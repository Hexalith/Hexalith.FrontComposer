# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> repeatable rounded native planes shield only contained focus paint
- Location: specs/responsive-accessibility.spec.ts:45:1

# Error details

```
Error: locator.evaluate: Error: Competing border/shadow paint needs pixel evidence: {"element":"BUTTON#.","candidate":"DIV#under.","pseudo":null,"boxes":[{"left":41,"right":145,"top":98,"bottom":100},{"left":41,"right":145,"top":132,"bottom":134},{"left":41,"right":43,"top":100,"bottom":132},{"left":143,"right":145,"top":100,"bottom":132}],"paintBoxes":[{"left":0,"right":1280,"top":0,"bottom":3},{"left":1277,"right":1280,"top":0,"bottom":720},{"left":0,"right":1280,"top":717,"bottom":720},{"left":0,"right":3,"top":0,"bottom":720},{"left":-30,"right":1310,"top":-30,"bottom":750}],"candidateBox":{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0},"shadow":"rgb(0, 0, 0) 0px 0px 20px 0px"}
    at unsupported (eval at evaluate (:311:30), <anonymous>:304:39)
    at sample (eval at evaluate (:311:30), <anonymous>:313:56)
    at visit (eval at evaluate (:311:30), <anonymous>:653:13)
    at eval (eval at evaluate (:311:30), <anonymous>:707:5)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- button "Action" [active] [ref=e4]
```