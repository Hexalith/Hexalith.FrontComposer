# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> review native-plane circular corner proof rejects supported bevel paint
- Location: specs/responsive-accessibility.spec.ts:91:1

# Error details

```
Error: locator.evaluate: Error: Overlapping sibling background needs pixel evidence: {"element":"BUTTON#.","candidate":"DIV#under.","boxes":[{"left":44,"right":68,"top":44,"bottom":46},{"left":44,"right":68,"top":66,"bottom":68},{"left":44,"right":46,"top":46,"bottom":66},{"left":66,"right":68,"top":46,"bottom":66}],"candidateBox":{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0},"candidateBoxes":[{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0}],"candidateClip":{"kind":"none"},"candidatePosition":"fixed","root":"document"}
    at sample (eval at evaluate (:311:30), <anonymous>:441:54)
    at visit (eval at evaluate (:311:30), <anonymous>:677:13)
    at eval (eval at evaluate (:311:30), <anonymous>:731:5)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- button "Action" [active] [ref=e4]
```