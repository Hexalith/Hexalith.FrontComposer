# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> review opaque native top-layer surfaces shield text from page backgrounds only
- Location: specs/responsive-accessibility.spec.ts:1525:1

# Error details

```
Error: locator.evaluate: Error: Overlapping sibling background needs pixel evidence: {"element":"P#.","candidate":"DIV#under.","boxes":[{"left":601.5625,"right":678.4375,"top":351,"bottom":368}],"candidateBox":{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0},"candidateBoxes":[{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0}],"candidateClip":{"kind":"none"},"candidatePosition":"fixed","root":"document"}
    at sample (eval at evaluate (:311:30), <anonymous>:441:54)
    at visit (eval at evaluate (:311:30), <anonymous>:564:13)
    at eval (eval at evaluate (:311:30), <anonymous>:731:5)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- dialog [active] [ref=e3]:
  - paragraph [ref=e4]: Modal label
```