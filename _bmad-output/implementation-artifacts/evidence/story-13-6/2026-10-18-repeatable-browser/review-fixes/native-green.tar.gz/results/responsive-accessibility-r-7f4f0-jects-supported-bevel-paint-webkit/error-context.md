# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> review native-plane circular corner proof rejects supported bevel paint
- Location: specs/responsive-accessibility.spec.ts:91:1

# Error details

```
Error: locator.evaluate: Error: Overlapping sibling background needs pixel evidence: {"element":"BUTTON#.","candidate":"DIV#under.","boxes":[{"left":44,"right":68,"top":44,"bottom":46},{"left":44,"right":68,"top":66,"bottom":68},{"left":44,"right":46,"top":46,"bottom":66},{"left":66,"right":68,"top":46,"bottom":66}],"candidateBox":{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0},"candidateBoxes":[{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0}],"candidateClip":{"kind":"none"},"candidatePosition":"fixed","root":"document"}
```

# Page snapshot

```yaml
- button "Action" [active] [ref=e4]
```

# Test source

```ts
  924  |       }
  925  |       return false;
  926  |     };
  927  |     const check = (owner: Element, initial: PaintBox[]) => {
  928  |       let boxes = initial.filter(box => box.right > box.left && box.bottom > box.top);
  929  |       for (let current: Element | null = owner; current && boxes.length; current = parent(current)) {
  930  |         const css = getComputedStyle(current), bounds = current.getBoundingClientRect();
  931  |         const explicit = audit.clip(css, bounds);
  932  |         if (explicit.kind === 'unsupported') failures.add(`${identify(current)}: text clip/mask needs pixel evidence`);
  933  |         if (explicit.kind === 'hidden') { failures.add(identify(current)); break; }
  934  |         const clip = explicit.box;
  935  |         if (clip) {
  936  |           if (boxes.some(box => box.left < clip.left - 1 || box.right > clip.right + 1 || box.top < clip.top - 1 || box.bottom > clip.bottom + 1)) failures.add(identify(current));
  937  |           boxes = boxes.map(box => ({ left: Math.max(box.left, clip.left), right: Math.min(box.right, clip.right), top: Math.max(box.top, clip.top), bottom: Math.min(box.bottom, clip.bottom) }));
  938  |         }
  939  |         if (!['inline', 'contents'].includes(css.display)) {
  940  |           const left = bounds.left + parseFloat(css.borderLeftWidth), right = bounds.right - parseFloat(css.borderRightWidth);
  941  |           const top = bounds.top + parseFloat(css.borderTopWidth), bottom = bounds.bottom - parseFloat(css.borderBottomWidth);
  942  |           if (boxes.some(box => /(hidden|clip)/u.test(css.overflowX) && (box.left < left - 1 || box.right > right + 1)
  943  |             || /(hidden|clip)/u.test(css.overflowY) && (box.top < top - 1 || box.bottom > bottom + 1))) failures.add(identify(current));
  944  |           // A nested scrollport owns its offscreen content. Only its visible portion
  945  |           // can be clipped again by an outer owner, including across shadow slots.
  946  |           boxes = boxes.map(box => ({
  947  |             left: /(auto|scroll|hidden|clip)/u.test(css.overflowX) ? Math.max(box.left, left) : box.left,
  948  |             right: /(auto|scroll|hidden|clip)/u.test(css.overflowX) ? Math.min(box.right, right) : box.right,
  949  |             top: /(auto|scroll|hidden|clip)/u.test(css.overflowY) ? Math.max(box.top, top) : box.top,
  950  |             bottom: /(auto|scroll|hidden|clip)/u.test(css.overflowY) ? Math.min(box.bottom, bottom) : box.bottom,
  951  |           }));
  952  |         }
  953  |         boxes = boxes.filter(box => box.right > box.left && box.bottom > box.top);
  954  |         // Native top-layer surfaces escape outer clips, but retain their own checks.
  955  |         if (current.matches(':popover-open,:modal')) break;
  956  |       }
  957  |     };
  958  |     const visit = (node: Node) => {
  959  |       if (visited.has(node)) return;
  960  |       visited.add(node);
  961  |       if (node instanceof Text) {
  962  |         const owner = parent(node);
  963  |         if (!node.textContent?.trim() || !owner || excluded(owner)) return;
  964  |         const range = document.createRange(); range.selectNodeContents(node);
  965  |         check(owner, [...range.getClientRects()]);
  966  |       } else if (node instanceof Element) {
  967  |         if (excluded(node)) return;
  968  |         if ((node instanceof HTMLInputElement && ['text','search','email','url','tel','password','number'].includes(node.type) || node instanceof HTMLTextAreaElement || node instanceof HTMLSelectElement)
  969  |           && (node instanceof HTMLSelectElement ? node.selectedOptions.length > 0 : node.value || node.placeholder)) {
  970  |           const css = getComputedStyle(node), bounds = node.getBoundingClientRect();
  971  |           if (bounds.width && bounds.height) {
  972  |             const context = document.createElement('canvas').getContext('2d')!;
  973  |             context.font = css.font;
  974  |             const glyph = context.measureText(node instanceof HTMLSelectElement ? [...node.selectedOptions].map(option => option.label).join(' ') : node.value || node.placeholder);
  975  |             const height = glyph.actualBoundingBoxAscent + glyph.actualBoundingBoxDescent;
  976  |             const available = bounds.height - parseFloat(css.borderTopWidth) - parseFloat(css.borderBottomWidth) - parseFloat(css.paddingTop) - parseFloat(css.paddingBottom);
  977  |             if (height > available + 1) failures.add(`${identify(node)}: native value is vertically clipped`);
  978  |             // Native values scroll horizontally by design; their painted viewport
  979  |             // still participates in outer composed clipping.
  980  |             check(node, [{ left: bounds.left + parseFloat(css.borderLeftWidth), top: bounds.top + parseFloat(css.borderTopWidth), right: bounds.right - parseFloat(css.borderRightWidth), bottom: bounds.bottom - parseFloat(css.borderBottomWidth) }]);
  981  |           }
  982  |         }
  983  |         for (const pseudo of ['::before', '::after']) {
  984  |           const generated = getComputedStyle(node, pseudo);
  985  |           if (!generated.content || ['none','normal','""',"''"].includes(generated.content) || generated.display === 'none' || generated.visibility === 'hidden' || Number(generated.opacity) === 0) continue;
  986  |           const visualContent = generated.content.match(/^("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')(?:\s*\/.*)?$/u)?.[1];
  987  |           if (visualContent && ['""', "''"].includes(visualContent)) continue;
  988  |           if (/(hidden|clip)/u.test(generated.overflowX + generated.overflowY)) {
  989  |             failures.add(`${identify(node)}: generated text clipping needs pixel evidence`);
  990  |             continue;
  991  |           }
  992  |           // Supported normal-flow glyphs fit their host's scroll envelope. Use that
  993  |           // conservative envelope through composed clips, including required markers.
  994  |           if (visualContent && generated.position === 'static' && generated.transform === 'none' && generated.cssFloat === 'none'
  995  |             && node.clientWidth > 0 && node.clientHeight > 0 && node.scrollWidth <= node.clientWidth + .5 && node.scrollHeight <= node.clientHeight + .5
  996  |             && [generated.marginTop, generated.marginRight, generated.marginBottom, generated.marginLeft].every(value => Number.isFinite(parseFloat(value)) && parseFloat(value) >= 0)) {
  997  |             check(node, [node.getBoundingClientRect()]);
  998  |             continue;
  999  |           }
  1000 |           for (let owner: Element | null = node; owner; owner = parent(owner)) {
  1001 |             const css = getComputedStyle(owner);
  1002 |             if (/(hidden|clip)/u.test(css.overflowX + css.overflowY) || audit.clip(css, owner.getBoundingClientRect()).kind !== 'none') {
  1003 |               failures.add(`${identify(owner)}: generated text clipping needs pixel evidence`); break;
  1004 |             }
  1005 |             if (owner.matches(':popover-open,:modal')) break;
  1006 |           }
  1007 |         }
  1008 |         if (node instanceof HTMLSlotElement) for (const child of node.assignedNodes({ flatten: true })) visit(child);
  1009 |         if (node.shadowRoot) for (const child of node.shadowRoot.childNodes) visit(child);
  1010 |         for (const child of node.childNodes) visit(child);
  1011 |       }
  1012 |     };
  1013 |     visit(document.documentElement);
  1014 |     return [...failures];
  1015 |   });
  1016 |   expect(failures, 'AE-03 clipped text ranges').toEqual([]);
  1017 | }
  1018 | 
  1019 | export type ContrastKind = 'text' | 'border' | 'icon' | 'focus' | 'cue';
  1020 | 
  1021 | /** Sample actual painted nodes in the composed tree; empty/unsupported samples fail closed. */
  1022 | export async function measureSurfaceContrast(root: Locator, kind: ContrastKind = 'text') {
  1023 |   await preparePaintAudit(root);
> 1024 |   return root.evaluate((scope, sampleKind) => {
       |               ^ Error: locator.evaluate: Error: Overlapping sibling background needs pixel evidence: {"element":"BUTTON#.","candidate":"DIV#under.","boxes":[{"left":44,"right":68,"top":44,"bottom":46},{"left":44,"right":68,"top":66,"bottom":68},{"left":44,"right":46,"top":46,"bottom":66},{"left":66,"right":68,"top":46,"bottom":66}],"candidateBox":{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0},"candidateBoxes":[{"x":0,"y":0,"width":1280,"height":720,"top":0,"right":1280,"bottom":720,"left":0}],"candidateClip":{"kind":"none"},"candidatePosition":"fixed","root":"document"}
  1025 |     const parent = (node: Element): Element | null => node.assignedSlot ?? node.parentElement ?? (node.getRootNode() instanceof ShadowRoot ? (node.getRootNode() as ShadowRoot).host : null);
  1026 |     const audit = (window as typeof window & { __aePaintAudit: PaintAudit }).__aePaintAudit;
  1027 |     const parse = audit.parse;
  1028 |     const resting = sampleKind === 'focus' ? audit.resting(scope) : new Map();
  1029 |     const composite = (fg: number[], bg: number[]) => [0, 1, 2].map(i => fg[i] * fg[3] + bg[i] * (1 - fg[3])).concat(1);
  1030 |     const background = (element: Element | null) => {
  1031 |       const layers: number[][] = [];
  1032 |       for (let current = element; current; current = parent(current)) {
  1033 |         const css = getComputedStyle(current);
  1034 |         if (css.backgroundImage !== 'none') throw new Error('Background image needs pixel evidence');
  1035 |         if (css.filter !== 'none' || css.mixBlendMode !== 'normal' || css.getPropertyValue('backdrop-filter') && css.getPropertyValue('backdrop-filter') !== 'none') throw new Error('Filtered or blended paint needs pixel evidence');
  1036 |         if (Number(css.opacity) > 0 && Number(css.opacity) < 1) throw new Error(`Translucent group needs pixel evidence: ${current.tagName}.${current.className} opacity=${css.opacity}`);
  1037 |         layers.push(parse(css.backgroundColor));
  1038 |       }
  1039 |       const probe = document.createElement('span'); probe.style.color = 'Canvas'; document.documentElement.append(probe);
  1040 |       const canvas = parse(getComputedStyle(probe).color); probe.remove();
  1041 |       return layers.reverse().reduce((bg, fg) => composite(fg, bg), canvas);
  1042 |     };
  1043 |     const luminance = (color: number[]) => color.slice(0, 3).map(channel => { const c = channel / 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, c, i) => sum + c * [.2126, .7152, .0722][i], 0);
  1044 |     const visible = (element: Element) => {
  1045 |       if (element.getClientRects().length === 0 && getComputedStyle(element).display !== 'contents') return false;
  1046 |       for (let current: Element | null = element; current; current = parent(current)) {
  1047 |         const css = getComputedStyle(current);
  1048 |         if (sampleKind === 'icon' && current.matches('fluent-skeleton,.fluent-skeleton,.fc-empty-state-body__icon')) return false;
  1049 |         if (audit.clip(css, current.getBoundingClientRect()).kind === 'hidden') return false;
  1050 |         if (css.visibility === 'hidden' || css.display === 'none' || Number(css.opacity) === 0 || current.matches('[hidden],.fc-sr-only,.fc-skip-link:not(:focus),[disabled],[aria-disabled="true"]')) return false;
  1051 |       }
  1052 |       return true;
  1053 |     };
  1054 |     const samples: { owner: number; node: string; paint: string; foreground: number[]; background: number[]; ratio: number; minimum: number; measurement?: 'conservative-bound'; shadowBound?: ShadowContrastBound }[] = [];
  1055 |     const owners = new Map<Element, number>();
  1056 |     const controlOwner = (element: Element) => {
  1057 |       let nearest: Element | null = null;
  1058 |       for (let current: Element | null = element; current; current = parent(current)) {
  1059 |         if (current.matches('fluent-button,fluent-text-input,fluent-number-input,fluent-dropdown,fluent-combobox,fluent-select,fluent-radio,fluent-switch')) return current;
  1060 |         if (!nearest && current.matches('button,input,select,textarea,a[href],[role="button"],[role="tab"],[role="radio"],[role="option"]')) nearest = current;
  1061 |         if (current === scope) break;
  1062 |       }
  1063 |       return nearest ?? element;
  1064 |     };
  1065 |     const pseudoEdges = new Map<Element, PaintBox>();
  1066 |     const pseudoOutside = (element: Element, css: CSSStyleDeclaration, side: string) => {
  1067 |       pseudoEdges.delete(element);
  1068 |       if (!['absolute','fixed'].includes(css.position)) {
  1069 |         if ([css.marginTop,css.marginRight,css.marginBottom,css.marginLeft].some(value => parseFloat(value) < 0)) throw new Error('Flow pseudo border adjacency needs pixel evidence');
  1070 |         const clipping = audit.clip(css, element.getBoundingClientRect());
  1071 |         if (clipping.kind === 'hidden') return null;
  1072 |         if (clipping.kind !== 'none') throw new Error('Clipped pseudo border needs pixel evidence');
  1073 |         return false;
  1074 |       }
  1075 |       let containing: Element | null = css.position === 'fixed' ? null : element;
  1076 |       while (containing && getComputedStyle(containing).position === 'static' && getComputedStyle(containing).transform === 'none') containing = parent(containing);
  1077 |       if (containing && getComputedStyle(containing).transform !== 'none') {
  1078 |         const transform = new DOMMatrixReadOnly(getComputedStyle(containing).transform);
  1079 |         if (!transform.is2D || transform.a !== 1 || transform.d !== 1 || transform.b !== 0 || transform.c !== 0) throw new Error('Transformed pseudo border adjacency needs pixel evidence');
  1080 |       }
  1081 |       const bounds = containing?.getBoundingClientRect();
  1082 |       const base = containing && bounds ? { left: bounds.left + containing.clientLeft, top: bounds.top + containing.clientTop, width: containing.clientWidth, height: containing.clientHeight } : { left: 0, top: 0, width: innerWidth, height: innerHeight };
  1083 |       const px = (value: string) => /^-?[\d.]+px$/u.test(value) ? parseFloat(value) : null;
  1084 |       const width = px(css.width), height = px(css.height), left = px(css.left), right = px(css.right), top = px(css.top), bottom = px(css.bottom);
  1085 |       if (width === null || height === null || left === null && right === null || top === null && bottom === null) throw new Error('Unresolved pseudo border adjacency needs pixel evidence');
  1086 |       const extraX = css.boxSizing === 'border-box' ? 0 : parseFloat(css.paddingLeft) + parseFloat(css.paddingRight) + parseFloat(css.borderLeftWidth) + parseFloat(css.borderRightWidth);
  1087 |       const extraY = css.boxSizing === 'border-box' ? 0 : parseFloat(css.paddingTop) + parseFloat(css.paddingBottom) + parseFloat(css.borderTopWidth) + parseFloat(css.borderBottomWidth);
  1088 |       const matrix = new DOMMatrixReadOnly(css.transform === 'none' ? undefined : css.transform);
  1089 |       if (!matrix.is2D || matrix.a !== 1 || matrix.d !== 1 || matrix.b !== 0 || matrix.c !== 0) throw new Error('Transformed pseudo border adjacency needs pixel evidence');
  1090 |       const x = base.left + (left !== null ? left + parseFloat(css.marginLeft) : base.width - right! - width - extraX - parseFloat(css.marginRight)) + matrix.e;
  1091 |       const y = base.top + (top !== null ? top + parseFloat(css.marginTop) : base.height - bottom! - height - extraY - parseFloat(css.marginBottom)) + matrix.f;
  1092 |       const box = { left: x, top: y, right: x + width + extraX, bottom: y + height + extraY };
  1093 |       const clipping = audit.clip(css, box);
  1094 |       if (clipping.kind === 'hidden') return null;
  1095 |       if (clipping.kind === 'unsupported') throw new Error('Clipped pseudo border needs pixel evidence');
  1096 |       const thickness = parseFloat(css.getPropertyValue(`border-${side}-width`));
  1097 |       if (side === 'top') box.bottom = box.top + thickness;
  1098 |       if (side === 'bottom') box.top = box.bottom - thickness;
  1099 |       if (side === 'left') box.right = box.left + thickness;
  1100 |       if (side === 'right') box.left = box.right - thickness;
  1101 |       if (clipping.box) {
  1102 |         box.left = Math.max(box.left, clipping.box.left); box.right = Math.min(box.right, clipping.box.right);
  1103 |         box.top = Math.max(box.top, clipping.box.top); box.bottom = Math.min(box.bottom, clipping.box.bottom);
  1104 |         if (box.right <= box.left || box.bottom <= box.top) return null;
  1105 |       }
  1106 |       pseudoEdges.set(element, box);
  1107 |       const control = element.getBoundingClientRect();
  1108 |       if (box.left >= control.left - .5 && box.right <= control.right + .5 && box.top >= control.top - .5 && box.bottom <= control.bottom + .5) return false;
  1109 |       if (box.right <= control.left + .5 || box.left >= control.right - .5 || box.bottom <= control.top + .5 || box.top >= control.bottom - .5) return true;
  1110 |       throw new Error('Straddling pseudo border adjacency needs pixel evidence');
  1111 |     };
  1112 |     const pagePaint: Element[] = [];
  1113 |     const collectPaint = (root: Document | ShadowRoot) => {
  1114 |       for (const candidate of root.querySelectorAll('*')) { pagePaint.push(candidate); if (candidate.shadowRoot) collectPaint(candidate.shadowRoot); }
  1115 |     };
  1116 |     collectPaint(document);
  1117 |     const clippedPaint = (element: Element, boxes: PaintBox[], content = true): PaintBox[] => {
  1118 |       if (!boxes.length) return [];
  1119 |       for (let current: Element | null = element; current; current = parent(current)) {
  1120 |         const css = getComputedStyle(current);
  1121 |         if (css.filter !== 'none' || css.mixBlendMode !== 'normal' || css.getPropertyValue('backdrop-filter') && css.getPropertyValue('backdrop-filter') !== 'none') throw new Error('Filtered or blended paint needs pixel evidence');
  1122 |         const clipping = audit.clip(css, current.getBoundingClientRect());
  1123 |         if (clipping.kind === 'hidden') return [];
  1124 |         if (clipping.kind === 'unsupported') throw new Error('Clipped contrast paint needs pixel evidence');
```