# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> review native-plane corner proof rejects host CSS zoom
- Location: specs/responsive-accessibility.spec.ts:84:44

# Error details

```
Error: expect(received).rejects.toThrow()

Received promise resolved instead of rejected
Resolved to value: [{"background": [255, 255, 255, 1], "foreground": [0, 0, 0, 1], "minimum": 3, "node": "button", "owner": 0, "paint": "element outline", "ratio": 21}]
```

# Page snapshot

```yaml
- button "Action" [active] [ref=e3]
```

# Test source

```ts
  1   | import { readFile } from 'node:fs/promises';
  2   | import { expect, test } from '../fixtures/index.js';
  3   | import { applyTextSpacing, removeTextSpacing, expectFocusVisible, expectNoPageOverflow, expectNoTextClipping, expectTargetSizes, expectTextContrast, expectSurfaceContrast, focusGeometry, inventoryTargets, screenshotPreservingScroll, settlePaint, measureSurfaceContrast, type TargetException } from '../helpers/responsive-accessibility.js';
  4   | import { expectNoBlockingAxeViolations } from '../helpers/a11y.js';
  5   | import { specimenManifest } from '../helpers/specimen-manifest.js';
  6   | 
  7   | async function fixtureFocusGeometry(target: import('@playwright/test').Locator) {
  8   |   await target.evaluate(element => {
  9   |     element.setAttribute('data-ae-focus-fixture', 'true');
  10  |     const style = document.createElement('style');
  11  |     style.textContent = '[data-ae-focus-fixture]:not(:focus){outline:none!important;box-shadow:none!important}[data-ae-focus-fixture]:not(:focus)::before,[data-ae-focus-fixture]:not(:focus)::after{content:none!important}';
  12  |     document.head.append(style);
  13  |   });
  14  |   await target.focus();
  15  |   return focusGeometry(target);
  16  | }
  17  | 
  18  | test('resumed review simple contrast rejects translucent composed ancestors', async ({ page }) => {
  19  |   await page.setContent('<div id="host" style="opacity:.01;background:white"></div>');
  20  |   await page.locator('#host').evaluate(host => {
  21  |     host.attachShadow({ mode: 'open' }).innerHTML = '<p style="color:black;background:white">Essential warning</p>';
  22  |   });
  23  |   await expect(expectTextContrast(page.locator('#host p'))).rejects.toThrow(/opacity.*pixel evidence/);
  24  |   await page.locator('#host').evaluate(host => { host.style.opacity = '1'; });
  25  |   expect((await expectTextContrast(page.locator('#host p'))).ratio).toBe(21);
  26  |   await page.locator('#host p').evaluate(text => { (text as HTMLElement).style.opacity = '.01'; });
  27  |   await expect(expectTextContrast(page.locator('#host p'))).rejects.toThrow(/opacity.*pixel evidence/);
  28  | });
  29  | 
  30  | test('resumed review fixed pseudo focus checks the transformed target containing block', async ({ page }) => {
  31  |   await page.setViewportSize({ width: 1280, height: 900 });
  32  |   await page.setContent('<style>button{position:absolute;left:1200px;top:40px;width:60px;height:40px;transform:translateX(0);outline:none}button:focus::after{content:"";position:fixed;left:50px;top:50px;width:100px;height:40px;border:2px solid black}</style><button>Save</button>');
  33  |   expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('fixed pseudo in transformed ancestry needs pixel evidence');
  34  |   await page.locator('button').evaluate(button => { button.style.transform = 'none'; });
  35  |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  36  | });
  37  | 
  38  | test('resumed review transparent sibling glyphs cannot certify the warning they cover', async ({ page }) => {
  39  |   await page.setContent('<style>body{background:white}p{position:absolute;left:40px;top:40px;margin:0;font:20px monospace}#warning{color:black}#cover{color:white;z-index:1;pointer-events:none}</style><p id="warning">Essential warning</p><p id="cover">Essential warning</p>');
  40  |   await expect(measureSurfaceContrast(page.locator('#warning'))).rejects.toThrow(/Overlapping text needs pixel evidence/);
  41  |   await page.locator('#cover').evaluate(cover => { cover.style.top = '100px'; });
  42  |   expect((await measureSurfaceContrast(page.locator('#warning'))).every(sample => sample.ratio === 21)).toBe(true);
  43  | });
  44  | 
  45  | test('repeatable rounded native planes shield only contained focus paint', async ({ page }) => {
  46  |   await page.setContent('<style>body{background:white}#under{position:fixed;inset:0;background:black;border:3px solid black;box-shadow:0 0 20px black}button{position:absolute;left:3px;top:60px;width:100px;height:32px;background:white;color:black;border:0;outline:none}button:focus{outline:2px solid black}</style><div id="under"></div><div id="host"><button>Action</button></div>');
  47  |   await page.locator('#host').evaluate(host => {
  48  |     host.attachShadow({ mode: 'open' }).innerHTML = '<div id="plane" popover="manual" style="position:fixed;left:40px;top:40px;width:160px;height:160px;margin:0;padding:0;border:0;border-radius:12px;background:white"><slot></slot></div>';
  49  |     (host.shadowRoot!.querySelector('#plane') as HTMLElement).showPopover();
  50  |   });
  51  |   const target = page.getByRole('button');
  52  |   await target.focus();
  53  |   await expectSurfaceContrast(target, 'focus');
  54  |   await page.locator('#plane').evaluate(plane => { (plane as HTMLElement).style.background = 'transparent'; });
  55  |   await expect(measureSurfaceContrast(target, 'focus')).rejects.toThrow(/Overlapping sibling background|Competing border\/shadow/);
  56  |   await page.locator('#plane').evaluate(plane => { (plane as HTMLElement).style.background = 'white'; });
  57  |   await target.evaluate(button => { button.style.left = '-1px'; });
  58  |   await expect(measureSurfaceContrast(target, 'focus')).rejects.toThrow(/Overlapping sibling background|Competing border\/shadow/);
  59  |   await target.evaluate(button => { button.style.left = '3px'; button.style.top = '3px'; });
  60  |   await expect(measureSurfaceContrast(target, 'focus')).rejects.toThrow(/Overlapping sibling background|Competing border\/shadow/);
  61  |   await target.evaluate(button => { button.style.top = '60px'; });
  62  |   await page.evaluate(() => {
  63  |     const cover = document.createElement('div'); cover.id = 'cover'; cover.setAttribute('popover', 'manual');
  64  |     cover.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;margin:0;border:0;padding:0;background:black';
  65  |     document.body.append(cover); cover.showPopover();
  66  |   });
  67  |   await expect(measureSurfaceContrast(target, 'focus')).rejects.toThrow(/Overlapping sibling background|Competing border\/shadow/);
  68  |   await page.locator('#cover').evaluate(cover => { (cover as HTMLElement).hidePopover(); cover.remove(); });
  69  |   await expectSurfaceContrast(target, 'focus');
  70  | });
  71  | 
  72  | async function roundedPlaneCornerFixture(page: import('@playwright/test').Page) {
  73  |   await page.setContent('<style>body{background:white}#under{position:fixed;inset:0;background:black}button{position:absolute;left:6px;top:6px;width:20px;height:20px;background:white;color:black;border:0;outline:none}button:focus{outline:2px solid black}</style><div id="under"></div><div id="host"><button>Action</button></div>');
  74  |   await page.locator('#host').evaluate(host => {
  75  |     host.attachShadow({ mode: 'open' }).innerHTML = '<div id="plane" popover="manual" style="position:fixed;left:40px;top:40px;width:160px;height:160px;margin:0;padding:0;border:0;border-radius:12px;background:white"><slot></slot></div>';
  76  |     (host.shadowRoot!.querySelector('#plane') as HTMLElement).showPopover();
  77  |   });
  78  |   const target = page.getByRole('button');
  79  |   await target.focus();
  80  |   await expectSurfaceContrast(target, 'focus');
  81  |   return target;
  82  | }
  83  | 
  84  | for (const zoomOwner of ['plane', 'host']) test(`review native-plane corner proof rejects ${zoomOwner} CSS zoom`, async ({ page }) => {
  85  |   const target = await roundedPlaneCornerFixture(page);
  86  |   await target.evaluate(button => { button.style.left = '3px'; });
  87  |   await page.locator(`#${zoomOwner}`).evaluate(owner => { (owner as HTMLElement).style.zoom = '2'; });
> 88  |   await expect(measureSurfaceContrast(target, 'focus')).rejects.toThrow(/native-plane.*zoom.*pixel evidence/i);
      |                                                                 ^ Error: expect(received).rejects.toThrow()
  89  | });
  90  | 
  91  | test('review native-plane circular corner proof rejects supported bevel paint', async ({ page }, info) => {
  92  |   const supported = await page.evaluate(() => CSS.supports('corner-shape', 'bevel'));
  93  |   await info.attach('corner-shape-capability', { body: JSON.stringify({ engine: info.project.name, supported }), contentType: 'application/json' });
  94  |   test.skip(!supported, 'This engine cannot paint corner-shape:bevel; circular positive remains independently covered.');
  95  |   const target = await roundedPlaneCornerFixture(page);
  96  |   await page.locator('#plane').evaluate(plane => { (plane as HTMLElement).style.setProperty('corner-shape', 'bevel'); });
  97  |   expect(await page.locator('#plane').evaluate(plane => getComputedStyle(plane).getPropertyValue('corner-shape'))).toContain('bevel');
  98  |   await expect(measureSurfaceContrast(target, 'focus')).rejects.toThrow(/Overlapping sibling background|Competing border\/shadow/);
  99  | });
  100 | 
  101 | // Synthetic failures protect the assertions themselves. These are geometry fixtures, never AT proof.
  102 | test.describe('AE geometry regression fixtures', () => {
  103 |   test('rejects a clipped ring even when the complete target is inside the viewport', async ({ page }) => {
  104 |     await page.setContent('<button style="position:fixed;left:0;top:40px;width:40px;height:30px;outline:3px solid;outline-offset:2px">Save</button>');
  105 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('viewport clips target or focus ring');
  106 |   });
  107 |   test('includes outer box-shadow rings and offsets in clipping geometry', async ({ page }) => {
  108 |     await page.setContent('<button style="position:fixed;left:4px;top:40px;width:40px;height:30px;appearance:none;outline:none;box-shadow:0 0 0 6px black">Save</button>');
  109 |     const first = await fixtureFocusGeometry(page.locator('button'));
  110 |     expect(first.box.left).toBe(-2);
  111 |     expect(first.failures).toContain('viewport clips target or focus ring');
  112 |     await page.locator('button').evaluate(element => { element.style.left = '20px'; element.style.boxShadow = '-18px 0 0 6px black'; });
  113 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('viewport clips target or focus ring');
  114 |     await page.locator('button').evaluate(element => { element.style.boxShadow = 'inset 0 0 0 6px black,0 0 0 6px transparent'; });
  115 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).not.toContain('viewport clips target or focus ring');
  116 |     await page.setContent('<style>button{position:fixed;left:4px;top:40px;width:40px;height:30px;appearance:none;outline:none}button::after{content:"";position:absolute;inset:-8px;outline:3px solid black}</style><button>Save</button>');
  117 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('viewport clips target or focus ring');
  118 |     await page.setContent('<style>button{position:relative;width:40px;height:30px;appearance:none;outline:none}button::after{content:"";position:absolute;inset:-8px;outline:3px solid black}</style><div style="overflow:hidden;width:80px;height:80px;padding:4px"><button>Save</button></div>');
  119 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('horizontal scrollport clips target or ring');
  120 |     await page.setContent('<div style="overflow:hidden;width:80px;height:80px;padding:4px"><button style="width:40px;height:30px;appearance:none;outline:none;box-shadow:0 0 0 6px black">Save</button></div>');
  121 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('horizontal scrollport clips target or ring');
  122 |     await page.locator('button').evaluate(element => { element.style.boxShadow = '0 0 6px black'; });
  123 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('blurred focus shadow needs pixel evidence');
  124 |     await page.setContent('<button style="position:fixed;left:40px;top:40px;width:80px;height:40px;appearance:none;outline:2px solid black;box-shadow:0 0 6px black">Save</button>');
  125 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toEqual([]);
  126 |     await page.setContent('<div style="position:fixed;left:40px;top:40px;width:100px;height:60px;overflow:hidden;padding:3px"><button style="width:80px;height:40px;appearance:none;outline:2px solid black;box-shadow:0 0 6px black">Save</button></div>');
  127 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toEqual([]);
  128 |     await page.locator('button').evaluate(element => { element.style.outlineWidth = '6px'; });
  129 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('horizontal scrollport clips target or ring');
  130 |   });
  131 |   test('detects an opaque fixed occluder inside a zero-box open shadow host', async ({ page }) => {
  132 |     await page.setContent('<button style="position:absolute;left:40px;top:40px;width:100px;height:40px;outline:2px solid">Save</button><div id="host" style="display:contents"></div>');
  133 |     await page.locator('#host').evaluate(element => { element.attachShadow({ mode: 'open' }).innerHTML = '<div style="position:fixed;left:45px;top:45px;width:8px;height:8px;background:black;z-index:10"></div>'; });
  134 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  135 |     await page.locator('#host').evaluate(element => { (element.shadowRoot!.firstElementChild as HTMLElement).style.background = 'transparent'; (element.shadowRoot!.firstElementChild as HTMLElement).style.pointerEvents = 'none'; });
  136 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).not.toContain('app content obscures target or focus ring');
  137 |   });
  138 |   test('a real Fluent dropdown owns its passive sibling indicator, while an overlapping shadow sibling still occludes', async ({ page }, info) => {
  139 |     await page.setViewportSize({ width: 320, height: 900 });
  140 |     await page.goto('/__frontcomposer/specimens/type');
  141 |     await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  142 |     const dropdown = page.locator('fluent-dropdown').first();
  143 |     const control = dropdown.locator('button[slot="control"][role="combobox"]');
  144 |     await control.focus();
  145 |     const ownership = await control.evaluate(button => {
  146 |       const host = button.parentElement!;
  147 |       const icon = host.shadowRoot!.querySelector('slot[name="indicator"] svg[aria-hidden="true"]')!;
  148 |       return { controlSlot: button.assignedSlot?.name, indicatorSlot: icon.parentElement?.getAttribute('name'), sharedShadow: button.assignedSlot?.getRootNode() === icon.getRootNode(), directDescendant: button.contains(icon) };
  149 |     });
  150 |     expect(ownership).toEqual({ controlSlot: 'control', indicatorSlot: 'indicator', sharedShadow: true, directDescendant: false });
  151 |     await info.attach('dropdown-composed-ownership', { body: JSON.stringify(ownership), contentType: 'application/json' });
  152 |     expect((await focusGeometry(control)).failures).toEqual([]);
  153 |     await dropdown.evaluate(host => {
  154 |       const overlay = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  155 |       overlay.setAttribute('aria-hidden', 'true');
  156 |       overlay.setAttribute('style', 'position:absolute;right:8px;top:8px;width:12px;height:12px;z-index:100');
  157 |       overlay.innerHTML = '<rect width="12" height="12" fill="black"/>';
  158 |       host.shadowRoot!.querySelector('.control')!.append(overlay);
  159 |     });
  160 |     expect((await focusGeometry(control)).failures).toContain('app content obscures target or focus ring');
  161 |   });
  162 |   test('rejects an off-center occluder and ancestor clipping', async ({ page }) => {
  163 |     await page.setContent('<button style="position:absolute;left:40px;top:40px;width:100px;height:40px">Save</button><div style="position:absolute;left:45px;top:45px;width:3px;height:3px;background:red"></div>');
  164 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  165 |     await page.setContent('<div style="overflow:hidden;width:35px;height:60px"><button style="width:40px;height:30px">Save</button></div>');
  166 |     expect((await fixtureFocusGeometry(page.locator('button'))).failures).toContain('horizontal scrollport clips target or ring');
  167 |   });
  168 |   test('spacing exceptions reject neighboring circles and accept an isolated target', async ({ page }) => {
  169 |     const spacing: TargetException = { selector: '#a', kind: 'Spacing', rationale: 'Isolated fixture target', keyboardPath: 'Tab', evidence: 'Retained geometry inventory' };
  170 |     await page.setContent('<button id="a" style="position:absolute;left:40px;top:40px;width:10px;height:10px;padding:0">A</button><button id="b" style="position:absolute;left:60px;top:40px;width:10px;height:10px;padding:0">B</button>');
  171 |     expect((await inventoryTargets(page, [spacing])).inventory[0].failure).toContain('neighboring undersized circle');
  172 |     await page.locator('#b').evaluate(element => element.remove());
  173 |     expect((await inventoryTargets(page, [spacing])).inventory[0].failure).toBeNull();
  174 |   });
  175 |   test('rejects missing and invalid equivalent inventories', async ({ page }) => {
  176 |     await page.setContent('<button id="a" style="width:10px;height:10px;padding:0">A</button>');
  177 |     expect((await inventoryTargets(page)).inventory[0].failure).toContain('lacks an evidenced exception');
  178 |     const exception: TargetException = { selector: '#a', kind: 'Equivalent', rationale: 'Fixture', keyboardPath: 'Tab', evidence: 'Fixture', equivalentSelector: '#a' };
  179 |     expect((await inventoryTargets(page, [exception])).inventory[0].failure).toContain('Equivalent control');
  180 |   });
  181 |   test('a nonmodal dialog does not hide outside pointer targets from evidence', async ({ page }) => {
  182 |     await page.setContent('<button id="outside" style="position:absolute;left:40px;top:40px;width:5px;height:5px;padding:0">Outside</button><dialog><button id="inside" style="width:40px;height:40px">Inside</button></dialog>');
  183 |     await page.locator('dialog').evaluate(dialog => (dialog as HTMLDialogElement).show());
  184 |     const inventory = (await inventoryTargets(page)).inventory;
  185 |     expect(inventory.find(target => target.target === '#outside')?.failure).toContain('lacks an evidenced exception');
  186 |     expect(inventory.find(target => target.target === '#inside')?.failure).toBeNull();
  187 |   });
  188 |   test('spacing overrides reach Fluent-style shadow content and contrast composites alpha', async ({ page }) => {
```