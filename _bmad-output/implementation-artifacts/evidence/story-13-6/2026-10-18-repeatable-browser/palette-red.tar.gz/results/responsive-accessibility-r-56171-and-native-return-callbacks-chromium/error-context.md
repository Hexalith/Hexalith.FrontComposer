# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> repeatable palette dismissal preserves Tab through delayed entry and native return callbacks
- Location: specs/responsive-accessibility.spec.ts:1142:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByTestId('fc-settings-button')
Expected: focused
Received: inactive
Timeout:  10000ms

Call log:
  - Expect "toBeFocused" getByTestId('fc-settings-button') with timeout 10000ms
  - waiting for getByTestId('fc-settings-button')
    24 × locator resolved to <fluent-button icon-only="" tabindex="0" role="button" appearance="subtle" title="Open settings" aria-label="Open settings" data-testid="fc-settings-button" _bl_18025758-2d88-4cd8-94fa-eb2b5b527c98="">…</fluent-button>
       - unexpected value "inactive"

```

```yaml
- button "Open settings"
```

# Test source

```ts
  1092 | });
  1093 | 
  1094 | test('R10 generated meaningful text cannot disappear beside passing text', async ({ page }) => {
  1095 |   await page.setContent('<style>div{background:white;color:black}div::before{content:"Generated label";color:#eee}</style><div>Passing label</div>');
  1096 |   await expect(expectSurfaceContrast(page.locator('div'))).rejects.toThrow(/contrast failures/);
  1097 |   await page.addStyleTag({ content: 'div::before{color:black}' });
  1098 |   await expectSurfaceContrast(page.locator('div'));
  1099 | });
  1100 | 
  1101 | test('R11 collapsed offset shadow paints no focus pixels', async ({ page }) => {
  1102 |   await page.setContent('<style>button{appearance:none;margin:40px;outline:none}button:focus{box-shadow:10px 0 0 -100px black}</style><button>Action</button>');
  1103 |   await page.locator('button').focus();
  1104 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  1105 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  1106 |   await page.addStyleTag({ content: 'button:focus{box-shadow:10px 0 0 2px black}' });
  1107 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1108 | });
  1109 | 
  1110 | test('R12 permanent shadow cannot certify an invisible focus-only layer', async ({ page }) => {
  1111 |   await page.setContent('<style>button{margin:40px;background:white;outline:none;box-shadow:0 0 0 3px black}button:focus{box-shadow:0 0 0 3px black,0 0 0 1px white}</style><button>Action</button>');
  1112 |   await page.locator('button').focus();
  1113 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty|contrast failures/);
  1114 |   await page.addStyleTag({ content: 'button:focus{box-shadow:0 0 0 3px black,0 0 0 5px black}' });
  1115 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1116 | });
  1117 | 
  1118 | test('R13 inset pseudo focus border compares against control paint', async ({ page }) => {
  1119 |   await page.setContent('<style>button{position:relative;margin:40px;background:black;color:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black}</style><button>Action</button>');
  1120 |   await page.locator('button').focus();
  1121 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  1122 |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  1123 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1124 | });
  1125 | 
  1126 | test('R14 placeholder alpha determines effective contrast', async ({ page }) => {
  1127 |   await page.setContent('<style>input{background:white;color:black}input::placeholder{color:black;opacity:.1}</style><input placeholder="Meaningful placeholder">');
  1128 |   await expect(expectSurfaceContrast(page.locator('input'))).rejects.toThrow(/contrast failures/);
  1129 |   await page.addStyleTag({ content: 'input::placeholder{opacity:1}' });
  1130 |   await expectSurfaceContrast(page.locator('input'));
  1131 | });
  1132 | 
  1133 | test('reflow rejects unlabelled nested horizontal scrolling and stale or unjustified target exceptions', async ({ page }) => {
  1134 |   await page.setContent('<div style="width:100px;overflow:auto"><div style="width:200px">Long content</div></div><button id="small" style="width:10px;height:10px;padding:0">A</button>');
  1135 |   await expect(expectNoPageOverflow(page)).rejects.toThrow(/scroll/);
  1136 |   const record: TargetException = { selector: '#small', kind: 'Essential', rationale: 'Small fixture', keyboardPath: 'Tab', evidence: 'fixture' };
  1137 |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('Essential');
  1138 |   await page.locator('#small').evaluate(node => { node.style.width = node.style.height = '30px'; });
  1139 |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('stale');
  1140 | });
  1141 | 
  1142 | test('repeatable palette dismissal preserves Tab through delayed entry and native return callbacks', async ({ page }, info) => {
  1143 |   // Delay only the completion reply of the real entry interop. Its focus behavior,
  1144 |   // component registration/disposal and the keyboard dismissal all remain genuine.
  1145 |   await page.route('**/fc-keyboard.js', async route => {
  1146 |     const response = await route.fetch();
  1147 |     const source = await response.text();
  1148 |     expect(source).toContain('export function focusElement(element)');
  1149 |     await route.fulfill({ response, body: source.replace('export function focusElement(element)', 'function originalPaletteEntry(element)') + `
  1150 | export function focusElement(element) {
  1151 |   const result = originalPaletteEntry(element);
  1152 |   if (element?.getAttribute?.('data-testid') !== 'fc-palette-search') return result;
  1153 |   return new Promise(resolve => { window.__aeReleasePaletteEntry = resolve; });
  1154 | }` });
  1155 |   });
  1156 |   await page.goto('/__frontcomposer/specimens/page-toolbar');
  1157 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1158 |   await page.getByTestId('fc-palette-trigger').click();
  1159 |   await expect(page.getByTestId('fc-palette-search')).toBeFocused();
  1160 |   await page.waitForFunction(() => typeof (window as typeof window & { __aeReleasePaletteEntry?: unknown }).__aeReleasePaletteEntry === 'function');
  1161 |   await page.evaluate(() => {
  1162 |     const host = document.querySelector('[data-testid="fc-palette-root"]')!.closest('fluent-dialog')!;
  1163 |     const callbacks: (() => void)[] = [];
  1164 |     const original = window.setTimeout;
  1165 |     window.setTimeout = ((handler: TimerHandler, delay?: number, ...args: unknown[]) => {
  1166 |       if (delay === 25 && typeof handler === 'function' && new Error().stack?.includes('Microsoft.FluentUI.AspNetCore.Components.lib.module.js')) {
  1167 |         callbacks.push(() => handler(...args)); return 0;
  1168 |       }
  1169 |       return original(handler, delay, ...args);
  1170 |     }) as typeof window.setTimeout;
  1171 |     (window as typeof window & { __aePaletteReturn?: unknown }).__aePaletteReturn = { host, callbacks, restore: () => { window.setTimeout = original; } };
  1172 |   });
  1173 |   await page.keyboard.press('Escape');
  1174 |   await expect(page.getByTestId('fc-palette-root')).toHaveCount(0);
  1175 |   await expect(page.getByTestId('fc-palette-trigger')).toBeFocused();
  1176 |   await page.keyboard.press('Tab');
  1177 |   const next = page.getByTestId('fc-settings-button');
  1178 |   await expect(next).toBeFocused();
  1179 |   const proof = await page.evaluate(() => {
  1180 |     const w = window as typeof window & {
  1181 |       __aeReleasePaletteEntry: () => void;
  1182 |       __aePaletteReturn: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void };
  1183 |     };
  1184 |     w.__aeReleasePaletteEntry();
  1185 |     w.__aePaletteReturn.restore();
  1186 |     const proof = { queued: w.__aePaletteReturn.callbacks.length, cleared: w.__aePaletteReturn.host.previousActiveElement === null };
  1187 |     for (const callback of w.__aePaletteReturn.callbacks) callback();
  1188 |     return proof;
  1189 |   });
  1190 |   await info.attach('palette-delayed-return', { body: JSON.stringify(proof), contentType: 'application/json' });
  1191 |   expect(proof.queued).toBeGreaterThan(0);
> 1192 |   await expect(next).toBeFocused();
       |                      ^ Error: expect(locator).toBeFocused() failed
  1193 |   expect(proof.cleared).toBe(true);
  1194 | });
  1195 | 
  1196 | test('R15 owned Settings return cancels the actual Fluent delayed return after an operator Tab', async ({ page }) => {
  1197 |   await page.goto('/counter');
  1198 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1199 |   await page.goto('/__frontcomposer/specimens/page-toolbar');
  1200 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1201 |   await page.getByTitle('Change theme').first().click();
  1202 |   await page.getByRole('menuitem', { name: 'Dark', exact: true }).click();
  1203 |   const toolbar = new (await import('../page-objects/page-toolbar-specimen.page.js')).PageToolbarSpecimenPage(page);
  1204 |   await toolbar.summaryTab.focus();
  1205 |   await toolbar.summaryTab.press('ArrowRight');
  1206 |   await page.getByTestId('fc-palette-trigger').click();
  1207 |   await expect(page.getByTestId('fc-palette-search')).toBeFocused();
  1208 |   await page.getByTestId('fc-palette-search').locator('input').fill('no-match-accessibility-136');
  1209 |   await page.keyboard.press('Escape');
  1210 |   await expect(page.getByTestId('fc-palette-trigger')).toBeFocused();
  1211 |   await page.keyboard.press('Tab');
  1212 |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  1213 |   await page.keyboard.press('Enter');
  1214 |   await expect(page.locator('#fc-settings-heading')).toBeFocused();
  1215 |   await page.keyboard.press('Tab');
  1216 |   await page.keyboard.press('Tab');
  1217 |   await page.evaluate(async () => {
  1218 |     const host = document.querySelector<HTMLElement>('[data-testid="fc-settings-dialog"]')!.closest('fluent-dialog')!;
  1219 |     const w = window as typeof window & { __aeVendorReturn?: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } };
  1220 |     const callbacks: (() => void)[] = [];
  1221 |     const original = window.setTimeout;
  1222 |     window.setTimeout = ((handler: TimerHandler, delay?: number, ...args: unknown[]) => {
  1223 |       // Hold the pinned Fluent callback itself, rather than substitute a synthetic return.
  1224 |       if (delay === 25 && typeof handler === 'function' && new Error().stack?.includes('Microsoft.FluentUI.AspNetCore.Components.lib.module.js')) {
  1225 |         callbacks.push(() => handler(...args));
  1226 |         return 0;
  1227 |       }
  1228 |       return original(handler, delay, ...args);
  1229 |     }) as typeof window.setTimeout;
  1230 |     w.__aeVendorReturn = { host, callbacks, restore: () => { window.setTimeout = original; } };
  1231 |   });
  1232 |   await page.keyboard.press('Escape');
  1233 |   await expect(page.getByTestId('fc-settings-dialog')).toHaveCount(0);
  1234 |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  1235 |   await page.keyboard.press('Shift+Tab');
  1236 |   const settings = page.getByTestId('fc-palette-trigger');
  1237 |   await expect(settings).toBeFocused();
  1238 |   const proof = await page.evaluate(() => {
  1239 |     const state = (window as typeof window & { __aeVendorReturn: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } }).__aeVendorReturn;
  1240 |     state.restore();
  1241 |     const proof = { queued: state.callbacks.length, cleared: state.host.previousActiveElement === null };
  1242 |     for (const callback of state.callbacks) callback();
  1243 |     return proof;
  1244 |   });
  1245 |   expect(proof.queued).toBeGreaterThan(0);
  1246 |   expect(proof.cleared).toBe(true);
  1247 |   await expect(settings).toBeFocused();
  1248 | });
  1249 | 
  1250 | 
  1251 | test('reused owned dialog dismissal resets only its current return and preserves later external input', async ({ page }) => {
  1252 |   await page.goto('/counter');
  1253 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1254 |   await page.evaluate(async () => {
  1255 |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  1256 |     const focus = await import(path) as { containDialogFocus: (testId: string) => boolean };
  1257 |     const host = document.createElement('fluent-dialog');
  1258 |     host.hidden = true;
  1259 |     host.innerHTML = '<div data-testid="fc-settings-dialog"></div>';
  1260 |     document.body.append(host);
  1261 |     const w = window as typeof window & { __fcModalReservation?: { watchFocus: boolean; moved: boolean }; __fcOverlayOpenIntent?: { watchFocus: boolean; moved: boolean } };
  1262 |     for (let opening = 0; opening < 2; opening++) {
  1263 |       document.querySelector<HTMLElement>('[data-testid="fc-palette-trigger"]')!.focus();
  1264 |       const reservation = { watchFocus: true, moved: true };
  1265 |       const intent = { watchFocus: true, moved: true };
  1266 |       w.__fcModalReservation = reservation;
  1267 |       w.__fcOverlayOpenIntent = intent;
  1268 |       if (!focus.containDialogFocus('fc-settings-dialog')) throw new Error('reused host containment failed');
  1269 |       host.dispatchEvent(new CustomEvent('beforetoggle', { detail: { newState: 'closed' } }));
  1270 |       if (reservation.watchFocus || reservation.moved || intent.watchFocus || intent.moved) throw new Error('native return retained modal input tracking');
  1271 |       document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
  1272 |       document.querySelector<HTMLElement>('[data-testid="fc-settings-button"]')!.focus();
  1273 |       if (!reservation.watchFocus || !reservation.moved || !intent.watchFocus || !intent.moved) throw new Error('later external input was discarded');
  1274 |     }
  1275 |     delete w.__fcModalReservation;
  1276 |     delete w.__fcOverlayOpenIntent;
  1277 |     host.remove();
  1278 |   });
  1279 | });
  1280 | 
  1281 | test('forced-color replacement capability is recorded for its engine and run', async ({ page }, info) => {
  1282 |   await page.setContent('<span style="color:rgb(255,0,0);background:rgb(0,255,0);forced-color-adjust:auto">Capability</span>');
  1283 |   await page.emulateMedia({ forcedColors: 'active' });
  1284 |   const forced = await page.locator('span').evaluate(element => {
  1285 |     const css = getComputedStyle(element);
  1286 |     return { forcedColors: matchMedia('(forced-colors: active)').matches, color: css.color, background: css.backgroundColor };
  1287 |   });
  1288 |   const authoredColorReplacement = forced.color !== 'rgb(255, 0, 0)' && forced.background !== 'rgb(0, 255, 0)';
  1289 |   if (!authoredColorReplacement) expect(info.project.name).toBe('webkit');
  1290 |   const path = info.outputPath(`forced-colors-capability-${info.project.name}.json`);
  1291 |   await (await import('node:fs/promises')).writeFile(path, JSON.stringify({ engine: info.project.name, runId: process.env.FC_A11Y_EVIDENCE_RUN_ID, testId: info.testId, attempt: info.retry, authoredColorReplacement, forced }));
  1292 |   await info.attach('forced-color-capability', { path, contentType: 'application/json' });
```