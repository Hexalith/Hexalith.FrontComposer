import { expect, test as base, type Locator, type Page } from '@playwright/test';

/**
 * Command lifecycle contract surfaced by FcLifecycleWrapper.
 * See `_bmad-output/planning-artifacts/architecture.md` for canonical state set.
 */
export const LIFECYCLE_STATES = ['idle', 'submitting', 'acknowledged', 'syncing', 'confirmed', 'rejected', 'idempotent-confirmed', 'needs-review', 'warning', 'degraded', 'degraded-exhausted'] as const;
export type LifecycleState = (typeof LIFECYCLE_STATES)[number];

export interface LifecycleAssertions {
  locator: (commandId: string) => Locator;
  expectState: (commandId: string, state: LifecycleState) => Promise<void>;
  waitForTerminal: (commandId: string) => Promise<LifecycleState>;
}

export type LifecycleFixtures = {
  lifecycle: LifecycleAssertions;
};

const lifecycleLocator = (page: Page, commandId: string): Locator =>
  page.locator(`[data-testid="fc-lifecycle-${commandId}"]`);
const TERMINAL_STATE_TIMEOUT_MS = 20_000;
export const TERMINAL_LIFECYCLE_STATES: readonly LifecycleState[] = ['confirmed', 'idempotent-confirmed', 'rejected', 'needs-review', 'warning', 'degraded-exhausted'];

const readState = async (locator: Locator): Promise<LifecycleState | null> => {
  const raw = await locator.getAttribute('data-lifecycle-state');
  if (!raw) return null;
  return LIFECYCLE_STATES.includes(raw as LifecycleState) ? (raw as LifecycleState) : null;
};

export const lifecycleTest = base.extend<LifecycleFixtures>({
  lifecycle: async ({ page }, use) => {
    const assertions: LifecycleAssertions = {
      locator: (commandId) => lifecycleLocator(page, commandId),
      expectState: async (commandId, state) => {
        const loc = lifecycleLocator(page, commandId);
        await expect(loc).toHaveAttribute('data-lifecycle-state', state, {
          timeout: TERMINAL_LIFECYCLE_STATES.includes(state) ? TERMINAL_STATE_TIMEOUT_MS : undefined,
        });
      },
      waitForTerminal: async (commandId) => {
        const loc = lifecycleLocator(page, commandId);
        await expect(loc).toHaveAttribute('data-lifecycle-state', /^(confirmed|idempotent-confirmed|rejected|needs-review|warning|degraded-exhausted)$/, {
          timeout: TERMINAL_STATE_TIMEOUT_MS,
        });
        const state = await readState(loc);
        if (!state) throw new Error(`lifecycle state missing for commandId=${commandId}`);
        return state;
      },
    };
    await use(assertions);
  },
});
