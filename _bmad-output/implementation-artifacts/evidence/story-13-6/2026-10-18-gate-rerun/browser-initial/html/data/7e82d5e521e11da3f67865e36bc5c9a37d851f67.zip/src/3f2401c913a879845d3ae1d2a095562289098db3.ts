import { expect, test } from '../fixtures/index.js';
import { expectNoBlockingAxeViolations } from '../helpers/a11y.js';
import { fieldEditorByLabel, waitForGeneratedFormReady } from '../helpers/fluent-fields.js';
import { spawn } from 'node:child_process';
import {
  getSpecimenRoute,
  specimenManifest,
  validateSpecimenManifest,
  type SpecimenRoute,
} from '../helpers/specimen-manifest.js';

const consoleErrorsByPage = new WeakMap<import('@playwright/test').Page, string[]>();
const unexpectedRequestsByPage = new WeakMap<import('@playwright/test').Page, string[]>();
const minimumReadableTextContrast = 4.5;
const windowsVisualBaselineMaxDiffPixels = 76_000;

test.describe('FrontComposer accessibility and visual specimens', () => {
  test.use({
    locale: 'fr-FR',
    timezoneId: 'UTC',
    deviceScaleFactor: 1,
  });

  test.beforeEach(async ({ page }) => {
    attachSpecimenGuards(page);

    await page.addInitScript(() => {
      window.localStorage.clear();
      window.sessionStorage.clear();
    });

    await page.setViewportSize({ width: 1280, height: 900 });
    await page.emulateMedia({ reducedMotion: 'reduce' });

    test.info().attachments.push({
      name: 'specimen-console-and-network-guard',
      contentType: 'text/plain',
      body: Buffer.from('Console and network guards are active for specimen routes.'),
    });

  });

  test.afterEach(async ({ page }) => {
    const consoleErrors = consoleErrorsByPage.get(page) ?? [];
    const unexpectedRequests = unexpectedRequestsByPage.get(page) ?? [];
    expect(consoleErrors, `Unhandled browser console errors:\n${consoleErrors.join('\n')}`).toEqual([]);
    expect(unexpectedRequests, `Unexpected network calls:\n${unexpectedRequests.join('\n')}`).toEqual([]);
  });

  test('manifest names owned nonblank specimen routes and exactly six visual combinations', () => {
    validateSpecimenManifest();
  });

  for (const route of specimenManifest.routes) {
    test(`${route.name} specimen is nonblank and passes blocking axe gate`, async ({ page }, testInfo) => {
      await gotoSpecimen(page, route);
      await expectNoBlockingAxeViolations(page, {
        route: route.path,
        include: [route.landmarkRoot],
        requiredSelectors: [route.readySelector, ...route.requiredSections],
        artifactPath: testInfo.outputPath(`axe-${route.name}.json`),
      });
    });
  }

  test('type specimen renders required shell, density, badge, lifecycle, detail, and nav surfaces', async ({ page }) => {
    const route = getSpecimenRoute('type');
    await gotoSpecimen(page, route);

    await expect(page.getByTestId('fc-type-slot-display')).toContainText('FrontComposer Display');
    await expect(page.getByTestId('fc-token-theme-light')).toBeVisible();
    await expect(page.getByTestId('fc-token-theme-dark')).toBeVisible();
    await expect(page.getByTestId('fc-density-state-compact')).toBeVisible();
    await expect(page.getByTestId('fc-density-state-comfortable')).toBeVisible();
    await expect(page.getByTestId('fc-density-state-roomy')).toBeVisible();
    await expect(page.getByTestId('fc-status-icon')).toHaveCount(6);
    await expect(page.getByLabel(/Status.*Neutral/u)).toHaveAttribute('data-fc-badge-slot', 'Neutral');
    await expect(page.getByLabel(/Status.*Info/u)).toHaveAttribute('data-fc-badge-slot', 'Info');
    await expect(page.getByLabel(/Status.*Success/u)).toHaveAttribute('data-fc-badge-slot', 'Success');
    await expect(page.getByLabel(/Status.*Warning/u)).toHaveAttribute('data-fc-badge-slot', 'Warning');
    await expect(page.getByLabel(/Status.*Danger/u)).toHaveAttribute('data-fc-badge-slot', 'Danger');
    await expect(page.getByLabel(/Status.*Accent/u)).toHaveAttribute('data-fc-badge-slot', 'Accent');
    await expect(page.getByTestId('fc-badge-grid').locator("[data-fc-field='Status']")).toHaveCount(6);
    await expect(page.getByTestId('fc-generated-counter-grid').locator("[data-fc-field='Count']").first()).toContainText('42');
    await expect(page.getByTestId('fc-lifecycle-idle')).toContainText('Ready to submit');
    await expect(page.getByTestId('fc-lifecycle-confirmed-rejected')).toContainText('Terminal confirmation');
    await expect(page.getByTestId('fc-expanded-detail')).toContainText('fc-correlation-0002');
    await expect(page.getByRole('navigation', { name: 'Specimen multi-level navigation' })).toBeVisible();
  });

  test('dark generated command specimens keep readable foreground contrast', async ({ page }) => {
    const route = getSpecimenRoute('type');
    await page.goto(`${route.path}?theme=dark&density=roomy`);
    await expect(page.locator(route.readySelector)).toBeVisible();

    // VG17-01 — a failed submit renders Fluent's error text, so the dark override for it is sampled too.
    // Retention stays unchosen, so client validation blocks the confirmation dialog.
    const destructiveForm = page.locator("[data-testid='fc-destructive-command-specimen'] .fc-command-form");
    await waitForGeneratedFormReady(destructiveForm);
    await destructiveForm.getByRole('button', { name: 'Purge Specimen Record', exact: true }).click();
    await expect(destructiveForm.locator('.fluent-validation-message')).toHaveCount(1);

    const samples = await page.evaluate(() => {
      type Color = { r: number; g: number; b: number; a: number };

      const parseColor = (value: string): Color => {
        if (value === 'transparent') {
          return { r: 0, g: 0, b: 0, a: 0 };
        }

        const match = value.match(/^rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)$/u);
        if (!match) {
          throw new Error(`Unsupported CSS color: ${value}`);
        }

        return {
          r: Number.parseFloat(match[1]),
          g: Number.parseFloat(match[2]),
          b: Number.parseFloat(match[3]),
          a: match[4] === undefined ? 1 : Number.parseFloat(match[4]),
        };
      };

      const luminance = (color: Color): number => {
        const normalize = (channel: number): number => {
          const value = channel / 255;
          return value <= 0.03928 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
        };

        return (0.2126 * normalize(color.r)) + (0.7152 * normalize(color.g)) + (0.0722 * normalize(color.b));
      };

      const contrastRatio = (foreground: string, background: string): number => {
        const foregroundLuminance = luminance(parseColor(foreground));
        const backgroundLuminance = luminance(parseColor(background));
        return (Math.max(foregroundLuminance, backgroundLuminance) + 0.05)
          / (Math.min(foregroundLuminance, backgroundLuminance) + 0.05);
      };

      const effectiveBackground = (element: Element): string => {
        for (let current: Element | null = element; current; current = current.parentElement) {
          const background = getComputedStyle(current).backgroundColor;
          if (parseColor(background).a > 0) {
            return background;
          }
        }

        return getComputedStyle(document.body).backgroundColor;
      };

      const query = (selectors: string[]): Element => {
        for (const selector of selectors) {
          const element = document.querySelector(selector);
          if (element) {
            return element;
          }
        }

        throw new Error(`Missing contrast sample target: ${selectors.join(', ')}`);
      };

      const sample = (selectors: string[]) => {
        const element = query(selectors);
        const foreground = getComputedStyle(element).color;
        const background = effectiveBackground(element);
        return {
          background,
          foreground,
          ratio: contrastRatio(foreground, background),
        };
      };

      // Story 13.3 — generated fields are Fluent editors (the label is the Fluent field label) and a
      // fail-closed command renders a denial card instead of a message bar.
      return {
        destructiveInput: sample(["[data-testid='fc-destructive-command-specimen'] .fc-command-field fluent-text-input"]),
        destructiveLabel: sample(["[data-testid='fc-destructive-command-specimen'] .fc-command-field fluent-field > label"]),
        destructiveValidationMessage: sample(["[data-testid='fc-destructive-command-specimen'] .fluent-validation-message"]),
        policyInput: sample(["[data-testid='fc-policy-command-specimen'] .fc-command-field fluent-text-input"]),
        policyLabel: sample(["[data-testid='fc-policy-command-specimen'] .fc-command-field fluent-field > label"]),
        policyDenialHeading: sample(["[data-testid='fc-policy-command-specimen'] [data-fc-authorization-denied] h2"]),
        policyDenialText: sample(["[data-testid='fc-policy-command-specimen'] [data-fc-authorization-denied] p"]),
      };
    });

    for (const [name, sample] of Object.entries(samples)) {
      expect(sample.ratio, `${name} contrast ${sample.foreground} on ${sample.background}`)
        .toBeGreaterThanOrEqual(minimumReadableTextContrast);
    }
    expect(samples.destructiveInput.foreground).toBe('rgb(20, 20, 20)');
    expect(samples.destructiveInput.background).toBe('rgb(255, 255, 255)');
    expect(samples.destructiveLabel.foreground).toBe('rgb(247, 247, 242)');
    expect(samples.destructiveValidationMessage.foreground).toBe('rgb(227, 125, 128)');
    expect(samples.policyInput.foreground).toBe('rgb(20, 20, 20)');
    expect(samples.policyInput.background).toBe('rgb(255, 255, 255)');
    expect(samples.policyLabel.foreground).toBe('rgb(247, 247, 242)');
    expect(samples.policyDenialHeading.foreground).toBe('rgb(59, 47, 0)');
    expect(samples.policyDenialText.foreground).toBe('rgb(59, 47, 0)');
    expect(samples.policyDenialText.background).toBe('rgb(255, 244, 206)');
  });

  // Touch activation (AC2) requires a touch-enabled browser context. The desktop projects
  // (chromium/firefox/webkit) run with hasTouch=false, so locator.tap() would throw
  // "The page does not support tap"; scope just this test to a touch-capable context.
  test.describe('status icon touch interactions', () => {
    test.use({ hasTouch: true });

    test('status icons expose contextual labels and reveal tooltips on focus, hover, and touch', async ({ page }) => {
      const route = getSpecimenRoute('type');
      await gotoSpecimen(page, route);

      const warningIcon = page.getByLabel(/Status.*Warning/u);
      await expect(warningIcon).toHaveAttribute('data-testid', 'fc-status-icon');
      await warningIcon.focus();
      await expect(page.locator('fluent-tooltip').filter({ hasText: 'Warning' })).toBeVisible();

      const dangerIcon = page.getByLabel(/Status.*Danger/u);
      await dangerIcon.hover();
      await expect(page.locator('fluent-tooltip').filter({ hasText: 'Danger' })).toBeVisible();

      await dangerIcon.tap();
      await expect(page.locator('fluent-tooltip').filter({ hasText: 'Danger' })).toBeVisible();
    });
  });

  test('data-formatting specimen renders deterministic text and accessible names', async ({ page }) => {
    const route = getSpecimenRoute('data-formatting');
    await gotoSpecimen(page, route);

    await expect(page.getByTestId('fc-data-formatting-specimen')).toHaveAttribute('data-culture', 'fr-FR');
    await expect(page.getByTestId('fc-format-row-locale-number')).toContainText('12 345,67');
    await expect(page.getByTestId('fc-format-row-absolute-timestamp')).toContainText('15/01/2026 13:45 UTC');
    await expect(page.getByTestId('fc-format-row-relative-timestamp')).toContainText('3 hours ago');
    await expect(page.getByTestId('fc-format-row-null-value')).toContainText('—');
    await expect(page.getByTestId('fc-format-row-currency')).toContainText('1 234,50 EUR');
    await expect(page.getByTestId('fc-format-row-boolean')).toContainText('Yes');
    await expect(page.getByLabel('Budget: 1 234,50 EUR')).toBeVisible();
    await expect(page.getByTestId('fc-generated-formatting-grid').locator("[data-fc-field='TotalOrders']").first()).toContainText(/12[\s\u202f]345,67/u);
    await expect(page.getByTestId('fc-generated-formatting-grid').locator("[data-fc-field='Budget']").first()).toContainText(/1[\s\u202f]234,50/u);
    await expect(page.getByTestId('fc-generated-formatting-grid').locator("[data-fc-field='OpaquePayload']").first()).toBeVisible();
  });

  test('keyboard flow reaches skip link, controls, grid, command form, detail, and nav without traps', async ({ page }) => {
    const route = getSpecimenRoute('type');
    await gotoSpecimen(page, route);

    await page.getByTestId('fc-specimen-skip').focus();
    await expect(page.locator(':focus')).toHaveAttribute('data-testid', 'fc-specimen-skip');

    const expected = [
      'fc-theme-control-light',
      'fc-theme-control-dark',
      'fc-density-control-compact',
      'fc-density-control-comfortable',
      'fc-density-control-roomy',
      'fc-command-input',
      'fc-command-number',
      'fc-command-submit',
      'fc-command-cancel',
      'fc-expanded-detail-summary',
      'fc-nav-foundation',
      'fc-nav-group-generated',
    ];

    for (const testId of expected) {
      await tabUntilTestId(page, testId);
      await expect(page.locator(':focus')).toBeInViewport();
    }

    await page.keyboard.press('Space');
    await expect(page.getByTestId('fc-nav-group-generated')).toHaveAttribute('aria-expanded', 'true');
    await page.keyboard.press('Escape');
    await expect(page.locator(':focus')).toBeVisible();
  });

  test('focus-visible indicator remains visible over lifecycle visuals', async ({ page }, testInfo) => {
    const route = getSpecimenRoute('type');
    await gotoSpecimen(page, route);
    // Initial route focus must finish before this keyboard-focus proof begins.
    await expect(page.locator('#fc-type-specimen-title')).toBeFocused();
    const submit = page.getByTestId('fc-command-submit');
    const amount = page.getByTestId('fc-command-number');
    await amount.focus();
    await expect(amount).toBeFocused();
    await page.keyboard.press('Tab');
    await expect(submit).toBeFocused();
    await expect.poll(() => submit.evaluate((element) =>
      document.activeElement === element
      && element.matches(':focus-visible')
      && getComputedStyle(element).outlineStyle !== 'none')).toBe(true);
    await page.screenshot({ path: testInfo.outputPath('focus-type-command-submit.png'), fullPage: false });
  });

  test('story 11.5 scoped Fluent-root visual hooks are reachable in normal and reduced motion', async ({ page, browserName }) => {
    test.skip(browserName !== 'chromium', 'Computed-style pins (0.7s / 24 / alternate) and emulateMedia reduced-motion are Chromium-serialized; the gated a11y lane runs chromium only.');
    const route = getSpecimenRoute('type');
    await page.setViewportSize({ width: 420, height: 900 });
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await gotoSpecimen(page, route);

    await page.getByTestId('fc-settings-button').click();
    await expect(page.getByTestId('fc-settings-dialog')).toBeVisible();
    await page.getByRole('button', { name: /^(Aperçu|Preview)$/u }).click();

    const preview = page.getByTestId('fc-density-preview');
    await expect(preview).toBeVisible();
    const previewStyles = await preview.evaluate((element) => {
      const styles = getComputedStyle(element);
      return {
        borderStyle: styles.borderTopStyle,
        paddingTop: Number.parseFloat(styles.paddingTop),
      };
    });
    expect(previewStyles.borderStyle).not.toBe('none');
    expect(previewStyles.paddingTop).toBeGreaterThan(0);

    const footerBox = await page.locator('.fc-settings-footer').boundingBox();
    const doneBox = await page.getByTestId('fc-settings-done').boundingBox();
    expect(footerBox).not.toBeNull();
    expect(doneBox).not.toBeNull();
    expect(doneBox!.width).toBeGreaterThan(footerBox!.width * 0.9);

    const pulseProof = await page.evaluate(() => {
      const collectRules = (rules: CSSRuleList): CSSRule[] => {
        const collected: CSSRule[] = [];
        for (const rule of Array.from(rules)) {
          collected.push(rule);
          if ('cssRules' in rule) {
            collected.push(...collectRules((rule as CSSGroupingRule).cssRules));
          }
        }

        return collected;
      };

      const styleRules = Array.from(document.styleSheets)
        .flatMap((sheet) => {
          try {
            return collectRules(sheet.cssRules);
          } catch {
            return [];
          }
        })
        .filter((rule): rule is CSSStyleRule => rule instanceof CSSStyleRule);

      const selector = styleRules
        .map((rule) => rule.selectorText)
        .find((text) => text.includes('.fc-projection-connection-status-host')
          && text.includes('.fc-projection-connection-status-pulse'));
      const scopeAttribute = selector?.match(/\.fc-projection-connection-status-host\[([^\]=]+)(?:=[^\]]+)?\]/u)?.[1];
      if (!scopeAttribute) {
        throw new Error('Projection connection status scoped selector was not present in the browser CSSOM.');
      }

      const host = document.createElement('div');
      host.className = 'fc-projection-connection-status-host';
      host.setAttribute('data-testid', 'fc-story-11-5-pulse-proof');
      host.setAttribute(scopeAttribute, '');
      const pulse = document.createElement('div');
      pulse.className = 'fc-projection-connection-status fc-projection-connection-status-pulse';
      host.append(pulse);
      document.body.append(host);
      const styles = getComputedStyle(pulse);
      return {
        animationDirection: styles.animationDirection,
        animationDuration: styles.animationDuration,
        animationIterationCount: styles.animationIterationCount,
        animationName: styles.animationName,
        reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
      };
    });

    try {
      expect(pulseProof.reducedMotion).toBe(false);
      // Blazor CSS isolation scopes the @keyframes name with a `-b-<hash>` suffix in the bundled
      // stylesheet (observed: `fc-sync-status-pulse-b-<hash>`), so match the prefix, not an exact name.
      expect(pulseProof.animationName).toMatch(/^fc-sync-status-pulse(?:-|$)/u);
      expect(pulseProof.animationDuration).toBe('0.7s');
      expect(pulseProof.animationIterationCount).toBe('24');
      expect(pulseProof.animationDirection).toBe('alternate');

      await page.emulateMedia({ reducedMotion: 'reduce' });
      const reducedPulseProof = await page
        .getByTestId('fc-story-11-5-pulse-proof')
        .locator('.fc-projection-connection-status-pulse')
        .evaluate((element) => {
          const styles = getComputedStyle(element);
          return {
            animationDuration: styles.animationDuration,
            animationName: styles.animationName,
            reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
          };
        });

      expect(reducedPulseProof.reducedMotion).toBe(true);
      expect(reducedPulseProof.animationName).toBe('none');
      expect(reducedPulseProof.animationDuration).toBe('0s');
    } finally {
      await page.evaluate(() => document.querySelector('[data-testid="fc-story-11-5-pulse-proof"]')?.remove());
    }
  });

  test('forced-colors and reduced-motion states are active and perceivable', async ({ browser }) => {
    const context = await browser.newContext({
      baseURL: process.env.BASE_URL ?? 'http://127.0.0.1:5070',
      forcedColors: 'active',
      reducedMotion: 'reduce',
      ignoreHTTPSErrors: true,
    });
    const page = await context.newPage();
    const guards = attachSpecimenGuards(page);

    const route = getSpecimenRoute('type');
    await gotoSpecimen(page, route);

    await expect(page.locator(route.readySelector)).toBeVisible();
    await expect(page.getByLabel(/Status.*Warning/u)).toHaveAttribute('data-fc-badge-slot', 'Warning');
    await expect(page.getByTestId('fc-lifecycle-confirmed-rejected')).toContainText('rejection');
    expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(true);
    expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toBe(true);

    const freshRowProof = await page.evaluate(() => {
      const collect = (rules: CSSRuleList): CSSRule[] => Array.from(rules).flatMap((rule) =>
        'cssRules' in rule ? [rule, ...collect((rule as CSSGroupingRule).cssRules)] : [rule]);
      const rules = Array.from(document.styleSheets).flatMap((sheet) => {
        try { return collect(sheet.cssRules); } catch { return []; }
      });
      const selector = rules.filter((rule): rule is CSSStyleRule => rule instanceof CSSStyleRule)
        .map((rule) => rule.selectorText).find((text) => text.includes('.fc-new-item-indicator['));
      const scope = selector?.match(/\.fc-new-item-indicator\[([^\]=]+)(?:=[^\]]+)?\]/u)?.[1];
      if (!scope) throw new Error('Fresh-row indicator scoped CSS is absent.');
      const cue = document.createElement('div');
      cue.className = 'fc-new-item-indicator';
      cue.setAttribute(scope, '');
      cue.style.width = '240px';
      cue.textContent = `Updated row: ${'longidentifier'.repeat(32)}.`;
      document.body.append(cue);
      try {
        const styles = getComputedStyle(cue);
        const system = document.createElement('div');
        system.style.borderInlineStart = '3px solid CanvasText';
        document.body.append(system);
        const systemColor = getComputedStyle(system).borderInlineStartColor;
        system.remove();
        return { borderColor: styles.borderInlineStartColor, systemColor,
          borderStyle: styles.borderInlineStartStyle, borderWidth: styles.borderInlineStartWidth,
          backgroundImage: styles.backgroundImage, animationName: styles.animationName,
          transitionDuration: styles.transitionDuration, forcedColorAdjust: styles.forcedColorAdjust,
          longIdentifierWraps: cue.scrollWidth <= cue.clientWidth && cue.getBoundingClientRect().height > 40 };
      } finally { cue.remove(); }
    });
    expect(freshRowProof.borderColor).toBe(freshRowProof.systemColor);
    expect(freshRowProof.borderStyle).toBe('solid');
    expect(freshRowProof.borderWidth).toBe('3px');
    expect(freshRowProof.backgroundImage).toBe('none');
    expect(freshRowProof.animationName).toBe('none');
    expect(freshRowProof.transitionDuration).toBe('0s');
    expect(freshRowProof.forcedColorAdjust).not.toBe('none');
    expect(freshRowProof.longIdentifierWraps).toBe(true);

    await page.getByTestId('fc-command-submit').focus();
    const outlineColor = await page.getByTestId('fc-command-submit').evaluate((element) => getComputedStyle(element).outlineColor);
    expect(outlineColor).toBeTruthy();
    expect(guards.consoleErrors, `Unhandled browser console errors:\n${guards.consoleErrors.join('\n')}`).toEqual([]);
    expect(guards.unexpectedRequests, `Unexpected network calls:\n${guards.unexpectedRequests.join('\n')}`).toEqual([]);
    await context.close();
  });

  for (const scale of [1, 2, 4] as const) {
    test(`viewport reflow keeps critical controls reachable at ${Math.floor(1280 / scale)} CSS pixels (not browser zoom)`, async ({ page }) => {
      const route = getSpecimenRoute('type');
      await page.setViewportSize({ width: Math.floor(1280 / scale), height: 900 });
      await gotoSpecimen(page, route);

      await scrollTestIdIntoView(page, 'fc-command-submit');
      await scrollTestIdIntoView(page, 'fc-multi-level-nav');
      const horizontalOverflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(horizontalOverflow).toBeLessThanOrEqual(1);
    });
  }

  for (const combination of specimenManifest.themeDensityCombinations) {
    test(`visual baseline ${combination.theme} ${combination.density}`, async ({ page }) => {
      await page.goto(`/__frontcomposer/specimens/type?theme=${combination.theme}&density=${combination.density}`);
      await expect(page.getByTestId('fc-type-specimen')).toBeVisible();
      await prepareSpecimenVisualBaseline(page);
      await expect(page).toHaveScreenshot(combination.artifact, {
        fullPage: true,
        animations: 'disabled',
        // Linux baselines are regenerated locally. Windows baselines come from CI
        // artifacts, so keep the semantic contrast guard strict and allow only a
        // narrow Windows text-rasterization delta calibrated from the CSS fix.
        ...(process.platform === 'win32' ? { maxDiffPixels: windowsVisualBaselineMaxDiffPixels } : {}),
      });
    });
  }

  test('production-style route exposure fails closed when specimen host configuration is absent', async ({ playwright }) => {
    const port = 5071;
    const server = spawn('dotnet', [
      'run',
      '--project',
      '../../samples/Counter/Counter.Web/Counter.Web.csproj',
      '--configuration',
      process.env.FC_E2E_BUILD_CONFIGURATION ?? 'Release',
      '--no-build',
      '--no-launch-profile',
      '--urls',
      `http://127.0.0.1:${port}`,
    ], {
      cwd: process.cwd(),
      env: {
        ...process.env,
        ASPNETCORE_ENVIRONMENT: 'Production',
        Hexalith__FrontComposer__Specimens__Enabled: '',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let serverOutput = '';
    server.stdout.on('data', (chunk) => { serverOutput += chunk.toString(); });
    server.stderr.on('data', (chunk) => { serverOutput += chunk.toString(); });

    const api = await playwright.request.newContext({ baseURL: `http://127.0.0.1:${port}` });
    try {
      await waitForHost(api);
      const response = await api.get('/__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true', { failOnStatusCode: false });
      expect(response.status(), `Specimen route was exposed without explicit configuration.\n${serverOutput}`).toBeGreaterThanOrEqual(400);
    } finally {
      await api.dispose();
      server.kill();
    }
  });
});

const attachSpecimenGuards = (page: import('@playwright/test').Page) => {
  const consoleErrors: string[] = [];
  const unexpectedRequests: string[] = [];

  page.on('console', (message) => {
    if (message.type() === 'error') {
      if (message.text() === 'Failed to load resource: the server responded with a status of 404 (Not Found)') {
        return;
      }

      consoleErrors.push(message.text());
    }
  });

  page.on('request', (request) => {
    const url = new URL(request.url());
    const path = url.pathname;
    const allowed = path.startsWith('/_framework/')
      || path.startsWith('/_content/')
      || path.startsWith('/_blazor')
      || path.startsWith('/css/')
      || path.startsWith('/js/')
      || path.startsWith('/__frontcomposer/specimens/')
      || path === '/Counter.Web.styles.css'
      || path === '/'
      || path === '/favicon.ico';

    if (!allowed) {
      unexpectedRequests.push(`${request.method()} ${url.pathname}`);
    }
  });

  consoleErrorsByPage.set(page, consoleErrors);
  unexpectedRequestsByPage.set(page, unexpectedRequests);
  return { consoleErrors, unexpectedRequests };
};

const gotoSpecimen = async (page: import('@playwright/test').Page, route: SpecimenRoute): Promise<void> => {
  await page.goto(route.path);
  await expect(page.locator(route.readySelector), `${route.path} missing ready marker`).toBeVisible();
  await page.waitForFunction(() => [...document.querySelectorAll('*')]
    .filter((element) => element.localName.includes('-'))
    .every((element) => customElements.get(element.localName) !== undefined));
  await expect(page.locator('.fc-shell-root')).toHaveAttribute('data-fc-interactive', 'true');
  for (const form of await page.locator('.fc-command-form').all()) {
    await waitForGeneratedFormReady(form);
  }
  if (route.name === 'type') {
    for (const section of ['fc-destructive-command-specimen', 'fc-policy-command-specimen']) {
      const form = page.getByTestId(section).locator('.fc-command-form');
      await expect(fieldEditorByLabel(form, 'Record Id')).toHaveAccessibleName(/^Record Id(?:,.*)?$/u);
      await expect(fieldEditorByLabel(form, 'Reason')).toHaveAccessibleName(/^Reason(?:,.*)?$/u);
    }
    await expect(page.getByTestId('fc-destructive-command-specimen')
      .getByRole('combobox', { name: 'Retention', exact: true })).toHaveAttribute('aria-expanded', 'false');
  }
  for (const selector of route.requiredSections) {
    const count = await page.locator(selector).count();
    expect(count, `${route.path} missing ${selector}`).toBeGreaterThan(0);
  }
};

const prepareSpecimenVisualBaseline = async (page: import('@playwright/test').Page): Promise<void> => {
  await expect(page.locator('.fc-shell-root')).toHaveAttribute('data-fc-interactive', 'true');
  // The cleared desktop fixture uses the shell's Compact factory density; the query's density
  // controls the specimen cards separately. Wait for the real shell projection before capture.
  await expect(page.locator('body')).toHaveAttribute('data-fc-density', 'compact');
  await page.waitForFunction(() => [...document.querySelectorAll('*')]
    .filter((element) => element.localName.includes('-'))
    .every((element) => customElements.get(element.localName) !== undefined));
  await page.evaluate(() => document.fonts.ready);

  await page.addStyleTag({
    content: `
      .pa-3.fluent-layout-item {
        overflow: visible !important;
        height: auto !important;
        max-height: none !important;
      }

      .fc-shell-root,
      fluent-layout,
      .fluent-layout {
        height: auto !important;
        min-height: auto !important;
        overflow: visible !important;
      }
    `,
  });

  await page.evaluate(() => {
    window.scrollTo(0, 0);
    for (const element of document.querySelectorAll<HTMLElement>('.fluent-layout-item')) {
      element.scrollTop = 0;
    }
  });
  await expect(page.getByTestId('fc-type-specimen')).toBeInViewport();

  let previousHeight = -1;
  let stableSamples = 0;
  await expect.poll(async () => {
    const height = await page.evaluate(() => document.documentElement.scrollHeight);
    stableSamples = height === previousHeight ? stableSamples + 1 : 0;
    previousHeight = height;
    return stableSamples;
  }, {
    message: 'the upgraded Fluent/Chromium specimen layout must settle before visual capture',
    timeout: 10_000,
    intervals: [100, 100, 250, 250],
  }).toBeGreaterThanOrEqual(2);
};

const scrollTestIdIntoView = async (page: import('@playwright/test').Page, testId: string): Promise<void> => {
  await expect(async () => {
    const locator = page.getByTestId(testId);
    await expect(locator).toHaveCount(1);
    await locator.scrollIntoViewIfNeeded();
    await expect(locator).toBeInViewport();
  }).toPass({ timeout: 5_000 });
};

const tabUntilTestId = async (page: import('@playwright/test').Page, testId: string): Promise<void> => {
  for (let attempt = 0; attempt < 30; attempt += 1) {
    await page.keyboard.press('Tab');
    // Fluent editors focus a control inside their shadow root, so `:focus` can match both the host
    // and its inner input; the document's active element is always the single light-DOM host.
    const focusedTestId = await page.evaluate(() => document.activeElement?.getAttribute('data-testid') ?? null);
    if (focusedTestId === testId) {
      return;
    }
  }

  throw new Error(`Expected focus to reach ${testId}`);
};

const waitForHost = async (request: import('@playwright/test').APIRequestContext): Promise<void> => {
  const deadline = Date.now() + 60_000;
  let lastError: unknown;
  while (Date.now() < deadline) {
    try {
      const response = await request.get('/', { failOnStatusCode: false, timeout: 2_000 });
      if (response.status() < 500) {
        return;
      }
    } catch (error) {
      lastError = error;
    }

    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  throw new Error(`Counter production smoke host did not start: ${String(lastError)}`);
};
