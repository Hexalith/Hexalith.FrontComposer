# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> review actual placeholder pseudo composition rejects filters
- Location: specs/responsive-accessibility.spec.ts:1095:3

# Error details

```
Error: expect(received).rejects.toThrow()

Received promise resolved instead of rejected
Resolved to value: [{"background": [255, 255, 255, 1], "foreground": [0, 0, 0, 1], "minimum": 4.5, "node": "input", "owner": 0, "paint": "input placeholder", "ratio": 21}]
```

# Page snapshot

```yaml
- textbox "Label" [ref=e2]
```

# Test source

```ts
  1002 |   const settings = page.getByTestId('fc-palette-trigger');
  1003 |   await expect(settings).toBeFocused();
  1004 |   const proof = await page.evaluate(() => {
  1005 |     const state = (window as typeof window & { __aeVendorReturn: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } }).__aeVendorReturn;
  1006 |     state.restore();
  1007 |     const proof = { queued: state.callbacks.length, cleared: state.host.previousActiveElement === null };
  1008 |     for (const callback of state.callbacks) callback();
  1009 |     return proof;
  1010 |   });
  1011 |   expect(proof.queued).toBeGreaterThan(0);
  1012 |   expect(proof.cleared).toBe(true);
  1013 |   await expect(settings).toBeFocused();
  1014 | });
  1015 | 
  1016 | 
  1017 | test('reused owned dialog dismissal resets only its current return and preserves later external input', async ({ page }) => {
  1018 |   await page.goto('/counter');
  1019 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1020 |   await page.evaluate(async () => {
  1021 |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  1022 |     const focus = await import(path) as { containDialogFocus: (testId: string) => boolean };
  1023 |     const host = document.createElement('fluent-dialog');
  1024 |     host.hidden = true;
  1025 |     host.innerHTML = '<div data-testid="fc-settings-dialog"></div>';
  1026 |     document.body.append(host);
  1027 |     const w = window as typeof window & { __fcModalReservation?: { watchFocus: boolean; moved: boolean }; __fcOverlayOpenIntent?: { watchFocus: boolean; moved: boolean } };
  1028 |     for (let opening = 0; opening < 2; opening++) {
  1029 |       document.querySelector<HTMLElement>('[data-testid="fc-palette-trigger"]')!.focus();
  1030 |       const reservation = { watchFocus: true, moved: true };
  1031 |       const intent = { watchFocus: true, moved: true };
  1032 |       w.__fcModalReservation = reservation;
  1033 |       w.__fcOverlayOpenIntent = intent;
  1034 |       if (!focus.containDialogFocus('fc-settings-dialog')) throw new Error('reused host containment failed');
  1035 |       host.dispatchEvent(new CustomEvent('beforetoggle', { detail: { newState: 'closed' } }));
  1036 |       if (reservation.watchFocus || reservation.moved || intent.watchFocus || intent.moved) throw new Error('native return retained modal input tracking');
  1037 |       document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
  1038 |       document.querySelector<HTMLElement>('[data-testid="fc-settings-button"]')!.focus();
  1039 |       if (!reservation.watchFocus || !reservation.moved || !intent.watchFocus || !intent.moved) throw new Error('later external input was discarded');
  1040 |     }
  1041 |     delete w.__fcModalReservation;
  1042 |     delete w.__fcOverlayOpenIntent;
  1043 |     host.remove();
  1044 |   });
  1045 | });
  1046 | 
  1047 | test('forced-color replacement capability is recorded for its engine and run', async ({ page }, info) => {
  1048 |   await page.setContent('<span style="color:rgb(255,0,0);background:rgb(0,255,0);forced-color-adjust:auto">Capability</span>');
  1049 |   await page.emulateMedia({ forcedColors: 'active' });
  1050 |   const forced = await page.locator('span').evaluate(element => {
  1051 |     const css = getComputedStyle(element);
  1052 |     return { forcedColors: matchMedia('(forced-colors: active)').matches, color: css.color, background: css.backgroundColor };
  1053 |   });
  1054 |   const authoredColorReplacement = forced.color !== 'rgb(255, 0, 0)' && forced.background !== 'rgb(0, 255, 0)';
  1055 |   if (!authoredColorReplacement) expect(info.project.name).toBe('webkit');
  1056 |   const path = info.outputPath(`forced-colors-capability-${info.project.name}.json`);
  1057 |   await (await import('node:fs/promises')).writeFile(path, JSON.stringify({ engine: info.project.name, runId: process.env.FC_A11Y_EVIDENCE_RUN_ID, testId: info.testId, attempt: info.retry, authoredColorReplacement, forced }));
  1058 |   await info.attach('forced-color-capability', { path, contentType: 'application/json' });
  1059 | });
  1060 | 
  1061 | 
  1062 | test('desktop rail flyout controls fit both 72px and 48px rails without horizontal scrolling', async ({ page }) => {
  1063 |   await page.setViewportSize({ width: 1600, height: 900 });
  1064 |   await page.goto('/__frontcomposer/specimens/type?density=compact');
  1065 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1066 |   const rail = page.getByTestId('fc-shell-navigation').getByTestId('fc-navigation-rail');
  1067 |   for (const width of [72, 48]) {
  1068 |     if (width === 48) await page.getByTestId('fc-hamburger-toggle').click();
  1069 |     await expect(rail).toHaveAttribute('data-rail-width', String(width));
  1070 |     await expect.poll(async () => (await rail.boundingBox())?.width).toBe(width);
  1071 |     for (const forcedColors of ['none', 'active'] as const) {
  1072 |       await page.emulateMedia({ forcedColors });
  1073 |       await expectNoPageOverflow(page);
  1074 |       const regions = await page.getByTestId('fc-shell-navigation').evaluate(element => ({ client: element.clientWidth, scroll: element.scrollWidth }));
  1075 |       expect(regions.scroll).toBeLessThanOrEqual(regions.client + 1);
  1076 |       await expect(rail.locator('[data-testid="fc-nav-flyout-trigger-Counter"]')).toHaveAttribute('icon-only', '');
  1077 |     }
  1078 |   }
  1079 | });
  1080 | 
  1081 | 
  1082 | for (const shape of ['line', 'path']) for (const axis of ['horizontal', 'vertical']) {
  1083 |   test(`review axis-aligned SVG ${shape} ${axis} retains its painted stroke envelope`, async ({ page }) => {
  1084 |     const points = axis === 'horizontal' ? 'x1="40" y1="20" x2="80" y2="20"' : 'x1="60" y1="5" x2="60" y2="35"';
  1085 |     const line = shape === 'line' ? `<line ${points}/>` : `<path d="${axis === 'horizontal' ? 'M40 20H80' : 'M60 5V35'}"/>`;
  1086 |     await page.setContent(`<svg width="100" height="40" style="background:white"><rect width="20" height="20" fill="black"/><g fill="none" stroke="#eee" stroke-width="3">${line}</g></svg>`);
  1087 |     await expect(expectSurfaceContrast(page.locator('svg'), 'icon')).rejects.toThrow(/contrast failures/);
  1088 |     await page.locator('g').evaluate(node => node.setAttribute('stroke', 'black'));
  1089 |     const samples = await expectSurfaceContrast(page.locator('svg'), 'icon');
  1090 |     expect(samples.some(sample => sample.node === shape && sample.paint === 'icon stroke')).toBe(true);
  1091 |   });
  1092 | }
  1093 | 
  1094 | for (const kind of ['generated', 'placeholder', 'focus']) {
  1095 |   test(`review actual ${kind} pseudo composition rejects filters`, async ({ page }) => {
  1096 |     const markup = kind === 'generated' ? '<style>div::before{content:"Label";color:black;filter:brightness(0)}</style><div style="background:white"></div>'
  1097 |       : kind === 'placeholder' ? '<style>input::placeholder{color:black;opacity:1;filter:brightness(0)}</style><input placeholder="Label" style="background:white">'
  1098 |       : '<style>button{position:relative;margin:40px;background:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black;filter:brightness(0)}</style><button>Action</button>';
  1099 |     await page.setContent(markup);
  1100 |     const target = page.locator(kind === 'generated' ? 'div' : kind === 'placeholder' ? 'input' : 'button');
  1101 |     if (kind === 'focus') await target.focus();
> 1102 |     await expect(measureSurfaceContrast(target, kind === 'focus' ? 'focus' : 'text')).rejects.toThrow(/Filtered or blended/);
       |                                                                                               ^ Error: expect(received).rejects.toThrow()
  1103 |     if (kind === 'focus') await expect(focusGeometry(target)).rejects.toThrow(/Filtered or blended/);
  1104 |     await page.addStyleTag({ content: '*::before,*::after,*::placeholder{filter:none!important}' });
  1105 |     await expectSurfaceContrast(target, kind === 'focus' ? 'focus' : 'text');
  1106 |   });
  1107 | }
  1108 | 
  1109 | test('review generated glyphs outside their host require pixel evidence', async ({ page }) => {
  1110 |   await page.setContent('<style>body{background:black}div{position:relative;background:white;color:black;width:100px;height:40px}div::before{content:"Label";position:absolute;left:120px}</style><div></div>');
  1111 |   await expect(measureSurfaceContrast(page.locator('div'))).rejects.toThrow(/Generated text geometry/);
  1112 |   await page.addStyleTag({ content: 'div::before{position:static}' });
  1113 |   await expectSurfaceContrast(page.locator('div'));
  1114 | });
  1115 | 
  1116 | for (const style of ['position:relative;top:40px', 'position:sticky;top:0', 'transform:translateY(40px)', '']) {
  1117 |   test(`review overlapping sibling backgrounds require evidence ${style || 'static negative margin'}`, async ({ page }) => {
  1118 |     await page.setContent(`<div style="background:white"><div id="under" style="background:black;height:40px;${style}"></div><p style="position:relative;margin-top:${style.includes('40px') ? '0' : '-32px'};color:black">Label</p></div>`);
  1119 |     await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/Overlapping sibling background/);
  1120 |     await page.locator('#under').evaluate(node => node.remove());
  1121 |     await expectSurfaceContrast(page.locator('p'));
  1122 |   });
  1123 | }
  1124 | 
  1125 | test('review a sharp shadow concealed by its opaque control is not focus paint', async ({ page }) => {
  1126 |   await page.setContent('<style>button{width:100px;height:40px;margin:40px;border:0;border-radius:0;background:white;outline:none}button:focus{box-shadow:1px 0 0 -2px black}</style><button>Action</button>');
  1127 |   await page.locator('button').focus();
  1128 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  1129 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  1130 |   await page.addStyleTag({ content: 'button:focus{box-shadow:4px 0 0 -2px black}' });
  1131 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  1132 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1133 | });
  1134 | 
  1135 | test('review permanent pseudo background cannot certify a same-color focus border', async ({ page }) => {
  1136 |   await page.setContent('<style>button{position:relative;margin:40px;background:white;outline:none}button::after{content:"";position:absolute;inset:0;background:black;border:2px solid transparent}button:focus::after{border-color:black}</style><button>Action</button>');
  1137 |   await page.locator('button').focus();
  1138 |   await expect(focusGeometry(page.locator('button'))).rejects.toThrow(/Pseudo focus background/);
  1139 |   await expect(measureSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Pseudo focus background/);
  1140 |   await page.addStyleTag({ content: 'button::after{background:transparent}' });
  1141 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  1142 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1143 | });
  1144 | 
  1145 | test('review margin-shifted pseudo borders use the backdrop outside their host', async ({ page }) => {
  1146 |   await page.setContent('<style>body{background:black}button{position:relative;margin:40px;width:100px;height:40px;background:white;outline:none}button:focus::after{content:"";position:absolute;left:0;top:0;width:100px;height:40px;box-sizing:border-box;margin-left:120px;border:2px solid black}</style><button>Action</button>');
  1147 |   await page.locator('button').focus();
  1148 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  1149 |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  1150 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1151 | });
  1152 | 
  1153 | test('review transformed static descendants remain focus obstructions', async ({ page }) => {
  1154 |   await page.setContent('<style>button{margin:40px;width:100px;height:40px;outline:none}button:focus{outline:2px solid black}span{display:block;width:120px;height:60px;background:white;transform:translate(-12px,-24px)}</style><button>Action<span></span></button>');
  1155 |   await page.locator('button').focus();
  1156 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  1157 |   await page.locator('span').evaluate(node => { node.style.transform = 'none'; node.style.width = node.style.height = '10px'; });
  1158 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  1159 | });
  1160 | 
  1161 | test('review generated large text uses the existing 3 to 1 threshold', async ({ page }) => {
  1162 |   await page.setContent('<style>div{background:white}div::before{content:"Large label";font-size:32px;color:#888}</style><div></div>');
  1163 |   const samples = await expectSurfaceContrast(page.locator('div'));
  1164 |   expect(samples[0].minimum).toBe(3);
  1165 |   expect(samples[0].ratio).toBeGreaterThan(3.5);
  1166 |   expect(samples[0].ratio).toBeLessThan(3.6);
  1167 |   await page.addStyleTag({ content: 'div::before{color:#aaa}' });
  1168 |   await expect(expectSurfaceContrast(page.locator('div'))).rejects.toThrow(/contrast failures/);
  1169 | });
  1170 | 
  1171 | test('review recorded operator focus on SVG survives deferred overlay restoration', async ({ page }) => {
  1172 |   await page.goto('/counter');
  1173 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1174 |   await page.evaluate(async () => {
  1175 |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  1176 |     const focus = await import(path) as { restoreOverlayOrigin: () => void };
  1177 |     const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  1178 |     svg.setAttribute('tabindex', '0'); svg.id = 'operator-svg'; document.body.append(svg); svg.focus();
  1179 |     const w = window as typeof window & { __fcOverlayOrigin?: Element; __fcModalReservation?: { moved: boolean } };
  1180 |     w.__fcOverlayOrigin = document.querySelector('[data-testid="fc-palette-trigger"]')!;
  1181 |     w.__fcModalReservation = { moved: true };
  1182 |     focus.restoreOverlayOrigin();
  1183 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  1184 |   });
  1185 |   await expect(page.locator('#operator-svg')).toBeFocused();
  1186 | });
  1187 | 
```