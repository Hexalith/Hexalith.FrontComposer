# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> review recorded operator focus on SVG survives deferred overlay restoration
- Location: specs/responsive-accessibility.spec.ts:1171:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('#operator-svg')
Expected: focused
Received: inactive
Timeout:  10000ms

Call log:
  - Expect "toBeFocused" locator('#operator-svg') with timeout 10000ms
  - waiting for locator('#operator-svg')
    24 × locator resolved to <svg tabindex="0" id="operator-svg"></svg>
       - unexpected value "inactive"

```

```yaml
- img
```

# Test source

```ts
  1085 |     const line = shape === 'line' ? `<line ${points}/>` : `<path d="${axis === 'horizontal' ? 'M40 20H80' : 'M60 5V35'}"/>`;
  1086 |     await page.setContent(`<svg width="100" height="40" style="background:white"><rect width="20" height="20" fill="black"/><g fill="none" stroke="#eee" stroke-width="3">${line}</g></svg>`);
  1087 |     await expect(expectSurfaceContrast(page.locator('svg'), 'icon')).rejects.toThrow(/contrast failures/);
  1088 |     await page.locator('g').evaluate(node => node.setAttribute('stroke', 'black'));
  1089 |     const samples = await expectSurfaceContrast(page.locator('svg'), 'icon');
  1090 |     expect(samples.some(sample => sample.node === shape && sample.paint === 'icon stroke')).toBe(true);
  1091 |   });
  1092 | }
  1093 | 
  1094 | for (const kind of ['generated', 'placeholder', 'focus']) {
  1095 |   test(`review actual ${kind} pseudo composition rejects filters`, async ({ page }) => {
  1096 |     const markup = kind === 'generated' ? '<style>div::before{content:"Label";color:black;filter:brightness(0)}</style><div style="background:white"></div>'
  1097 |       : kind === 'placeholder' ? '<style>input::placeholder{color:black;opacity:1;filter:brightness(0)}</style><input placeholder="Label" style="background:white">'
  1098 |       : '<style>button{position:relative;margin:40px;background:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black;filter:brightness(0)}</style><button>Action</button>';
  1099 |     await page.setContent(markup);
  1100 |     const target = page.locator(kind === 'generated' ? 'div' : kind === 'placeholder' ? 'input' : 'button');
  1101 |     if (kind === 'focus') await target.focus();
  1102 |     await expect(measureSurfaceContrast(target, kind === 'focus' ? 'focus' : 'text')).rejects.toThrow(/Filtered or blended/);
  1103 |     if (kind === 'focus') await expect(focusGeometry(target)).rejects.toThrow(/Filtered or blended/);
  1104 |     await page.addStyleTag({ content: '*::before,*::after,*::placeholder{filter:none!important}' });
  1105 |     await expectSurfaceContrast(target, kind === 'focus' ? 'focus' : 'text');
  1106 |   });
  1107 | }
  1108 | 
  1109 | test('review generated glyphs outside their host require pixel evidence', async ({ page }) => {
  1110 |   await page.setContent('<style>body{background:black}div{position:relative;background:white;color:black;width:100px;height:40px}div::before{content:"Label";position:absolute;left:120px}</style><div></div>');
  1111 |   await expect(measureSurfaceContrast(page.locator('div'))).rejects.toThrow(/Generated text geometry/);
  1112 |   await page.addStyleTag({ content: 'div::before{position:static}' });
  1113 |   await expectSurfaceContrast(page.locator('div'));
  1114 | });
  1115 | 
  1116 | for (const style of ['position:relative;top:40px', 'position:sticky;top:0', 'transform:translateY(40px)', '']) {
  1117 |   test(`review overlapping sibling backgrounds require evidence ${style || 'static negative margin'}`, async ({ page }) => {
  1118 |     await page.setContent(`<div style="background:white"><div id="under" style="background:black;height:40px;${style}"></div><p style="position:relative;margin-top:${style.includes('40px') ? '0' : '-32px'};color:black">Label</p></div>`);
  1119 |     await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/Overlapping sibling background/);
  1120 |     await page.locator('#under').evaluate(node => node.remove());
  1121 |     await expectSurfaceContrast(page.locator('p'));
  1122 |   });
  1123 | }
  1124 | 
  1125 | test('review a sharp shadow concealed by its opaque control is not focus paint', async ({ page }) => {
  1126 |   await page.setContent('<style>button{width:100px;height:40px;margin:40px;border:0;border-radius:0;background:white;outline:none}button:focus{box-shadow:1px 0 0 -2px black}</style><button>Action</button>');
  1127 |   await page.locator('button').focus();
  1128 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  1129 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  1130 |   await page.addStyleTag({ content: 'button:focus{box-shadow:4px 0 0 -2px black}' });
  1131 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  1132 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1133 | });
  1134 | 
  1135 | test('review permanent pseudo background cannot certify a same-color focus border', async ({ page }) => {
  1136 |   await page.setContent('<style>button{position:relative;margin:40px;background:white;outline:none}button::after{content:"";position:absolute;inset:0;background:black;border:2px solid transparent}button:focus::after{border-color:black}</style><button>Action</button>');
  1137 |   await page.locator('button').focus();
  1138 |   await expect(focusGeometry(page.locator('button'))).rejects.toThrow(/Pseudo focus background/);
  1139 |   await expect(measureSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Pseudo focus background/);
  1140 |   await page.addStyleTag({ content: 'button::after{background:transparent}' });
  1141 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  1142 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1143 | });
  1144 | 
  1145 | test('review margin-shifted pseudo borders use the backdrop outside their host', async ({ page }) => {
  1146 |   await page.setContent('<style>body{background:black}button{position:relative;margin:40px;width:100px;height:40px;background:white;outline:none}button:focus::after{content:"";position:absolute;left:0;top:0;width:100px;height:40px;box-sizing:border-box;margin-left:120px;border:2px solid black}</style><button>Action</button>');
  1147 |   await page.locator('button').focus();
  1148 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  1149 |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  1150 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  1151 | });
  1152 | 
  1153 | test('review transformed static descendants remain focus obstructions', async ({ page }) => {
  1154 |   await page.setContent('<style>button{margin:40px;width:100px;height:40px;outline:none}button:focus{outline:2px solid black}span{display:block;width:120px;height:60px;background:white;transform:translate(-12px,-24px)}</style><button>Action<span></span></button>');
  1155 |   await page.locator('button').focus();
  1156 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  1157 |   await page.locator('span').evaluate(node => { node.style.transform = 'none'; node.style.width = node.style.height = '10px'; });
  1158 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  1159 | });
  1160 | 
  1161 | test('review generated large text uses the existing 3 to 1 threshold', async ({ page }) => {
  1162 |   await page.setContent('<style>div{background:white}div::before{content:"Large label";font-size:32px;color:#888}</style><div></div>');
  1163 |   const samples = await expectSurfaceContrast(page.locator('div'));
  1164 |   expect(samples[0].minimum).toBe(3);
  1165 |   expect(samples[0].ratio).toBeGreaterThan(3.5);
  1166 |   expect(samples[0].ratio).toBeLessThan(3.6);
  1167 |   await page.addStyleTag({ content: 'div::before{color:#aaa}' });
  1168 |   await expect(expectSurfaceContrast(page.locator('div'))).rejects.toThrow(/contrast failures/);
  1169 | });
  1170 | 
  1171 | test('review recorded operator focus on SVG survives deferred overlay restoration', async ({ page }) => {
  1172 |   await page.goto('/counter');
  1173 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1174 |   await page.evaluate(async () => {
  1175 |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  1176 |     const focus = await import(path) as { restoreOverlayOrigin: () => void };
  1177 |     const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  1178 |     svg.setAttribute('tabindex', '0'); svg.id = 'operator-svg'; document.body.append(svg); svg.focus();
  1179 |     const w = window as typeof window & { __fcOverlayOrigin?: Element; __fcModalReservation?: { moved: boolean } };
  1180 |     w.__fcOverlayOrigin = document.querySelector('[data-testid="fc-palette-trigger"]')!;
  1181 |     w.__fcModalReservation = { moved: true };
  1182 |     focus.restoreOverlayOrigin();
  1183 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  1184 |   });
> 1185 |   await expect(page.locator('#operator-svg')).toBeFocused();
       |                                               ^ Error: expect(locator).toBeFocused() failed
  1186 | });
  1187 | 
```