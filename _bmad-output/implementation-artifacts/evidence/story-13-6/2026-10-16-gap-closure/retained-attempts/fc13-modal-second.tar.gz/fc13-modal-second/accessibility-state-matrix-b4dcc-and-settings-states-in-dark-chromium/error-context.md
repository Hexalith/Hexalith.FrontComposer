# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> active toolbar, tabs, palette and settings states in dark
- Location: specs/accessibility-state-matrix.spec.ts:327:3

# Error details

```
Error: Horizontal scroll regions must be labelled grids or tablists

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "FLUENT-TABLIST#f1961804-tablist",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/page-toolbar#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/page-toolbar#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Counter
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Dark"
                - generic [aria-hidden] [ref=e22]: Dark
          - button "Toggle developer overlay (Ctrl+Shift+D)" [ref=e27] [cursor=pointer]
          - button "Open command palette" [ref=e31] [cursor=pointer]
          - button "Open settings" [ref=e35] [cursor=pointer]
          - button "Account menu" [ref=e40] [cursor=pointer]
    - generic [ref=e43]:
      - status [ref=e44]: Density set to Comfortable.
      - main [ref=e45]:
        - status [ref=e46]
        - status [ref=e47]
        - main [ref=e49]:
          - generic [ref=e50]:
            - paragraph [ref=e51]: FrontComposer accessibility specimen
            - heading "Page toolbar specimen" [level=1] [ref=e52]
            - paragraph [ref=e53]: Reusable search, filter, view, action, and tab toolbar rendered with Fluent UI.
          - region [ref=e54]:
            - heading "Toolbar" [level=2] [ref=e55]
            - toolbar "Orders page tools" [ref=e57]:
              - generic "Search orders" [ref=e59]:
                - searchbox "Search orders" [ref=e61]: open
              - button "Order filters" [expanded] [active] [ref=e62] [cursor=pointer]
              - dialog "Order filters":
                - generic [ref=e65]:
                  - paragraph [ref=e67]: Order filters
                  - generic [ref=e68]:
                    - generic [ref=e69]: "Status: Active"
                    - generic [ref=e70]: "Owner: Current tenant"
              - button "View options" [ref=e72] [cursor=pointer]
              - generic [ref=e77]: Refresh
          - region [ref=e80]:
            - heading "Page tabs" [level=2] [ref=e81]
            - generic "Order sections" [ref=e82]:
              - tablist [ref=e83]:
                - generic:
                  - tab "Summary" [selected] [ref=e84] [cursor=pointer]
                  - tab "Activity" [ref=e86] [cursor=pointer]
                  - tab "Archived" [disabled]
                  - tab "History" [ref=e88] [cursor=pointer]
              - tabpanel "Summary" [ref=e90]:
                - paragraph [ref=e92]: Summary panel content
          - region [ref=e93]:
            - heading "Toolbar state" [level=2] [ref=e94]
            - generic [ref=e95]:
              - generic [ref=e96]: "Current search: open"
              - generic [ref=e97]: "Active tab: summary"
              - generic [ref=e98]: "Refresh count: 0"
    - generic [ref=e99]: Counter © 2026
```

# Test source

```ts
  1   | import { expect, type Locator, type Page } from '@playwright/test';
  2   | 
  3   | export type TargetException = {
  4   |   selector: string;
  5   |   kind: 'Inline' | 'Spacing' | 'Equivalent' | 'User Agent Control' | 'Essential';
  6   |   rationale: string;
  7   |   keyboardPath: string;
  8   |   evidence: string;
  9   |   equivalentSelector?: string;
  10  |   essentialReason?: string;
  11  | };
  12  | 
  13  | /** Apply all four overrides through rerenders, including shadow roots attached later. */
  14  | export async function applyTextSpacing(page: Page): Promise<void> {
  15  |   await page.evaluate(() => {
  16  |     const owner = window as unknown as { aeSpacingCleanup?: () => void };
  17  |     owner.aeSpacingCleanup?.();
  18  |     const css = '* { line-height: 1.5 !important; letter-spacing: .12em !important; word-spacing: .16em !important; } p { margin-block-end: 2em !important; }';
  19  |     const roots = new Set<Document | ShadowRoot>();
  20  |     const visit = (root: Document | ShadowRoot) => {
  21  |       if (!roots.has(root)) { roots.add(root); observer.observe(root instanceof Document ? root.documentElement : root, { childList: true, subtree: true }); }
  22  |       if (!root.querySelector('[data-ae-text-spacing]')) {
  23  |         const style = document.createElement('style'); style.dataset.aeTextSpacing = 'true'; style.textContent = css;
  24  |         (root instanceof Document ? root.head : root).append(style);
  25  |       }
  26  |       root.querySelectorAll('*').forEach(element => { if (element.shadowRoot) visit(element.shadowRoot); });
  27  |     };
  28  |     const observer = new MutationObserver(() => { for (const root of roots) visit(root); });
  29  |     const original = Element.prototype.attachShadow;
  30  |     const patched = function (this: Element, init: ShadowRootInit) { const root = original.call(this, init); visit(root); return root; };
  31  |     Element.prototype.attachShadow = patched;
  32  |     owner.aeSpacingCleanup = () => {
  33  |       observer.disconnect();
  34  |       if (Element.prototype.attachShadow === patched) Element.prototype.attachShadow = original;
  35  |       for (const root of roots) root.querySelectorAll('[data-ae-text-spacing]').forEach(style => style.remove());
  36  |       delete owner.aeSpacingCleanup;
  37  |     };
  38  |     visit(document);
  39  |   });
  40  | }
  41  | 
  42  | /** Remove the overrides and their observer/prototype seam before a restoration round trip. */
  43  | export async function removeTextSpacing(page: Page): Promise<void> {
  44  |   await page.evaluate(() => (window as unknown as { aeSpacingCleanup?: () => void }).aeSpacingCleanup?.());
  45  | }
  46  | 
  47  | export async function expectNoPageOverflow(page: Page): Promise<void> {
  48  |   const geometry = await page.evaluate(() => {
  49  |     const root = document.scrollingElement ?? document.documentElement;
  50  |     const unlabelled: string[] = [];
  51  |     const visit = (scope: Document | ShadowRoot) => {
  52  |       for (const element of scope.querySelectorAll('*')) {
  53  |         if (element.shadowRoot) visit(element.shadowRoot);
  54  |         const style = getComputedStyle(element), box = element.getBoundingClientRect();
  55  |         if (box.width === 0 || box.height === 0 || style.visibility === 'hidden' || element.closest('[hidden],[aria-hidden="true"]')) continue;
  56  |         if (!/(auto|scroll)/u.test(style.overflowX) || element.scrollWidth <= element.clientWidth + 1) continue;
  57  |         const label = element.getAttribute('aria-label')?.trim() || element.getAttribute('aria-labelledby')?.split(/\s+/u).map(id => element.ownerDocument.getElementById(id)?.textContent?.trim()).filter(Boolean).join(' ');
  58  |         const grid = element.matches('[role="region"]') && Boolean(element.querySelector('[role="grid"],table,[data-fc-datagrid]'));
  59  |         const tabs = element.matches('[role="tablist"],fluent-tablist');
  60  |         if (!(label && (grid || tabs))) unlabelled.push(`${element.tagName}#${element.id}`);
  61  |       }
  62  |     };
  63  |     visit(document);
  64  |     return { width: root.clientWidth, scrollWidth: root.scrollWidth, unlabelled };
  65  |   });
  66  |   expect(geometry.scrollWidth, `Page overflow: ${JSON.stringify(geometry)}`).toBeLessThanOrEqual(geometry.width + 1);
> 67  |   expect(geometry.unlabelled, 'Horizontal scroll regions must be labelled grids or tablists').toEqual([]);
      |                                                                                               ^ Error: Horizontal scroll regions must be labelled grids or tablists
  68  | }
  69  | 
  70  | /** Inventory actual hit targets, collapsing a Fluent control and its shadow control to one target. */
  71  | export async function inventoryTargets(page: Page, exceptions: TargetException[] = []) {
  72  |   return page.evaluate((records) => {
  73  |     const selector = 'a[href],button,input:not([type="hidden"]),select,textarea,summary,[role="button"],[role="tab"],[role="option"],[role="menuitem"],[role="checkbox"],[role="radio"],[role="switch"],fluent-button,fluent-text-input,fluent-number-input,fluent-select,fluent-combobox,fluent-dropdown,fluent-radio,fluent-switch,[tabindex]:not([tabindex="-1"]),[onclick]';
  74  |     const all: Element[] = [];
  75  |     const visit = (root: Document | ShadowRoot) => {
  76  |       root.querySelectorAll('*').forEach(element => { all.push(element); if (element.shadowRoot) visit(element.shadowRoot); });
  77  |     };
  78  |     visit(document);
  79  |     const visible = (element: Element) => {
  80  |       const rect = element.getBoundingClientRect();
  81  |       const style = getComputedStyle(element);
  82  |       return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none'
  83  |         && !element.closest('[inert]') && !element.closest('[aria-hidden="true"]');
  84  |     };
  85  |     const modalDialog = all.find(element => element.matches('dialog[open]'));
  86  |     const modalRoot = modalDialog?.getRootNode();
  87  |     const modal = modalRoot instanceof ShadowRoot ? modalRoot.host : modalDialog;
  88  |     const candidates = all.filter(element => element.matches(selector) && visible(element)
  89  |       && (!modal || element === modal || modal.contains(element) || element.getRootNode() instanceof ShadowRoot && modal.contains((element.getRootNode() as ShadowRoot).host)));
  90  |     const targets = candidates.filter(element => {
  91  |       const root = element.getRootNode();
  92  |       return !(root instanceof ShadowRoot && candidates.includes(root.host))
  93  |         && !candidates.some(ancestor => ancestor !== element && ancestor.tagName.startsWith('FLUENT-') && ancestor.contains(element));
  94  |     });
  95  |     const boxes = targets.map(element => ({ element, rect: element.getBoundingClientRect() }));
  96  |     const intersects = (a: DOMRect, b: DOMRect) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
  97  |     const circleIntersectsRect = (x: number, y: number, rect: DOMRect) => Math.hypot(x - Math.max(rect.left, Math.min(x, rect.right)), y - Math.max(rect.top, Math.min(y, rect.bottom))) < 12 - .01;
  98  |     const used = new Set<string>();
  99  |     const inventory = boxes.map(({ element, rect }, index) => {
  100 |       const identifier = element.id ? `#${element.id}` : element.getAttribute('data-testid') ? `[data-testid="${element.getAttribute('data-testid')}"]` : `${element.tagName.toLowerCase()}[inventory-index="${index}"]`;
  101 |       const record = records.find(item => element.matches(item.selector));
  102 |       let failure: string | null = null;
  103 |       const conforming = rect.width >= 24 && rect.height >= 24;
  104 |       if (record) used.add(record.selector);
  105 |       if (record && conforming) failure = 'Exception is stale: target already meets 24px minimum';
  106 |       if (!conforming) {
  107 |         if (!record || !record.rationale.trim() || !record.keyboardPath.trim() || !record.evidence.trim()) failure = 'Undersized target lacks an evidenced exception';
  108 |         else if (record.kind === 'Spacing') {
  109 |           const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
  110 |           if (boxes.some(other => other.element !== element && (circleIntersectsRect(x, y, other.rect)
  111 |             || (other.rect.width < 24 || other.rect.height < 24) && Math.hypot(x - other.rect.left - other.rect.width / 2, y - other.rect.top - other.rect.height / 2) < 24 - .01))) failure = '24px spacing circle intersects a target or neighboring undersized circle';
  112 |         } else if (record.kind === 'Equivalent') {
  113 |           const equivalent = record.equivalentSelector ? document.querySelector(record.equivalentSelector) : null;
  114 |           const box = equivalent?.getBoundingClientRect();
  115 |           if (!equivalent || equivalent === element || !visible(equivalent) || !box || box.width < 24 || box.height < 24 || intersects(rect, box)) failure = 'Equivalent control is absent, identical, overlapping, or undersized';
  116 |         } else if (record.kind === 'Inline') {
  117 |           if (!element.closest('p,li,dd') || !['inline', 'inline-block'].includes(getComputedStyle(element).display) || element.matches('button,[role="button"],fluent-button')) failure = 'Inline exception does not apply to a control outside running text';
  118 |         } else if (record.kind === 'Essential' && (!record.essentialReason?.trim() || !element.matches('[data-ae-essential-target]'))) failure = 'Essential exception requires an identified essential presentation and specific justification';
  119 |         else if (record.kind === 'User Agent Control' && (!element.matches('input,select,textarea') || getComputedStyle(element).appearance === 'none' || element.hasAttribute('style'))) failure = 'User agent exception requires an unmodified native control';
  120 |       }
  121 |       return { target: identifier, width: rect.width, height: rect.height, conforming, exception: record ?? null, failure };
  122 |     });
  123 |     return { inventory, unusedExceptions: records.filter(record => !used.has(record.selector)).map(record => record.selector) };
  124 |   }, exceptions);
  125 | }
  126 | 
  127 | export async function expectTargetSizes(page: Page, exceptions: TargetException[] = []) {
  128 |   const result = await inventoryTargets(page, exceptions);
  129 |   expect(result.inventory.length, 'Pointer-target inventory must be nonempty').toBeGreaterThan(0);
  130 |   expect(result.unusedExceptions, 'Stale or unmatched exception selectors').toEqual([]);
  131 |   expect(result.inventory.filter(target => target.failure), 'AE-04 target-size failures').toEqual([]);
  132 |   return result.inventory;
  133 | }
  134 | 
  135 | type PaintBox = { left: number; top: number; right: number; bottom: number };
  136 | type PaintClip = { kind: 'none' | 'rect' | 'hidden' | 'unsupported'; box?: PaintBox };
  137 | type RestingPaint = Map<Element, Record<string, Record<string, string>>>;
  138 | type PaintAudit = { clip: (css: CSSStyleDeclaration, box: PaintBox) => PaintClip; parse: (value: string) => number[]; resting: (scope: Element) => RestingPaint; changed: (element: Element, pseudo: string | null, style: CSSStyleDeclaration, resting: RestingPaint, properties: string[]) => boolean; shadows: (element: Element, pseudo: string | null, style: CSSStyleDeclaration, resting: RestingPaint) => string[] };
  139 | 
  140 | /** Observe resting pseudo-class paint synchronously, suppressing application focus callbacks. */
  141 | async function preparePaintAudit(root: Locator) {
  142 |   await root.evaluate(() => {
  143 |     const parse = (value: string): number[] => {
  144 |       if (!CSS.supports('color', value)) throw new Error(`Unsupported computed paint: ${value}`);
  145 |       const canvas = document.createElement('canvas'); canvas.width = canvas.height = 1;
  146 |       const context = canvas.getContext('2d')!; context.fillStyle = value; context.fillRect(0, 0, 1, 1);
  147 |       const pixel = context.getImageData(0, 0, 1, 1).data;
  148 |       return [pixel[0], pixel[1], pixel[2], pixel[3] / 255];
  149 |     };
  150 |     const clip = (css: CSSStyleDeclaration, box: PaintBox): PaintClip => {
  151 |       let result = { left: box.left, top: box.top, right: box.right, bottom: box.bottom }, clipped = false;
  152 |       const width = box.right - box.left, height = box.bottom - box.top;
  153 |       const length = (value: string, extent: number): number | null => {
  154 |         if (/^-?[\d.]+px$/u.test(value) || value === '0') return parseFloat(value);
  155 |         if (/^-?[\d.]+%$/u.test(value)) return parseFloat(value) * extent / 100;
  156 |         const calc = value.match(/^calc\(\s*(-?[\d.]+)%\s*([+-])\s*([\d.]+)px\s*\)$/u);
  157 |         return calc ? Number(calc[1]) * extent / 100 + (calc[2] === '+' ? 1 : -1) * Number(calc[3]) : null;
  158 |       };
  159 |       if (css.clip && css.clip !== 'auto' && ['absolute','fixed'].includes(css.position)) {
  160 |         const rect = css.clip.match(/^rect\((.*)\)$/u)?.[1].split(/[,\s]+/u).filter(Boolean);
  161 |         if (!rect || rect.length !== 4) return { kind: 'unsupported' };
  162 |         const values = rect.map((value, side) => value === 'auto' ? [0,width,height,0][side] : length(value, side % 2 ? width : height));
  163 |         if (values.some(value => value === null)) return { kind: 'unsupported' };
  164 |         result = { left: box.left + values[3]!, top: box.top + values[0]!, right: box.left + values[1]!, bottom: box.top + values[2]! }; clipped = true;
  165 |       }
  166 |       if (css.clipPath && css.clipPath !== 'none') {
  167 |         const tokens = css.clipPath.match(/^inset\((.*)\)$/u)?.[1].match(/calc\([^)]*\)|[^\s]+/gu);
```