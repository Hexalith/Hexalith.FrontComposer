# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> R11 collapsed offset shadow paints no focus pixels
- Location: specs/responsive-accessibility.spec.ts:908:1

# Error details

```
Error: Nonempty focus contrast inventory

expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- button "Action" [active] [ref=e2]
```

# Test source

```ts
  615 |         if (clipping.kind === 'unsupported') throw new Error('Clipped contrast paint needs pixel evidence');
  616 |         if (clipping.box) boxes = boxes.map(box => ({ left: Math.max(box.left, clipping.box!.left), right: Math.min(box.right, clipping.box!.right), top: Math.max(box.top, clipping.box!.top), bottom: Math.min(box.bottom, clipping.box!.bottom) }));
  617 |       }
  618 |       if (!boxes.some(box => box.right > box.left && box.bottom > box.top)) return;
  619 |       // Unrelated positioned paint under glyphs is not represented by ancestor colors.
  620 |       // Reject it until a pixel measurement can establish its compositing order.
  621 |       if (sampleKind === 'text' || sampleKind === 'icon') {
  622 |         const root = element.getRootNode();
  623 |         if (root instanceof Document || root instanceof ShadowRoot) for (const candidate of root.querySelectorAll('*')) {
  624 |           if (candidate === element || candidate.contains(element) || element.contains(candidate)) continue;
  625 |           const css = getComputedStyle(candidate), rect = candidate.getBoundingClientRect();
  626 |           if (!['absolute', 'fixed'].includes(css.position) || css.visibility === 'hidden' || Number(css.opacity) === 0 || parse(css.backgroundColor)[3] === 0) continue;
  627 |           if (boxes.some(box => rect.left < box.right && rect.right > box.left && rect.top < box.bottom && rect.bottom > box.top)) throw new Error('Overlapping sibling background needs pixel evidence');
  628 |         }
  629 |       }
  630 |       const color = parse(value); color[3] *= alpha;
  631 |       if (color[3] === 0 && sampleKind !== 'icon') return;
  632 |       const bg = background(outside ? parent(element) : element);
  633 |       const fg = composite(color, bg), a = luminance(fg), b = luminance(bg);
  634 |       const owner = controlOwner(element);
  635 |       if (!owners.has(owner)) owners.set(owner, owners.size);
  636 |       samples.push({ owner: owners.get(owner)!, node: `${element.tagName.toLowerCase()}${element.id ? '#' + element.id : ''}`, paint: label, foreground: fg, background: bg, ratio: (Math.max(a, b) + .05) / (Math.min(a, b) + .05), minimum });
  637 |     };
  638 |     const glyphPaint = (css: CSSStyleDeclaration) => matchMedia('(forced-colors: active)').matches && css.forcedColorAdjust !== 'none' ? css.color : css.getPropertyValue('-webkit-text-fill-color') || css.color;
  639 |     const sampledText = new Set<Node>();
  640 |     const visited = new Set<Element>();
  641 |     const visit = (element: Element) => {
  642 |       if (visited.has(element) || !visible(element)) return;
  643 |       visited.add(element);
  644 |       const css = getComputedStyle(element);
  645 |       if (sampleKind === 'text') {
  646 |         if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
  647 |           const placeholder = getComputedStyle(element, '::placeholder');
  648 |           const glyph = glyphPaint;
  649 |           const paint = element.value.trim() ? glyph(css) : element.getAttribute('placeholder') ? glyph(placeholder) : null;
  650 |           if (paint) sample(element, paint, element.value.trim() ? 'input value' : 'input placeholder', 4.5, false, element.value.trim() ? 1 : Number(placeholder.opacity));
  651 |         }
  652 |         const textNodes = element instanceof HTMLSlotElement ? element.assignedNodes({ flatten: true }) : element.childNodes;
  653 |         for (const node of textNodes) if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim() && !sampledText.has(node)) {
  654 |           sampledText.add(node);
  655 |           const range = document.createRange(); range.selectNodeContents(node);
  656 |           if (![...range.getClientRects()].some(box => box.width > 0 && box.height > 0)) continue;
  657 |           const textOwner = (node as Text).assignedSlot ?? element;
  658 |           const textCss = getComputedStyle(textOwner);
  659 |           const large = parseFloat(textCss.fontSize) >= 24 || parseFloat(textCss.fontSize) >= 18.667 && parseInt(textCss.fontWeight) >= 700;
  660 |           sample(textOwner, glyphPaint(textCss), node.textContent.trim().slice(0, 80), large ? 3 : 4.5, false, 1, [...range.getClientRects()]);
  661 |         }
  662 |         for (const pseudo of ['::before', '::after']) {
  663 |           const generated = getComputedStyle(element, pseudo);
  664 |           if (!generated.content || ['none','normal','""',"''"].includes(generated.content) || generated.visibility === 'hidden' || generated.display === 'none' || Number(generated.opacity) === 0) continue;
  665 |           if (!/^("[^"]*"|'[^']*')$/u.test(generated.content)) throw new Error('Generated content needs pixel evidence');
  666 |           if (parse(generated.backgroundColor)[3] > 0 || generated.backgroundImage !== 'none') throw new Error('Generated text background needs pixel evidence');
  667 |           sample(element, glyphPaint(generated), `${pseudo} generated text`, 4.5, false, Number(generated.opacity));
  668 |         }
  669 |       } else if (sampleKind === 'icon' && element.matches('svg path,svg polygon,svg circle,svg rect,svg ellipse,svg line,svg polyline,svg use,svg text')) {
  670 |         if (element.matches('use')) throw new Error('SVG use instance needs pixel evidence');
  671 |         for (const property of ['fill', 'stroke']) {
  672 |           const paint = css.getPropertyValue(property);
  673 |           if (property === 'stroke' && parseFloat(css.strokeWidth) <= 0 || property === 'fill' && element.matches('line')) continue;
  674 |           if (paint !== 'none') { const opacity = css.getPropertyValue(`${property}-opacity`); sample(element, paint, `icon ${property}`, 3, false, parseFloat(opacity) / (opacity.endsWith('%') ? 100 : 1)); }
  675 |         }
  676 |       } else if (sampleKind === 'border') {
  677 |         for (const pseudo of [null, '::before', '::after']) {
  678 |           const edge = getComputedStyle(element, pseudo);
  679 |           if (pseudo && (edge.content === 'none' || edge.visibility === 'hidden' || Number(edge.opacity) === 0)) continue;
  680 |           if (edge.transform !== 'none') { const matrix = new DOMMatrixReadOnly(edge.transform); if (matrix.a === 0 || matrix.d === 0) continue; }
  681 |           for (const side of ['top', 'right', 'bottom', 'left']) if (parseFloat(edge.getPropertyValue(`border-${side}-width`)) > 0 && !['none', 'hidden'].includes(edge.getPropertyValue(`border-${side}-style`))) sample(element, edge.getPropertyValue(`border-${side}-color`), `${pseudo ?? 'element'} border-${side}`, 3, !pseudo, Number(edge.opacity));
  682 |         }
  683 |       } else if (sampleKind === 'focus' || sampleKind === 'cue') {
  684 |         for (const pseudo of [null, '::before', '::after']) {
  685 |           const paint = getComputedStyle(element, pseudo);
  686 |           if (paint.visibility === 'hidden' || paint.display === 'none' || Number(paint.opacity) === 0 || pseudo && paint.content === 'none') continue;
  687 |           if (paint.transform !== 'none') { const matrix = new DOMMatrixReadOnly(paint.transform); if (matrix.a === 0 || matrix.d === 0) continue; }
  688 |           const qualifies = (keys: string[]) => sampleKind === 'cue' || audit.changed(element, pseudo, paint, resting, keys);
  689 |           if (qualifies(['outline-width','outline-style','outline-color','outline-offset']) && parseFloat(paint.outlineWidth) > 0 && paint.outlineStyle !== 'none') {
  690 |             const offset = parseFloat(paint.outlineOffset);
  691 |             if (offset < 0 && offset + parseFloat(paint.outlineWidth) > 0) throw new Error('Straddling outline adjacency needs pixel evidence');
  692 |             sample(element, paint.outlineColor, `${pseudo ?? 'element'} outline`, 3, offset >= 0, Number(paint.opacity));
  693 |           }
  694 |           if (qualifies(['box-shadow'])) for (const shadow of audit.shadows(element, pseudo, paint, resting)) {
  695 |             if (/\binset\b/u.test(shadow)) continue;
  696 |             const lengths = shadow.replace(/[a-z][a-z0-9-]*\([^()]*\)/giu, '').match(/-?[\d.]+px/gu)?.map(Number.parseFloat) ?? [];
  697 |             const bounds = element.getBoundingClientRect(), spread = lengths[3] ?? 0;
  698 |             if (bounds.width + 2 * spread <= 0 || bounds.height + 2 * spread <= 0 || lengths.length < 2 || (lengths[2] ?? 0) > 0 || lengths[0] === 0 && lengths[1] === 0 && (lengths[3] ?? 0) <= 0) continue;
  699 |             for (const color of shadow.match(/[a-z][a-z0-9-]*\([^()]*\)/giu) ?? []) sample(element, color, `${pseudo ?? 'element'} box-shadow`, 3, true, Number(paint.opacity));
  700 |           }
  701 |           if (pseudo && qualifies(['border-top-width','border-right-width','border-bottom-width','border-left-width','border-top-color','border-right-color','border-bottom-color','border-left-color'])) for (const side of ['top', 'right', 'bottom', 'left']) if (parseFloat(paint.getPropertyValue(`border-${side}-width`)) > 0 && !['none', 'hidden'].includes(paint.getPropertyValue(`border-${side}-style`))) sample(element, paint.getPropertyValue(`border-${side}-color`), `${pseudo} border-${side}`, 3, false, Number(paint.opacity));
  702 |         }
  703 |       }
  704 |       if (element instanceof HTMLSlotElement) for (const child of element.assignedElements({ flatten: true })) visit(child);
  705 |       if (element.shadowRoot) for (const child of element.shadowRoot.children) visit(child);
  706 |       for (const child of element.children) if (!child.matches('style,script,template')) visit(child);
  707 |     };
  708 |     visit(scope);
  709 |     return samples;
  710 |   }, kind);
  711 | }
  712 | 
  713 | export async function expectSurfaceContrast(root: Locator, kind: ContrastKind = 'text') {
  714 |   const samples = await measureSurfaceContrast(root, kind);
> 715 |   expect(samples.length, `Nonempty ${kind} contrast inventory`).toBeGreaterThan(0);
      |                                                                 ^ Error: Nonempty focus contrast inventory
  716 |   // A Fluent control may paint a contrasting edge plus a two-color separator.
  717 |   // Alternatives belong to that unique control; another control cannot mask a failure.
  718 |   const owners = new Set(samples.map(sample => sample.owner));
  719 |   const passingOwners = new Set([...owners].filter(owner => samples.some(sample => sample.owner === owner && sample.ratio >= sample.minimum)));
  720 |   const failures = samples.filter(sample => sample.ratio < sample.minimum && (!(kind === 'focus' || kind === 'cue' || kind === 'border') || !passingOwners.has(sample.owner)));
  721 |   expect(failures, `${kind} contrast failures`).toEqual([]);
  722 |   return samples;
  723 | }
  724 | 
  725 | /** Diagnostic element captures must leave the operator's scroll/focus geometry unchanged. */
  726 | export async function screenshotPreservingScroll(target: Locator, options?: Parameters<Locator['screenshot']>[0]) {
  727 |   const positions = await target.evaluateHandle(() => {
  728 |     const elements = new Set<Element>([document.scrollingElement ?? document.documentElement]);
  729 |     const visit = (root: Document | ShadowRoot) => { for (const element of root.querySelectorAll('*')) {
  730 |       if (element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth || element.scrollTop || element.scrollLeft) elements.add(element);
  731 |       if (element.shadowRoot) visit(element.shadowRoot);
  732 |     } };
  733 |     visit(document);
  734 |     return [...elements].map(element => ({ element, left: element.scrollLeft, top: element.scrollTop }));
  735 |   });
  736 |   try { return await target.screenshot(options); }
  737 |   finally {
  738 |     await positions.evaluate(records => { for (const { element, left, top } of records) if (element.isConnected) element.scrollTo({ left, top, behavior: 'instant' }); });
  739 |     await positions.dispose();
  740 |   }
  741 | }
  742 | 
  743 | /** Wait for finite theme/control paint transitions without changing the active styling. */
  744 | export async function settlePaint(page: Page): Promise<void> {
  745 |   await page.evaluate(async () => {
  746 |     for (let pass = 0; pass < 5; pass++) {
  747 |       await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  748 |       const roots: (Document | ShadowRoot)[] = [document];
  749 |       const collect = (root: Document | ShadowRoot) => { for (const element of root.querySelectorAll('*')) if (element.shadowRoot) { roots.push(element.shadowRoot); collect(element.shadowRoot); } };
  750 |       collect(document);
  751 |       const animations = roots.flatMap(root => root.getAnimations()).filter(animation => animation.playState === 'running' && Number.isFinite(Number(animation.effect?.getComputedTiming().endTime)));
  752 |       if (!animations.length) return;
  753 |       await Promise.allSettled(animations.map(animation => animation.finished));
  754 |     }
  755 |   });
  756 | }
  757 | 
```