# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> R01 rejects an unprevented boundary Tab that application code refocuses
- Location: specs/responsive-accessibility.spec.ts:827:1

# Error details

```
Error: expect(received).rejects.toThrow()

Received promise resolved instead of rejected
Resolved to value: undefined
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "First" [active] [ref=e2]
  - button "Last" [ref=e3]
```

# Test source

```ts
  733 |   test('G03 transparent supported CSS colors are absent focus paint', async ({ page }) => {
  734 |     for (const paint of ['outline:3px solid color(srgb 0 0 0 / 0)', 'box-shadow:0 0 0 6px color(srgb 0 0 0 / 0)']) {
  735 |       await page.setContent(`<style>button{margin:40px;appearance:none;outline:none;box-shadow:none}button:focus{${paint}}</style><button>Save</button>`);
  736 |       await page.locator('button').focus();
  737 |       expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  738 |     }
  739 |   });
  740 | 
  741 |   test('G04 focus clipping and masks fail closed on the target and its ancestry', async ({ page }) => {
  742 |     for (const clip of ['clip-path:inset(0)', 'clip:rect(0px,100px,50px,0px)', 'mask-image:linear-gradient(black,black)']) for (const owner of ['target','ancestor']) {
  743 |       await page.setContent(`<style>button{position:absolute;left:10px;top:10px;width:80px;height:30px;outline:none;appearance:none}button:focus{outline:6px solid black}</style><div style="position:absolute;left:40px;top:40px;width:100px;height:50px;${owner === 'ancestor' ? clip : ''}"><button style="${owner === 'target' ? clip : ''}">Save</button></div>`);
  744 |       await page.locator('button').focus();
  745 |       expect((await focusGeometry(page.locator('button'))).failures).toContain('focus clip-path/clip/mask needs pixel evidence');
  746 |     }
  747 |   });
  748 | 
  749 |   test('G05 SVG fill and stroke opacity contribute to effective contrast', async ({ page }) => {
  750 |     for (const paint of ['fill="black" fill-opacity=".1"', 'fill="none" stroke="black" stroke-width="4" stroke-opacity=".1"']) {
  751 |       await page.setContent(`<main style="background:white"><svg width="40" height="40"><rect x="4" y="4" width="30" height="30" ${paint}/></svg></main>`);
  752 |       await expect(expectSurfaceContrast(page.locator('main'), 'icon')).rejects.toThrow(/icon contrast failures/);
  753 |     }
  754 |   });
  755 | 
  756 |   test('G06 visible clipped low-contrast text cannot disappear from the inventory', async ({ page }) => {
  757 |     for (const clip of ['clip-path:inset(1px)', 'position:absolute;clip:rect(0px,100px,20px,0px)']) {
  758 |       await page.setContent(`<main style="background:white"><p style="color:black">Readable</p><p style="color:#eee;${clip}">Still visible low contrast</p></main>`);
  759 |       await expect(expectSurfaceContrast(page.locator('main'))).rejects.toThrow(/Clipped contrast paint|contrast failures/);
  760 |     }
  761 |   });
  762 | 
  763 |   test('G12 inward outlines contrast with the control paint', async ({ page }) => {
  764 |     await page.setContent('<style>main{background:white;padding:40px}button{background:black;color:white;outline:none;appearance:none}button:focus{outline:2px solid black;outline-offset:-2px}</style><main><button>Save</button></main>');
  765 |     await page.locator('button').focus();
  766 |     await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/focus contrast failures/);
  767 |   });
  768 | 
  769 |   test('G13 zero and negative spread shadows without offset or blur draw no outer indicator', async ({ page }) => {
  770 |     for (const spread of [0, -4]) {
  771 |       await page.setContent(`<style>button{margin:40px;appearance:none;outline:none}button:focus{box-shadow:0 0 0 ${spread}px black}</style><button>Save</button>`);
  772 |       await page.locator('button').focus();
  773 |       expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  774 |       await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  775 |     }
  776 |   });
  777 | });
  778 | 
  779 | test('supported clipped paint keeps a focus underline and excludes only fully hidden text', async ({ page }) => {
  780 |   await page.setContent('<style>button{position:relative;margin:40px;width:120px;height:40px;outline:none;appearance:none}button::after{content:"";position:absolute;inset:0;border-bottom:2px solid black;clip-path:inset(calc(100% - 2px) 1px 0px);transform:scaleX(0)}button:focus::after{transform:scaleX(1)}</style><main style="background:white;color:black"><button>Save</button><p>Readable</p><span style="position:absolute;width:1px;height:1px;clip-path:inset(50%);color:#eee">Nonvisual heading</span></main>');
  781 |   await page.locator('button').focus();
  782 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  783 |   const samples = await expectSurfaceContrast(page.locator('main'));
  784 |   expect(samples.some(sample => sample.paint === 'Nonvisual heading')).toBe(false);
  785 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  786 |   await page.locator('span').evaluate(element => { element.style.width = '120px'; element.style.height = '30px'; element.style.clipPath = 'inset(1px)'; });
  787 |   await expect(expectSurfaceContrast(page.locator('main'))).rejects.toThrow(/contrast failures/);
  788 | });
  789 | 
  790 | test('diagnostic screenshots restore scroll without repairing an actually clipped focus ring', async ({ page }) => {
  791 |   await page.setContent('<style>button{outline:none}button:focus{outline:3px solid black;outline-offset:2px}</style><div id="scroller" style="position:absolute;left:40px;top:40px;width:240px;height:100px;overflow:auto;padding:10px"><button>Keep focus</button><div id="capture" style="margin-top:400px;height:30px">Diagnostic target</div></div>');
  792 |   const button = page.locator('button'), scroller = page.locator('#scroller');
  793 |   await button.focus();
  794 |   expect((await focusGeometry(button)).failures).toEqual([]);
  795 |   await screenshotPreservingScroll(page.locator('#capture'));
  796 |   expect(await scroller.evaluate(element => element.scrollTop)).toBe(0);
  797 |   await expect(button).toBeFocused();
  798 |   expect((await focusGeometry(button)).failures).toEqual([]);
  799 |   await scroller.evaluate(element => { element.scrollTop = 12; });
  800 |   const failures = (await focusGeometry(button)).failures;
  801 |   expect(failures).toContain('vertical scrollport clips target or ring');
  802 |   await screenshotPreservingScroll(page.locator('#capture'));
  803 |   expect(await scroller.evaluate(element => element.scrollTop)).toBe(12);
  804 |   expect((await focusGeometry(button)).failures).toEqual(failures);
  805 | });
  806 | 
  807 | test('real Fluent search and generated editors retain their focus contour with text spacing', async ({ page }) => {
  808 |   await page.setViewportSize({ width: 320, height: 900 });
  809 |   for (const route of ['/__frontcomposer/specimens/page-toolbar', '/__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true']) {
  810 |     await page.goto(route);
  811 |     await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  812 |     await applyTextSpacing(page);
  813 |     const control = route.includes('page-toolbar')
  814 |       ? page.getByTestId('fc-page-toolbar-search')
  815 |       : page.getByTestId('fc-destructive-command-specimen').locator('fluent-text-input').first();
  816 |     await expect(control).toBeVisible();
  817 |     await control.focus();
  818 |     await page.keyboard.press('Shift+Tab');
  819 |     await page.keyboard.press('Tab');
  820 |     await expectFocusVisible(control);
  821 |     expect((await focusGeometry(control.locator('input'))).failures).toEqual([]);
  822 |     await expectSurfaceContrast(control, 'focus');
  823 |   }
  824 | });
  825 | 
  826 | 
  827 | test('R01 rejects an unprevented boundary Tab that application code refocuses', async ({ page }) => {
  828 |   await page.setContent('<style>button{margin:8px;outline:none}button:focus{outline:2px solid}</style><button id="first">First</button><button id="last">Last</button>');
  829 |   await page.locator('#last').evaluate(button => button.addEventListener('keydown', event => {
  830 |     const key = event as KeyboardEvent;
  831 |     if (key.key === 'Tab' && !key.shiftKey) setTimeout(() => (button as HTMLElement).focus(), 0);
  832 |   }));
> 833 |   await expect(verifyKeyboardCycle(page)).rejects.toThrow(/Application trapped Tab/);
      |                                                   ^ Error: expect(received).rejects.toThrow()
  834 | });
  835 | 
  836 | for (const opacity of [.01, .1, 1]) {
  837 |   test(`R02 pseudo focus paint composites opacity ${opacity}`, async ({ page }) => {
  838 |     await page.setContent(`<style>button{position:absolute;left:40px;top:40px;width:100px;height:40px;background:white;border:0;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black;opacity:${opacity}}</style><button>Action</button>`);
  839 |     await page.locator('button').focus();
  840 |     if (opacity < 1) await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  841 |     else await expectSurfaceContrast(page.locator('button'), 'focus');
  842 |   });
  843 | }
  844 | 
  845 | for (const shape of ['ellipse', 'line', 'polyline', 'use']) {
  846 |   test(`R03 measures SVG ${shape} without a passing rectangle masking it`, async ({ page }) => {
  847 |     const svg = { ellipse: '<ellipse cx="50" cy="20" rx="10" ry="10" fill="#eee"/>', line: '<line x1="40" y1="10" x2="60" y2="30" stroke="#eee" stroke-width="3"/>', polyline: '<polyline points="40,10 50,30 60,10" fill="none" stroke="#eee" stroke-width="3"/>', use: '<defs><path id="glyph" d="M40 10h20v20h-20z"/></defs><use href="#glyph" fill="#eee"/>' }[shape];
  848 |     await page.setContent(`<svg style="background:white" width="80" height="40"><rect width="20" height="20" fill="black"/>${svg}</svg>`);
  849 |     await expect(expectSurfaceContrast(page.locator('svg'), 'icon')).rejects.toThrow(shape === 'use' ? /pixel evidence/ : /contrast failures/);
  850 |     await page.locator('svg').evaluate(svg => svg.querySelectorAll('ellipse,line,polyline,use').forEach(node => { node.setAttribute('fill', node.matches('line,polyline') ? 'none' : 'black'); node.setAttribute('stroke', 'black'); }));
  851 |     if (shape !== 'use') await expectSurfaceContrast(page.locator('svg'), 'icon');
  852 |   });
  853 | }
  854 | 
  855 | test('R04 zero-width SVG stroke does not count as meaningful icon paint', async ({ page }) => {
  856 |   await page.setContent('<svg style="background:white"><rect width="40" height="40" fill="none" stroke="black" stroke-width="0"/></svg>');
  857 |   await expect(expectSurfaceContrast(page.locator('svg'), 'icon')).rejects.toThrow(/Nonempty/);
  858 |   await page.locator('rect').evaluate(node => node.setAttribute('stroke-width', '2'));
  859 |   await expectSurfaceContrast(page.locator('svg'), 'icon');
  860 | });
  861 | 
  862 | for (const effect of ['filter:brightness(0)', 'mix-blend-mode:multiply', 'backdrop-filter:brightness(0)']) {
  863 |   test(`R05 rejects unsupported composition ${effect}`, async ({ page }) => {
  864 |     await page.setContent(`<div style="background:black;${effect}"><p style="color:white">Meaningful label</p></div>`);
  865 |     await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/pixel evidence/);
  866 |     await page.locator('div').evaluate(node => { node.style.filter = 'none'; node.style.mixBlendMode = 'normal'; node.style.backdropFilter = 'none'; });
  867 |     await expectSurfaceContrast(page.locator('p'));
  868 |   });
  869 | }
  870 | 
  871 | test('R06 effective glyph fill determines text contrast', async ({ page }) => {
  872 |   await page.setContent('<p style="color:black;-webkit-text-fill-color:white;background:white">Invisible glyphs</p>');
  873 |   await expect(expectSurfaceContrast(page.locator('p'))).rejects.toThrow(/contrast failures/);
  874 |   await page.locator('p').evaluate(node => node.style.setProperty('-webkit-text-fill-color', 'black'));
  875 |   await expectSurfaceContrast(page.locator('p'));
  876 | });
  877 | 
  878 | test('R07 sibling background paint cannot be replaced with ancestor white', async ({ page }) => {
  879 |   await page.setContent('<div style="position:relative;background:white"><div id="under" style="position:absolute;inset:0;background:black"></div><p style="position:relative;color:black">Hidden black glyphs</p></div>');
  880 |   await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/sibling background needs pixel evidence/);
  881 |   await page.locator('#under').evaluate(node => node.remove());
  882 |   await expectSurfaceContrast(page.locator('p'));
  883 | });
  884 | 
  885 | test('R08 invisible ancestor cannot certify focus geometry', async ({ page }) => {
  886 |   await page.setContent('<style>button{outline:none}button:focus{outline:2px solid black}</style><div style="opacity:0"><button>Action</button></div>');
  887 |   await page.locator('button').focus();
  888 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  889 |   await page.locator('div').evaluate(node => node.style.opacity = '1');
  890 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  891 | });
  892 | 
  893 | test('R09 descendant extending over the target ring is an obstruction', async ({ page }) => {
  894 |   await page.setContent('<style>button{position:absolute;left:40px;top:40px;width:100px;height:40px;outline:none}button:focus{outline:2px solid black}</style><button>Action<span style="position:absolute;inset:-5px;background:white"></span></button>');
  895 |   await page.locator('button').focus();
  896 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  897 |   await page.locator('span').evaluate(node => node.remove());
  898 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  899 | });
  900 | 
  901 | test('R10 generated meaningful text cannot disappear beside passing text', async ({ page }) => {
  902 |   await page.setContent('<style>div{background:white;color:black}div::before{content:"Generated label";color:#eee}</style><div>Passing label</div>');
  903 |   await expect(expectSurfaceContrast(page.locator('div'))).rejects.toThrow(/contrast failures/);
  904 |   await page.addStyleTag({ content: 'div::before{color:black}' });
  905 |   await expectSurfaceContrast(page.locator('div'));
  906 | });
  907 | 
  908 | test('R11 collapsed offset shadow paints no focus pixels', async ({ page }) => {
  909 |   await page.setContent('<style>button{margin:40px;outline:none}button:focus{box-shadow:10px 0 0 -100px black}</style><button>Action</button>');
  910 |   await page.locator('button').focus();
  911 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  912 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  913 |   await page.addStyleTag({ content: 'button:focus{box-shadow:10px 0 0 2px black}' });
  914 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  915 | });
  916 | 
  917 | test('R12 permanent shadow cannot certify an invisible focus-only layer', async ({ page }) => {
  918 |   await page.setContent('<style>button{margin:40px;background:white;outline:none;box-shadow:0 0 0 3px black}button:focus{box-shadow:0 0 0 3px black,0 0 0 1px white}</style><button>Action</button>');
  919 |   await page.locator('button').focus();
  920 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  921 |   await page.addStyleTag({ content: 'button:focus{box-shadow:0 0 0 3px black,0 0 0 5px black}' });
  922 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  923 | });
  924 | 
  925 | test('R13 inset pseudo focus border compares against control paint', async ({ page }) => {
  926 |   await page.setContent('<style>button{position:relative;margin:40px;background:black;color:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black}</style><button>Action</button>');
  927 |   await page.locator('button').focus();
  928 |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  929 |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  930 |   await expectSurfaceContrast(page.locator('button'), 'focus');
  931 | });
  932 | 
  933 | test('R14 placeholder alpha determines effective contrast', async ({ page }) => {
```