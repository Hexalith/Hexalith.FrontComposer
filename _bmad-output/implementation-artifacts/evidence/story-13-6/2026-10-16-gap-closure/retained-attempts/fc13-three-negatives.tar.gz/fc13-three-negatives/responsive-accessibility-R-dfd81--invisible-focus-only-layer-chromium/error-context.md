# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> R12 permanent shadow cannot certify an invisible focus-only layer
- Location: specs/responsive-accessibility.spec.ts:917:1

# Error details

```
Error: expect(received).rejects.toThrow(expected)

Expected pattern: /contrast failures/
Received message: "Nonempty focus contrast inventory·
expect(received).toBeGreaterThan(expected)·
Expected: > 0
Received:   0"

      713 | export async function expectSurfaceContrast(root: Locator, kind: ContrastKind = 'text') {
      714 |   const samples = await measureSurfaceContrast(root, kind);
    > 715 |   expect(samples.length, `Nonempty ${kind} contrast inventory`).toBeGreaterThan(0);
          |                                                                 ^
      716 |   // A Fluent control may paint a contrasting edge plus a two-color separator.
      717 |   // Alternatives belong to that unique control; another control cannot mask a failure.
      718 |   const owners = new Set(samples.map(sample => sample.owner));

      at expectSurfaceContrast (helpers/responsive-accessibility.ts:715:65)
      at specs/responsive-accessibility.spec.ts:920:3
```

# Page snapshot

```yaml
- button "Action" [active] [ref=e2]
```

# Test source

```ts
  820  |     await expectFocusVisible(control);
  821  |     expect((await focusGeometry(control.locator('input'))).failures).toEqual([]);
  822  |     await expectSurfaceContrast(control, 'focus');
  823  |   }
  824  | });
  825  | 
  826  | 
  827  | test('R01 rejects an unprevented boundary Tab that application code refocuses', async ({ page }) => {
  828  |   await page.setContent('<style>button{margin:8px;outline:none}button:focus{outline:2px solid}</style><button id="first">First</button><button id="last">Last</button>');
  829  |   await page.locator('#last').evaluate(button => button.addEventListener('keydown', event => {
  830  |     const key = event as KeyboardEvent;
  831  |     if (key.key === 'Tab' && !key.shiftKey) setTimeout(() => (button as HTMLElement).focus(), 0);
  832  |   }));
  833  |   await expect(verifyKeyboardCycle(page)).rejects.toThrow(/Application trapped Tab/);
  834  | });
  835  | 
  836  | for (const opacity of [.01, .1, 1]) {
  837  |   test(`R02 pseudo focus paint composites opacity ${opacity}`, async ({ page }) => {
  838  |     await page.setContent(`<style>button{position:absolute;left:40px;top:40px;width:100px;height:40px;background:white;border:0;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black;opacity:${opacity}}</style><button>Action</button>`);
  839  |     await page.locator('button').focus();
  840  |     if (opacity < 1) await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  841  |     else await expectSurfaceContrast(page.locator('button'), 'focus');
  842  |   });
  843  | }
  844  | 
  845  | for (const shape of ['ellipse', 'line', 'polyline', 'use']) {
  846  |   test(`R03 measures SVG ${shape} without a passing rectangle masking it`, async ({ page }) => {
  847  |     const svg = { ellipse: '<ellipse cx="50" cy="20" rx="10" ry="10" fill="#eee"/>', line: '<line x1="40" y1="10" x2="60" y2="30" stroke="#eee" stroke-width="3"/>', polyline: '<polyline points="40,10 50,30 60,10" fill="none" stroke="#eee" stroke-width="3"/>', use: '<defs><path id="glyph" d="M40 10h20v20h-20z"/></defs><use href="#glyph" fill="#eee"/>' }[shape];
  848  |     await page.setContent(`<svg style="background:white" width="80" height="40"><rect width="20" height="20" fill="black"/>${svg}</svg>`);
  849  |     await expect(expectSurfaceContrast(page.locator('svg'), 'icon')).rejects.toThrow(shape === 'use' ? /pixel evidence/ : /contrast failures/);
  850  |     await page.locator('svg').evaluate(svg => svg.querySelectorAll('ellipse,line,polyline,use').forEach(node => { node.setAttribute('fill', node.matches('line,polyline') ? 'none' : 'black'); node.setAttribute('stroke', 'black'); }));
  851  |     if (shape !== 'use') await expectSurfaceContrast(page.locator('svg'), 'icon');
  852  |   });
  853  | }
  854  | 
  855  | test('R04 zero-width SVG stroke does not count as meaningful icon paint', async ({ page }) => {
  856  |   await page.setContent('<svg style="background:white"><rect width="40" height="40" fill="none" stroke="black" stroke-width="0"/></svg>');
  857  |   await expect(expectSurfaceContrast(page.locator('svg'), 'icon')).rejects.toThrow(/Nonempty/);
  858  |   await page.locator('rect').evaluate(node => node.setAttribute('stroke-width', '2'));
  859  |   await expectSurfaceContrast(page.locator('svg'), 'icon');
  860  | });
  861  | 
  862  | for (const effect of ['filter:brightness(0)', 'mix-blend-mode:multiply', 'backdrop-filter:brightness(0)']) {
  863  |   test(`R05 rejects unsupported composition ${effect}`, async ({ page }) => {
  864  |     await page.setContent(`<div style="background:black;${effect}"><p style="color:white">Meaningful label</p></div>`);
  865  |     await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/pixel evidence/);
  866  |     await page.locator('div').evaluate(node => { node.style.filter = 'none'; node.style.mixBlendMode = 'normal'; node.style.backdropFilter = 'none'; });
  867  |     await expectSurfaceContrast(page.locator('p'));
  868  |   });
  869  | }
  870  | 
  871  | test('R06 effective glyph fill determines text contrast', async ({ page }) => {
  872  |   await page.setContent('<p style="color:black;-webkit-text-fill-color:white;background:white">Invisible glyphs</p>');
  873  |   await expect(expectSurfaceContrast(page.locator('p'))).rejects.toThrow(/contrast failures/);
  874  |   await page.locator('p').evaluate(node => node.style.setProperty('-webkit-text-fill-color', 'black'));
  875  |   await expectSurfaceContrast(page.locator('p'));
  876  | });
  877  | 
  878  | test('R07 sibling background paint cannot be replaced with ancestor white', async ({ page }) => {
  879  |   await page.setContent('<div style="position:relative;background:white"><div id="under" style="position:absolute;inset:0;background:black"></div><p style="position:relative;color:black">Hidden black glyphs</p></div>');
  880  |   await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/sibling background needs pixel evidence/);
  881  |   await page.locator('#under').evaluate(node => node.remove());
  882  |   await expectSurfaceContrast(page.locator('p'));
  883  | });
  884  | 
  885  | test('R08 invisible ancestor cannot certify focus geometry', async ({ page }) => {
  886  |   await page.setContent('<style>button{outline:none}button:focus{outline:2px solid black}</style><div style="opacity:0"><button>Action</button></div>');
  887  |   await page.locator('button').focus();
  888  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  889  |   await page.locator('div').evaluate(node => node.style.opacity = '1');
  890  |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  891  | });
  892  | 
  893  | test('R09 descendant extending over the target ring is an obstruction', async ({ page }) => {
  894  |   await page.setContent('<style>button{position:absolute;left:40px;top:40px;width:100px;height:40px;outline:none}button:focus{outline:2px solid black}</style><button>Action<span style="position:absolute;inset:-5px;background:white"></span></button>');
  895  |   await page.locator('button').focus();
  896  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  897  |   await page.locator('span').evaluate(node => node.remove());
  898  |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  899  | });
  900  | 
  901  | test('R10 generated meaningful text cannot disappear beside passing text', async ({ page }) => {
  902  |   await page.setContent('<style>div{background:white;color:black}div::before{content:"Generated label";color:#eee}</style><div>Passing label</div>');
  903  |   await expect(expectSurfaceContrast(page.locator('div'))).rejects.toThrow(/contrast failures/);
  904  |   await page.addStyleTag({ content: 'div::before{color:black}' });
  905  |   await expectSurfaceContrast(page.locator('div'));
  906  | });
  907  | 
  908  | test('R11 collapsed offset shadow paints no focus pixels', async ({ page }) => {
  909  |   await page.setContent('<style>button{margin:40px;outline:none}button:focus{box-shadow:10px 0 0 -100px black}</style><button>Action</button>');
  910  |   await page.locator('button').focus();
  911  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  912  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  913  |   await page.addStyleTag({ content: 'button:focus{box-shadow:10px 0 0 2px black}' });
  914  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  915  | });
  916  | 
  917  | test('R12 permanent shadow cannot certify an invisible focus-only layer', async ({ page }) => {
  918  |   await page.setContent('<style>button{margin:40px;background:white;outline:none;box-shadow:0 0 0 3px black}button:focus{box-shadow:0 0 0 3px black,0 0 0 1px white}</style><button>Action</button>');
  919  |   await page.locator('button').focus();
> 920  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
       |                                                                                ^ Error: expect(received).rejects.toThrow(expected)
  921  |   await page.addStyleTag({ content: 'button:focus{box-shadow:0 0 0 3px black,0 0 0 5px black}' });
  922  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  923  | });
  924  | 
  925  | test('R13 inset pseudo focus border compares against control paint', async ({ page }) => {
  926  |   await page.setContent('<style>button{position:relative;margin:40px;background:black;color:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black}</style><button>Action</button>');
  927  |   await page.locator('button').focus();
  928  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  929  |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  930  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  931  | });
  932  | 
  933  | test('R14 placeholder alpha determines effective contrast', async ({ page }) => {
  934  |   await page.setContent('<style>input{background:white;color:black}input::placeholder{color:black;opacity:.1}</style><input placeholder="Meaningful placeholder">');
  935  |   await expect(expectSurfaceContrast(page.locator('input'))).rejects.toThrow(/contrast failures/);
  936  |   await page.addStyleTag({ content: 'input::placeholder{opacity:1}' });
  937  |   await expectSurfaceContrast(page.locator('input'));
  938  | });
  939  | 
  940  | test('reflow rejects unlabelled nested horizontal scrolling and stale or unjustified target exceptions', async ({ page }) => {
  941  |   await page.setContent('<div style="width:100px;overflow:auto"><div style="width:200px">Long content</div></div><button id="small" style="width:10px;height:10px;padding:0">A</button>');
  942  |   await expect(expectNoPageOverflow(page)).rejects.toThrow(/scroll/);
  943  |   const record: TargetException = { selector: '#small', kind: 'Essential', rationale: 'Small fixture', keyboardPath: 'Tab', evidence: 'fixture' };
  944  |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('Essential');
  945  |   await page.locator('#small').evaluate(node => { node.style.width = node.style.height = '30px'; });
  946  |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('stale');
  947  | });
  948  | 
  949  | test('R15 owned Settings return cancels the actual Fluent delayed return after an operator Tab', async ({ page }) => {
  950  |   await page.goto('/counter');
  951  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  952  |   await page.goto('/__frontcomposer/specimens/page-toolbar');
  953  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  954  |   await page.getByTitle('Change theme').first().click();
  955  |   await page.getByRole('menuitem', { name: 'Dark', exact: true }).click();
  956  |   const toolbar = new (await import('../page-objects/page-toolbar-specimen.page.js')).PageToolbarSpecimenPage(page);
  957  |   await toolbar.summaryTab.focus();
  958  |   await toolbar.summaryTab.press('ArrowRight');
  959  |   await page.getByTestId('fc-palette-trigger').click();
  960  |   await expect(page.getByTestId('fc-palette-search')).toBeFocused();
  961  |   await page.getByTestId('fc-palette-search').locator('input').fill('no-match-accessibility-136');
  962  |   await page.keyboard.press('Escape');
  963  |   await expect(page.getByTestId('fc-palette-trigger')).toBeFocused();
  964  |   await page.keyboard.press('Tab');
  965  |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  966  |   await page.keyboard.press('Enter');
  967  |   await expect(page.locator('#fc-settings-heading')).toBeFocused();
  968  |   await page.keyboard.press('Tab');
  969  |   await page.keyboard.press('Tab');
  970  |   await page.evaluate(async () => {
  971  |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  972  |     const focus = await import(path) as { containDialogFocus: (testId: string) => boolean };
  973  |     if (!focus.containDialogFocus('fc-settings-dialog')) throw new Error('palette containment did not attach');
  974  |     const host = document.querySelector<HTMLElement>('[data-testid="fc-settings-dialog"]')!.closest('fluent-dialog')!;
  975  |     const w = window as typeof window & { __aeVendorReturn?: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } };
  976  |     const callbacks: (() => void)[] = [];
  977  |     const original = window.setTimeout;
  978  |     window.setTimeout = ((handler: TimerHandler, delay?: number, ...args: unknown[]) => {
  979  |       // Hold the pinned Fluent callback itself, rather than substitute a synthetic return.
  980  |       if (delay === 25 && typeof handler === 'function' && new Error().stack?.includes('Microsoft.FluentUI.AspNetCore.Components.lib.module.js')) {
  981  |         callbacks.push(() => handler(...args));
  982  |         return 0;
  983  |       }
  984  |       return original(handler, delay, ...args);
  985  |     }) as typeof window.setTimeout;
  986  |     w.__aeVendorReturn = { host, callbacks, restore: () => { window.setTimeout = original; } };
  987  |   });
  988  |   await page.keyboard.press('Escape');
  989  |   await expect(page.getByTestId('fc-settings-dialog')).toHaveCount(0);
  990  |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  991  |   await page.keyboard.press('Shift+Tab');
  992  |   const settings = page.getByTestId('fc-palette-trigger');
  993  |   await expect(settings).toBeFocused();
  994  |   const proof = await page.evaluate(() => {
  995  |     const state = (window as typeof window & { __aeVendorReturn: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } }).__aeVendorReturn;
  996  |     state.restore();
  997  |     const proof = { queued: state.callbacks.length, cleared: state.host.previousActiveElement === null };
  998  |     for (const callback of state.callbacks) callback();
  999  |     return proof;
  1000 |   });
  1001 |   expect(proof.queued).toBeGreaterThan(0);
  1002 |   expect(proof.cleared).toBe(true);
  1003 |   await expect(settings).toBeFocused();
  1004 | });
  1005 | 
```