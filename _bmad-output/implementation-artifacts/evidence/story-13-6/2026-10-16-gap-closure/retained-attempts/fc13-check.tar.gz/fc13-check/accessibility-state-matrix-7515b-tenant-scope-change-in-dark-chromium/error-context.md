# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> held generated recovery cancels after tenant scope change in dark
- Location: specs/accessibility-state-matrix.spec.ts:597:3

# Error details

```
Error: expect(locator).not.toContainText(expected) failed

Locator: getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status')
Expected substring: not "not in the current results"
Error: strict mode violation: getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status') resolved to 2 elements:
    1) <div role="status" aria-live="polite" aria-atomic="true" class="fc-sr-only" data-testid="fc-surface-status"></div> aka getByTestId('fc-surface-status').nth(1)
    2) <div role="status" aria-live="polite" aria-atomic="true" class="fc-sr-only" data-testid="fc-surface-status"></div> aka getByTestId('fc-lifecycle-ae-state').getByTestId('fc-surface-status')

Call log:
  - Expect "not toContainText" getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status') with timeout 10000ms
  - waiting for getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=dark#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=dark#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]: Density set to Comfortable.
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - main [ref=e43]:
          - generic [ref=e44]:
            - paragraph [ref=e45]: FrontComposer accessibility specimen
            - heading "Type, theme, density, lifecycle, and navigation specimen" [level=1] [ref=e46]
            - paragraph [ref=e47]: Generated shell surfaces rendered with deterministic local data.
            - link "Skip to command form" [ref=e48] [cursor=pointer]:
              - /url: "#fc-specimen-command-form"
          - region [ref=e49]:
            - heading "Theme and density controls" [level=2] [ref=e50]
            - generic [ref=e51]:
              - link "light" [ref=e52] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "dark" [ref=e53] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "compact" [ref=e54] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "comfortable" [ref=e55] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=comfortable&generatedGrid=true&accessibilityScenarios=true
              - link "roomy" [ref=e56] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=roomy&generatedGrid=true&accessibilityScenarios=true
          - region [ref=e57]:
            - heading "Type ramp" [level=2] [ref=e58]
            - generic [ref=e59]:
              - article [ref=e60]:
                - paragraph [ref=e61]: Display
                - generic [ref=e62]: FrontComposer Display
              - article [ref=e63]:
                - paragraph [ref=e64]: Title
                - generic [ref=e65]: Generated command title
              - article [ref=e66]:
                - paragraph [ref=e67]: Subtitle
                - generic [ref=e68]: Projection subtitle and context
              - article [ref=e69]:
                - paragraph [ref=e70]: Body
                - generic [ref=e71]: Readable generated body text
              - article [ref=e72]:
                - paragraph [ref=e73]: Caption
                - generic [ref=e74]: Supplemental metadata caption
              - article [ref=e75]:
                - paragraph [ref=e76]: Code
                - generic [ref=e77]: FC-STATIC-0001
          - region [ref=e78]:
            - heading "Semantic color tokens" [level=2] [ref=e79]
            - generic [ref=e80]:
              - article [ref=e81]:
                - heading "light theme" [level=3] [ref=e82]
                - generic [ref=e83]:
                  - generic [ref=e85]: Neutral
                  - strong [ref=e86]: Available
                - generic [ref=e87]:
                  - generic [ref=e89]: Informational
                  - strong [ref=e90]: Queued
                - generic [ref=e91]:
                  - generic [ref=e93]: Success
                  - strong [ref=e94]: Confirmed
                - generic [ref=e95]:
                  - generic [ref=e97]: Warning
                  - strong [ref=e98]: Needs review
                - generic [ref=e99]:
                  - generic [ref=e101]: Danger
                  - strong [ref=e102]: Rejected
                - generic [ref=e103]:
                  - generic [ref=e105]: Accent
                  - strong [ref=e106]: Selected
              - article [ref=e107]:
                - heading "dark theme" [level=3] [ref=e108]
                - generic [ref=e109]:
                  - generic [ref=e111]: Neutral
                  - strong [ref=e112]: Available
                - generic [ref=e113]:
                  - generic [ref=e115]: Informational
                  - strong [ref=e116]: Queued
                - generic [ref=e117]:
                  - generic [ref=e119]: Success
                  - strong [ref=e120]: Confirmed
                - generic [ref=e121]:
                  - generic [ref=e123]: Warning
                  - strong [ref=e124]: Needs review
                - generic [ref=e125]:
                  - generic [ref=e127]: Danger
                  - strong [ref=e128]: Rejected
                - generic [ref=e129]:
                  - generic [ref=e131]: Accent
                  - strong [ref=e132]: Selected
          - region [ref=e133]:
            - heading "Density states" [level=2] [ref=e134]
            - generic [ref=e135]:
              - article [ref=e136]:
                - heading "compact density" [level=3] [ref=e137]
                - button "Primary action" [ref=e138]
                - generic [ref=e139]:
                  - text: Label
                  - textbox "compact density text input" [ref=e140]: compact sample
              - article [ref=e141]:
                - heading "comfortable density" [level=3] [ref=e142]
                - button "Primary action" [ref=e143]
                - generic [ref=e144]:
                  - text: Label
                  - textbox "comfortable density text input" [ref=e145]: comfortable sample
              - article [ref=e146]:
                - heading "roomy density" [level=3] [ref=e147]
                - button "Primary action" [ref=e148]
                - generic [ref=e149]:
                  - text: Label
                  - textbox "roomy density text input" [ref=e150]: roomy sample
          - region [ref=e151]:
            - heading "Generated projection DataGrid and badge states" [level=2] [ref=e152]
            - group [ref=e153]:
              - generic [ref=e154]:
                - heading "Workspace unavailable" [level=1] [ref=e155]
                - generic [ref=e156]: Your workspace identity could not be verified. Sign in again or contact support.
          - region "Automated accessibility scenarios" [ref=e157]:
            - heading "Fixed accessibility scenarios" [level=2] [ref=e158]
            - generic [ref=e159]:
              - generic [ref=e160] [cursor=pointer]: validation
              - generic [ref=e162] [cursor=pointer]: returned-rejection
              - generic [ref=e164] [cursor=pointer]: exception-rejection
              - generic [ref=e166] [cursor=pointer]: forbidden
              - generic [ref=e168] [cursor=pointer]: unavailable
              - generic [ref=e170] [cursor=pointer]: blank-unavailable
              - generic [ref=e172] [cursor=pointer]: rate-limited
              - generic [ref=e174] [cursor=pointer]: blank-rate-limited
              - generic [ref=e176] [cursor=pointer]: transport
              - generic [ref=e178] [cursor=pointer]: admission
              - generic [ref=e180] [cursor=pointer]: policy
              - generic [ref=e182] [cursor=pointer]: accepted
            - paragraph [ref=e184]: validation
            - generic [ref=e185]:
              - button "Run accessibility specimen" [ref=e186] [cursor=pointer]
              - status [ref=e190]
            - status "New item added outside current filters" [ref=e192]: New item. It may not match current filters yet.
            - generic [ref=e193]:
              - generic [ref=e194] [cursor=pointer]: Idle
              - generic [ref=e196] [cursor=pointer]: Submitting
              - generic [ref=e198] [cursor=pointer]: Acknowledged
              - generic [ref=e200] [cursor=pointer]: Syncing
              - generic [ref=e202] [cursor=pointer]: Confirmed
              - generic [ref=e204] [cursor=pointer]: Rejected
              - generic [ref=e206] [cursor=pointer]: IdempotentConfirmed
              - generic [ref=e208] [cursor=pointer]: NeedsReview
              - generic [ref=e210] [cursor=pointer]: Warning
              - generic [ref=e212] [cursor=pointer]: Degraded
              - generic [ref=e214] [cursor=pointer]: DegradedExhausted
            - generic [ref=e216]:
              - generic: Observable lifecycle specimen
              - status [ref=e217]
            - generic [ref=e218]:
              - generic [ref=e219] [cursor=pointer]: Connected
              - generic [ref=e221] [cursor=pointer]: Reconnecting
              - generic [ref=e223] [cursor=pointer]: Disconnected
              - generic [ref=e225] [cursor=pointer]: Start held page
              - generic [ref=e227] [cursor=pointer]: Complete held page
              - generic [ref=e229] [cursor=pointer]: Complete capped page
              - generic [ref=e231] [cursor=pointer]: Apply no-match filter
              - generic [ref=e233] [cursor=pointer]: Reset filter
            - generic [ref=e235]:
              - generic [active] [ref=e236] [cursor=pointer]: Load two rows
              - generic [ref=e238] [cursor=pointer]: Complete missing row result
              - generic [ref=e240] [cursor=pointer]: Complete empty result
              - generic [ref=e242] [cursor=pointer]: Complete failed result
              - generic [ref=e244] [cursor=pointer]: Start pending result
              - generic [ref=e246] [cursor=pointer]: Complete delayed missing result
              - generic [ref=e248] [cursor=pointer]: Change fixed tenant
              - generic [ref=e250] [cursor=pointer]: Change fixed user
              - generic [ref=e252] [cursor=pointer]: Repeat completed result
          - region [ref=e254]:
            - heading "Generated Counter projection grid" [level=2] [ref=e255]
            - group [ref=e256]:
              - generic [ref=e257]:
                - heading "Workspace unavailable" [level=1] [ref=e258]
                - generic [ref=e259]: Your workspace identity could not be verified. Sign in again or contact support.
          - region [ref=e260]:
            - heading "Command form and lifecycle states" [level=2] [ref=e261]
            - form "Specimen command form" [ref=e262]:
              - generic [ref=e263]:
                - text: Counter name
                - textbox "Counter name" [ref=e264]: Specimen counter
              - generic [ref=e265]:
                - text: Amount
                - spinbutton "Amount" [ref=e266]: "3"
              - button "Submit command" [ref=e267]
              - button "Cancel" [ref=e268]
            - list "Five command lifecycle states" [ref=e269]:
              - listitem [ref=e270]:
                - strong [ref=e271]: Idle
                - text: Ready to submit.
              - listitem [ref=e272]:
                - strong [ref=e273]: Submitting
                - text: Submitting command.
              - listitem [ref=e274]:
                - strong [ref=e275]: Acknowledged
                - text: Command accepted by the host.
              - listitem [ref=e276]:
                - strong [ref=e277]: Syncing
                - text: Waiting for projection synchronization.
              - listitem [ref=e278]:
                - strong [ref=e279]: Confirmed or rejected
                - text: Terminal confirmation and rejection states remain text-visible.
          - region [ref=e280]:
            - heading "Destructive command confirmation" [level=2] [ref=e281]
            - group [ref=e283]:
              - generic "Purge Specimen Record command form" [ref=e284]:
                - generic [ref=e285]:
                  - generic [ref=e286]:
                    - group "Purge details" [ref=e287]:
                      - generic [ref=e290]:
                        - generic: Record Id
                        - generic "Record Id" [ref=e292]:
                          - textbox "Record Id, Required" [ref=e294]: FC-1002
                        - generic: Record to purge.
                      - generic [ref=e297]:
                        - generic: Reason
                        - generic "Reason" [ref=e299]:
                          - textbox "Reason, Required" [ref=e301]: QA destructive confirmation coverage
                        - generic: Why this purge is required.
                    - generic [ref=e304]:
                      - generic: Retention
                      - generic "Retention" [ref=e306] [cursor=pointer]:
                        - combobox "Retention" [ref=e308]
                      - generic: How long the purged record stays recoverable.
                    - button "Purge Specimen Record" [ref=e313] [cursor=pointer]
                  - status [ref=e315]
          - region [ref=e316]:
            - heading "Policy-gated command authorization" [level=2] [ref=e317]
            - group [ref=e319]:
              - generic "Policy Allowed Specimen command form" [ref=e320]:
                - generic [ref=e321]:
                  - generic [ref=e322]:
                    - generic [ref=e324]:
                      - generic: Record Id
                      - generic "Record Id" [ref=e326]:
                        - textbox "Record Id, Required" [ref=e328]: FC-AUTH-ALLOW
                    - generic [ref=e330]:
                      - generic: Reason
                      - generic "Reason" [ref=e332]:
                        - textbox "Reason, Required" [ref=e334]: QA policy allowed coverage
                    - button "Policy Allowed Specimen" [ref=e335] [cursor=pointer]
                  - status [ref=e337]
            - group [ref=e338]:
              - group [ref=e339]:
                - heading "Permission required" [level=2] [ref=e340]
                - paragraph [ref=e341]: You do not have permission to Policy Denied Specimen.
          - region [ref=e342]:
            - heading "Expanded detail view" [level=2] [ref=e343]
            - group [ref=e344]:
              - generic "Open projection details for FC-1002" [ref=e345]
              - generic [ref=e346]:
                - term [ref=e347]: Correlation
                - definition [ref=e348]: fc-correlation-0002
                - term [ref=e349]: Last synchronized
                - definition [ref=e350]: 2026-01-15 13:45 UTC
          - navigation "Specimen multi-level navigation" [ref=e351]:
            - heading "Multi-level navigation" [level=2] [ref=e352]
            - list [ref=e353]:
              - listitem [ref=e354]:
                - link "Foundation" [ref=e355] [cursor=pointer]:
                  - /url: "#fc-type-ramp-title"
              - listitem [ref=e356]:
                - button "Generated surfaces" [expanded] [ref=e357]
                - list [ref=e358]:
                  - listitem [ref=e359]:
                    - link "Projection grid" [ref=e360] [cursor=pointer]:
                      - /url: "#fc-badge-grid-title"
                  - listitem [ref=e361]:
                    - link "Command lifecycle" [ref=e362] [cursor=pointer]:
                      - /url: "#fc-specimen-command-title"
    - generic [ref=e363]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  551 | test('paint measurement follows slots, ignores unpainted pseudo borders and sees native modal text through inert ancestors', async ({ page }) => {
  552 |   await page.setContent('<style>#edge{border:1px solid #eee;background:white}#edge::after{content:"";border-bottom:2px solid black;transform:scaleX(0);display:block}</style><div id="host" style="color:black;background:black">Slotted readable label</div><div id="edge">Boundary</div><div inert><dialog id="modal"><p>Visible modal text</p></dialog></div>');
  553 |   await page.locator('#host').evaluate(element => { element.attachShadow({ mode: 'open' }).innerHTML = '<style>slot{color:white}</style><slot></slot>'; });
  554 |   expect((await expectSurfaceContrast(page.locator('#host')))[0].ratio).toBe(21);
  555 |   expect((await expectSurfaceContrast(page.locator('#host').locator('slot')))[0].ratio).toBe(21);
  556 |   await expect(expectSurfaceContrast(page.locator('#edge'), 'border')).rejects.toThrow(/contrast failures/);
  557 |   await page.addStyleTag({ content: '#edge::after{transform:scaleX(1)}' });
  558 |   expect((await expectSurfaceContrast(page.locator('#edge'), 'border')).some(sample => sample.ratio >= 3)).toBe(true);
  559 |   await page.locator('#modal').evaluate(element => (element as HTMLDialogElement).showModal());
  560 |   await expectSurfaceContrast(page.locator('#modal'));
  561 | });
  562 | 
  563 | 
  564 | test('validation links keep native same-page href activation when focus enhancement is unavailable', async ({ page }, info) => {
  565 |   await page.route('**/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js', async route => {
  566 |     const response = await route.fetch();
  567 |     const body = (await response.text())
  568 |       .replace('export function focusValidationOutcome(', 'export function unavailableFocusValidationOutcome(')
  569 |       .replace('export function focusValidationTarget(', 'export function unavailableFocusValidationTarget(')
  570 |       + "\nexport function focusValidationOutcome(){throw new Error('Fixed focus-enhancement fixture unavailable');}\nexport function focusValidationTarget(){throw new Error('Fixed focus-enhancement fixture unavailable');}\n";
  571 |     await route.fulfill({ response, body });
  572 |   });
  573 |   await ready(page, '/__frontcomposer/specimens/type', 'light');
  574 |   await page.getByTestId('fc-destructive-command-specimen').getByRole('button', { name: 'Purge Specimen Record', exact: true }).click();
  575 |   const link = page.getByTestId('fc-validation-summary').getByRole('link', { name: 'The Retention field is required.', exact: true });
  576 |   await expect(link).toHaveCount(1);
  577 |   const href = await link.getAttribute('href');
  578 |   expect(href).toMatch(/__frontcomposer\/specimens\/type#.+-Retention$/u);
  579 |   await link.focus();
  580 |   await page.keyboard.press('Shift+Tab');
  581 |   await page.keyboard.press('Tab');
  582 |   await expect(link).toBeFocused();
  583 |   await page.keyboard.press('Enter');
  584 |   await expect(page).toHaveURL(new URL(href!, await page.locator('base').getAttribute('href').then(base => new URL(base!, page.url()).href)).href);
  585 |   await info.attach('native-validation-link-fallback', { body: JSON.stringify({ role: 'link', href, activation: 'keyboard Enter', duplicateKeyboardStops: false }), contentType: 'application/json' });
  586 | });
  587 | 
  588 | test('G09 forced-color focus geometry rejects a mode-specific clipped ring', async ({ page }) => {
  589 |   await page.setContent('<style>button{position:fixed;left:2px;top:40px;width:80px;height:40px;appearance:none;outline:none}button:focus{outline:2px solid black}@media(forced-colors:active){button:focus{outline-width:6px}}</style><button>Save</button>');
  590 |   await page.locator('button').focus();
  591 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  592 |   await page.emulateMedia({ forcedColors: 'active' });
  593 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('viewport clips target or focus ring');
  594 | });
  595 | 
  596 | for (const theme of ['light', 'dark']) for (const scope of ['tenant', 'user']) {
  597 |   test(`held generated recovery cancels after ${scope} scope change in ${theme}`, async ({ page }) => {
  598 |     await page.route('**/fc-focus.js', async route => {
  599 |       const response = await route.fetch();
  600 |       const source = (await response.text()).replace('export function focusReplacementHeading(key, headingId)', 'function originalFocusReplacementHeading(key, headingId)');
  601 |       await route.fulfill({ response, body: source + `
  602 | export async function focusReplacementHeading(key, headingId) {
  603 |   const gate = window.__aeRecoveryGate;
  604 |   if (gate?.hold) {
  605 |     gate.entered = true;
  606 |     gate.capturedDetached = focusBeforeReplacement.get(key) instanceof HTMLElement && !focusBeforeReplacement.get(key).isConnected;
  607 |     await new Promise(resolve => { gate.release = () => { gate.released = true; resolve(); }; });
  608 |   }
  609 |   if (gate?.hold) gate.captureStillOwned = focusBeforeReplacement.has(key);
  610 |   const result = originalFocusReplacementHeading(key, headingId);
  611 |   if (gate?.hold) gate.returned = result;
  612 |   return result;
  613 | }` });
  614 |     });
  615 |     await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  616 |     const grid = page.getByTestId('fc-generated-counter-grid');
  617 |     await grid.scrollIntoViewIfNeeded();
  618 |     await expect(grid.locator('[data-fc-datagrid]')).toBeVisible();
  619 |     await expect(grid.locator('tbody tr.fluent-data-grid-row').first()).toBeVisible();
  620 |     await page.getByTestId('fc-ae-rows-two').click();
  621 |     // The control above the grid may scroll its virtualized rows out of view.
  622 |     // Establish the completed two-row render before entering the focus recovery sequence.
  623 |     await grid.scrollIntoViewIfNeeded();
  624 |     await expect(grid.locator('tbody tr.fluent-data-grid-row')).toHaveCount(2);
  625 |     await expect(grid.getByRole('gridcell', { name: 'FC-AE-2', exact: true })).toBeVisible();
  626 |     await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  627 |     const detail = grid.locator('.fc-expand-in-row-detail');
  628 |     await expect(detail).toContainText('FC-AE-1');
  629 |     await detail.locator('a,button,fluent-button,[tabindex="0"]').first().focus();
  630 |     const arm = async () => page.evaluate(() => { (window as typeof window & { __aeRecoveryGate: unknown }).__aeRecoveryGate = { hold: true, entered: false, released: false }; });
  631 |     const entered = async () => {
  632 |       await expect.poll(() => page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { entered: boolean; capturedDetached?: boolean } }).__aeRecoveryGate)).toMatchObject({ entered: true, capturedDetached: true });
  633 |       await expect(detail.locator('a,button,fluent-button,[tabindex="0"]')).toHaveCount(0);
  634 |       await expect(grid.locator('.fc-expanded-row-hidden-banner-text')).toBeVisible();
  635 |     };
  636 |     const release = async () => {
  637 |       await page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { release: () => void } }).__aeRecoveryGate.release());
  638 |       await expect.poll(() => page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { returned?: boolean; captureStillOwned?: boolean } }).__aeRecoveryGate)).toMatchObject({ returned: false, captureStillOwned: false });
  639 |     };
  640 |     await arm();
  641 |     await page.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  642 |     await entered();
  643 |     await page.getByTestId(`fc-ae-scope-${scope}`).dispatchEvent('click');
  644 |     await expect(page.locator('.fc-expanded-row-hidden-banner-text')).toHaveCount(0);
  645 |     const current = page.getByTestId('fc-ae-rows-two');
  646 |     await expect(current).toBeVisible();
  647 |     await current.focus();
  648 |     await release();
  649 |     await expect(current).toBeFocused();
  650 |     await expect(page.locator('.fc-expanded-row-hidden-banner-text')).toHaveCount(0);
> 651 |     await expect(page.getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status')).not.toContainText('not in the current results');
      |                                                                                            ^ Error: expect(locator).not.toContainText(expected) failed
  652 |   });
  653 | }
  654 | 
```