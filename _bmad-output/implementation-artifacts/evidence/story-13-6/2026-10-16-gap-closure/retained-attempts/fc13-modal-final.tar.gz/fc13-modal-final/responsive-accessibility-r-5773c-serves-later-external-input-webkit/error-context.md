# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> reused owned dialog dismissal resets only its current return and preserves later external input
- Location: specs/responsive-accessibility.spec.ts:1017:1

# Error details

```
Error: page.evaluate: Error: later external input was discarded
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3]:
    - /url: /counter#fc-main-content
  - link "Skip to navigation" [ref=e4]:
    - /url: /counter#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic:
                  - generic:
                    - button "Close"
                - generic:
                  - generic:
                    - generic:
                      - generic:
                        - navigation "Primary navigation":
                          - generic:
                            - button "Counter"
                            - generic:
                              - generic:
                                - button "More Counter pages"
                            - button "Default"
                            - button "Specimens"
                            - generic:
                              - generic:
                                - button "More Specimens pages"
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [active] [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - navigation "Primary navigation" [ref=e39]:
      - generic [ref=e40]:
        - button "Counter" [ref=e41] [cursor=pointer]
        - button "More Counter pages" [ref=e47] [cursor=pointer]
        - button "Default" [ref=e54] [cursor=pointer]
        - button "Specimens" [ref=e59] [cursor=pointer]
        - button "More Specimens pages" [ref=e65] [cursor=pointer]
    - generic [ref=e72]:
      - status [ref=e73]: Density set to Compact.
      - main [ref=e74]:
        - status [ref=e75]
        - status [ref=e76]
        - generic [ref=e77]:
          - heading "Counter" [level=1] [ref=e78]
          - generic "Counter pages" [ref=e79]:
            - tablist [ref=e80]:
              - generic:
                - tab "Overview" [selected] [ref=e81] [cursor=pointer]
                - tab "Projection" [ref=e83] [cursor=pointer]
            - tabpanel "Overview" [ref=e85]:
              - generic [ref=e87]:
                - generic:
                  - generic [ref=e88]:
                    - heading [level=2] [ref=e89]:
                      - button "Create with an exact target" [expanded] [ref=e90] [cursor=pointer]
                    - region "Create with an exact target" [ref=e93]:
                      - group [ref=e95]:
                        - generic "Create Counter command form" [ref=e96]:
                          - generic [ref=e97]:
                            - generic [ref=e98]:
                              - generic [ref=e100]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e102]:
                                  - textbox "Counter key, Required" [ref=e104]
                              - generic [ref=e106]:
                                - generic: Initial Value
                                - generic "Initial Value" [ref=e108]:
                                  - textbox "Initial Value, Required" [ref=e110]: "0"
                              - button "Create Counter" [ref=e111] [cursor=pointer]
                            - status [ref=e113]
                  - generic [ref=e114]:
                    - heading [level=2] [ref=e115]:
                      - button "Update with an exact target" [expanded] [ref=e116] [cursor=pointer]
                    - region "Update with an exact target" [ref=e119]:
                      - group [ref=e121]:
                        - generic "Update Counter command form" [ref=e122]:
                          - generic [ref=e123]:
                            - generic [ref=e124]:
                              - generic [ref=e126]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e128]:
                                  - textbox "Counter key, Required" [ref=e130]
                              - generic [ref=e132]:
                                - generic: Amount
                                - generic "Amount" [ref=e134]:
                                  - textbox "Amount, Required" [ref=e136]: "1"
                              - button "Update Counter" [ref=e137] [cursor=pointer]
                            - status [ref=e139]
                  - generic [ref=e140]:
                    - heading [level=2] [ref=e141]:
                      - button "Compact inline (3 fields)" [expanded] [ref=e142] [cursor=pointer]
                    - region "Compact inline (3 fields)" [ref=e145]:
                      - group [ref=e147]:
                        - generic "Batch Increment command form" [ref=e148]:
                          - generic [ref=e149]:
                            - generic [ref=e150]:
                              - generic [ref=e152]:
                                - generic: Amount
                                - generic "Amount" [ref=e154]:
                                  - textbox "Amount, Required" [ref=e156]: "1"
                              - generic [ref=e158]:
                                - generic: Note
                                - generic "Note" [ref=e160]:
                                  - textbox "Note, Required" [ref=e162]
                              - generic [ref=e164]:
                                - generic: Effective Date
                                - generic "Effective Date" [ref=e166]:
                                  - generic [ref=e167]:
                                    - textbox "Effective Date" [ref=e168]:
                                      - /placeholder: M/d/yyyy
                                      - text: 10/16/2026
                                    - button "Show date picker" [ref=e170]
                              - button "Batch Increment" [ref=e172] [cursor=pointer]
                            - status [ref=e174]
                  - generic [ref=e175]:
                    - heading [level=2] [ref=e176]:
                      - button "Inline + popover (1 field)" [expanded] [ref=e177] [cursor=pointer]
                    - region "Inline + popover (1 field)" [ref=e180]:
                      - button "Increment" [ref=e181] [cursor=pointer]
                  - generic [ref=e185]:
                    - heading [level=2] [ref=e186]:
                      - button "Full-page command (5 fields)" [expanded] [ref=e187] [cursor=pointer]
                    - region "Full-page command (5 fields)" [ref=e190]:
                      - generic:
                        - note [ref=e191]: Navigation state persistence (scroll, filter, sort across FullPage round-trip) lands in Story 4.3. The current demo proves routing + breadcrumb return only.
                        - link [ref=e192] [cursor=pointer]:
                          - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                          - generic [ref=e193]:
                            - generic:
                              - link [ref=e194]:
                                - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                              - text: Configure Counter
          - status [ref=e195]
    - generic [ref=e196]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  920  |   await page.locator('button').focus();
  921  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  922  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  923  |   await page.addStyleTag({ content: 'button:focus{box-shadow:10px 0 0 2px black}' });
  924  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  925  | });
  926  | 
  927  | test('R12 permanent shadow cannot certify an invisible focus-only layer', async ({ page }) => {
  928  |   await page.setContent('<style>button{margin:40px;background:white;outline:none;box-shadow:0 0 0 3px black}button:focus{box-shadow:0 0 0 3px black,0 0 0 1px white}</style><button>Action</button>');
  929  |   await page.locator('button').focus();
  930  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty|contrast failures/);
  931  |   await page.addStyleTag({ content: 'button:focus{box-shadow:0 0 0 3px black,0 0 0 5px black}' });
  932  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  933  | });
  934  | 
  935  | test('R13 inset pseudo focus border compares against control paint', async ({ page }) => {
  936  |   await page.setContent('<style>button{position:relative;margin:40px;background:black;color:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black}</style><button>Action</button>');
  937  |   await page.locator('button').focus();
  938  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  939  |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  940  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  941  | });
  942  | 
  943  | test('R14 placeholder alpha determines effective contrast', async ({ page }) => {
  944  |   await page.setContent('<style>input{background:white;color:black}input::placeholder{color:black;opacity:.1}</style><input placeholder="Meaningful placeholder">');
  945  |   await expect(expectSurfaceContrast(page.locator('input'))).rejects.toThrow(/contrast failures/);
  946  |   await page.addStyleTag({ content: 'input::placeholder{opacity:1}' });
  947  |   await expectSurfaceContrast(page.locator('input'));
  948  | });
  949  | 
  950  | test('reflow rejects unlabelled nested horizontal scrolling and stale or unjustified target exceptions', async ({ page }) => {
  951  |   await page.setContent('<div style="width:100px;overflow:auto"><div style="width:200px">Long content</div></div><button id="small" style="width:10px;height:10px;padding:0">A</button>');
  952  |   await expect(expectNoPageOverflow(page)).rejects.toThrow(/scroll/);
  953  |   const record: TargetException = { selector: '#small', kind: 'Essential', rationale: 'Small fixture', keyboardPath: 'Tab', evidence: 'fixture' };
  954  |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('Essential');
  955  |   await page.locator('#small').evaluate(node => { node.style.width = node.style.height = '30px'; });
  956  |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('stale');
  957  | });
  958  | 
  959  | test('R15 owned Settings return cancels the actual Fluent delayed return after an operator Tab', async ({ page }) => {
  960  |   await page.goto('/counter');
  961  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  962  |   await page.goto('/__frontcomposer/specimens/page-toolbar');
  963  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  964  |   await page.getByTitle('Change theme').first().click();
  965  |   await page.getByRole('menuitem', { name: 'Dark', exact: true }).click();
  966  |   const toolbar = new (await import('../page-objects/page-toolbar-specimen.page.js')).PageToolbarSpecimenPage(page);
  967  |   await toolbar.summaryTab.focus();
  968  |   await toolbar.summaryTab.press('ArrowRight');
  969  |   await page.getByTestId('fc-palette-trigger').click();
  970  |   await expect(page.getByTestId('fc-palette-search')).toBeFocused();
  971  |   await page.getByTestId('fc-palette-search').locator('input').fill('no-match-accessibility-136');
  972  |   await page.keyboard.press('Escape');
  973  |   await expect(page.getByTestId('fc-palette-trigger')).toBeFocused();
  974  |   await page.keyboard.press('Tab');
  975  |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  976  |   await page.keyboard.press('Enter');
  977  |   await expect(page.locator('#fc-settings-heading')).toBeFocused();
  978  |   await page.keyboard.press('Tab');
  979  |   await page.keyboard.press('Tab');
  980  |   await page.evaluate(async () => {
  981  |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  982  |     const focus = await import(path) as { containDialogFocus: (testId: string) => boolean };
  983  |     if (!focus.containDialogFocus('fc-settings-dialog')) throw new Error('palette containment did not attach');
  984  |     const host = document.querySelector<HTMLElement>('[data-testid="fc-settings-dialog"]')!.closest('fluent-dialog')!;
  985  |     const w = window as typeof window & { __aeVendorReturn?: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } };
  986  |     const callbacks: (() => void)[] = [];
  987  |     const original = window.setTimeout;
  988  |     window.setTimeout = ((handler: TimerHandler, delay?: number, ...args: unknown[]) => {
  989  |       // Hold the pinned Fluent callback itself, rather than substitute a synthetic return.
  990  |       if (delay === 25 && typeof handler === 'function' && new Error().stack?.includes('Microsoft.FluentUI.AspNetCore.Components.lib.module.js')) {
  991  |         callbacks.push(() => handler(...args));
  992  |         return 0;
  993  |       }
  994  |       return original(handler, delay, ...args);
  995  |     }) as typeof window.setTimeout;
  996  |     w.__aeVendorReturn = { host, callbacks, restore: () => { window.setTimeout = original; } };
  997  |   });
  998  |   await page.keyboard.press('Escape');
  999  |   await expect(page.getByTestId('fc-settings-dialog')).toHaveCount(0);
  1000 |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  1001 |   await page.keyboard.press('Shift+Tab');
  1002 |   const settings = page.getByTestId('fc-palette-trigger');
  1003 |   await expect(settings).toBeFocused();
  1004 |   const proof = await page.evaluate(() => {
  1005 |     const state = (window as typeof window & { __aeVendorReturn: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } }).__aeVendorReturn;
  1006 |     state.restore();
  1007 |     const proof = { queued: state.callbacks.length, cleared: state.host.previousActiveElement === null };
  1008 |     for (const callback of state.callbacks) callback();
  1009 |     return proof;
  1010 |   });
  1011 |   expect(proof.queued).toBeGreaterThan(0);
  1012 |   expect(proof.cleared).toBe(true);
  1013 |   await expect(settings).toBeFocused();
  1014 | });
  1015 | 
  1016 | 
  1017 | test('reused owned dialog dismissal resets only its current return and preserves later external input', async ({ page }) => {
  1018 |   await page.goto('/counter');
  1019 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
> 1020 |   await page.evaluate(async () => {
       |              ^ Error: page.evaluate: Error: later external input was discarded
  1021 |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  1022 |     const focus = await import(path) as { containDialogFocus: (testId: string) => boolean };
  1023 |     const host = document.createElement('fluent-dialog');
  1024 |     host.hidden = true;
  1025 |     host.innerHTML = '<div data-testid="fc-settings-dialog"></div>';
  1026 |     document.body.append(host);
  1027 |     const w = window as typeof window & { __fcModalReservation?: { watchFocus: boolean; moved: boolean }; __fcOverlayOpenIntent?: { watchFocus: boolean; moved: boolean } };
  1028 |     for (let opening = 0; opening < 2; opening++) {
  1029 |       const reservation = { watchFocus: true, moved: true };
  1030 |       const intent = { watchFocus: true, moved: true };
  1031 |       w.__fcModalReservation = reservation;
  1032 |       w.__fcOverlayOpenIntent = intent;
  1033 |       if (!focus.containDialogFocus('fc-settings-dialog')) throw new Error('reused host containment failed');
  1034 |       host.dispatchEvent(new CustomEvent('beforetoggle', { detail: { newState: 'closed' } }));
  1035 |       if (reservation.watchFocus || reservation.moved || intent.watchFocus || intent.moved) throw new Error('native return retained modal input tracking');
  1036 |       document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
  1037 |       document.querySelector<HTMLElement>('[data-testid="fc-settings-button"]')!.focus();
  1038 |       if (!reservation.watchFocus || !reservation.moved || !intent.watchFocus || !intent.moved) throw new Error('later external input was discarded');
  1039 |     }
  1040 |     delete w.__fcModalReservation;
  1041 |     delete w.__fcOverlayOpenIntent;
  1042 |     host.remove();
  1043 |   });
  1044 | });
  1045 | 
  1046 | test('forced-color replacement capability is recorded for its engine and run', async ({ page }, info) => {
  1047 |   await page.setContent('<span style="color:rgb(255,0,0);background:rgb(0,255,0);forced-color-adjust:auto">Capability</span>');
  1048 |   await page.emulateMedia({ forcedColors: 'active' });
  1049 |   const forced = await page.locator('span').evaluate(element => {
  1050 |     const css = getComputedStyle(element);
  1051 |     return { forcedColors: matchMedia('(forced-colors: active)').matches, color: css.color, background: css.backgroundColor };
  1052 |   });
  1053 |   const authoredColorReplacement = forced.color !== 'rgb(255, 0, 0)' && forced.background !== 'rgb(0, 255, 0)';
  1054 |   if (!authoredColorReplacement) expect(info.project.name).toBe('webkit');
  1055 |   const path = info.outputPath(`forced-colors-capability-${info.project.name}.json`);
  1056 |   await (await import('node:fs/promises')).writeFile(path, JSON.stringify({ engine: info.project.name, runId: process.env.FC_A11Y_EVIDENCE_RUN_ID, testId: info.testId, attempt: info.retry, authoredColorReplacement, forced }));
  1057 |   await info.attach('forced-color-capability', { path, contentType: 'application/json' });
  1058 | });
  1059 | 
  1060 | 
  1061 | test('desktop rail flyout controls fit both 72px and 48px rails without horizontal scrolling', async ({ page }) => {
  1062 |   await page.setViewportSize({ width: 1600, height: 900 });
  1063 |   await page.goto('/__frontcomposer/specimens/type?density=compact');
  1064 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1065 |   const rail = page.getByTestId('fc-shell-navigation').getByTestId('fc-navigation-rail');
  1066 |   for (const width of [72, 48]) {
  1067 |     if (width === 48) await page.getByTestId('fc-hamburger-toggle').click();
  1068 |     await expect(rail).toHaveAttribute('data-rail-width', String(width));
  1069 |     await expect.poll(async () => (await rail.boundingBox())?.width).toBe(width);
  1070 |     for (const forcedColors of ['none', 'active'] as const) {
  1071 |       await page.emulateMedia({ forcedColors });
  1072 |       await expectNoPageOverflow(page);
  1073 |       const regions = await page.getByTestId('fc-shell-navigation').evaluate(element => ({ client: element.clientWidth, scroll: element.scrollWidth }));
  1074 |       expect(regions.scroll).toBeLessThanOrEqual(regions.client + 1);
  1075 |       await expect(rail.locator('[data-testid="fc-nav-flyout-trigger-Counter"]')).toHaveAttribute('icon-only', '');
  1076 |     }
  1077 |   }
  1078 | });
  1079 | 
```