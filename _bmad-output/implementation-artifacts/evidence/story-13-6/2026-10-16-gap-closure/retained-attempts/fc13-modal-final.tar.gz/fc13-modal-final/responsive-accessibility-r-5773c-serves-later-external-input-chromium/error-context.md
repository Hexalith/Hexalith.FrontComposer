# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> reused owned dialog dismissal resets only its current return and preserves later external input
- Location: specs/responsive-accessibility.spec.ts:1017:1

# Error details

```
Error: page.evaluate: Error: later external input was discarded
    at eval (eval at evaluate (:311:30), <anonymous>:32:103)
    at async <anonymous>:337:30
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /counter#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /counter#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - button "Toggle navigation" [ref=e12] [cursor=pointer]
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [active] [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - navigation "Primary navigation" [ref=e39]:
      - generic [ref=e40]:
        - button "Counter" [ref=e41] [cursor=pointer]
        - button "More Counter pages" [ref=e47] [cursor=pointer]
        - button "Default" [ref=e54] [cursor=pointer]
        - button "Specimens" [ref=e59] [cursor=pointer]
        - button "More Specimens pages" [ref=e65] [cursor=pointer]
    - generic [ref=e72]:
      - status [ref=e73]: Density set to Compact.
      - main [ref=e74]:
        - status [ref=e75]
        - status [ref=e76]
        - generic [ref=e77]:
          - heading "Counter" [level=1] [ref=e78]
          - generic "Counter pages" [ref=e79]:
            - tablist [ref=e80]:
              - generic:
                - tab "Overview" [selected] [ref=e81] [cursor=pointer]
                - tab "Projection" [ref=e83] [cursor=pointer]
            - tabpanel "Overview" [ref=e85]:
              - generic [ref=e87]:
                - generic:
                  - generic [ref=e88]:
                    - heading [level=2] [ref=e89]:
                      - button "Create with an exact target" [expanded] [ref=e90] [cursor=pointer]
                    - region "Create with an exact target" [ref=e93]:
                      - group [ref=e95]:
                        - generic "Create Counter command form" [ref=e96]:
                          - generic [ref=e97]:
                            - generic [ref=e98]:
                              - generic [ref=e100]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e102]:
                                  - textbox "Counter key, Required" [ref=e104]
                              - generic [ref=e106]:
                                - generic: Initial Value
                                - generic "Initial Value" [ref=e108]:
                                  - textbox "Initial Value, Required" [ref=e110]: "0"
                              - button "Create Counter" [ref=e111] [cursor=pointer]
                            - status [ref=e113]
                  - generic [ref=e114]:
                    - heading [level=2] [ref=e115]:
                      - button "Update with an exact target" [expanded] [ref=e116] [cursor=pointer]
                    - region "Update with an exact target" [ref=e119]:
                      - group [ref=e121]:
                        - generic "Update Counter command form" [ref=e122]:
                          - generic [ref=e123]:
                            - generic [ref=e124]:
                              - generic [ref=e126]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e128]:
                                  - textbox "Counter key, Required" [ref=e130]
                              - generic [ref=e132]:
                                - generic: Amount
                                - generic "Amount" [ref=e134]:
                                  - textbox "Amount, Required" [ref=e136]: "1"
                              - button "Update Counter" [ref=e137] [cursor=pointer]
                            - status [ref=e139]
                  - generic [ref=e140]:
                    - heading [level=2] [ref=e141]:
                      - button "Compact inline (3 fields)" [expanded] [ref=e142] [cursor=pointer]
                    - region "Compact inline (3 fields)" [ref=e145]:
                      - group [ref=e147]:
                        - generic "Batch Increment command form" [ref=e148]:
                          - generic [ref=e149]:
                            - generic [ref=e150]:
                              - generic [ref=e152]:
                                - generic: Amount
                                - generic "Amount" [ref=e154]:
                                  - textbox "Amount, Required" [ref=e156]: "1"
                              - generic [ref=e158]:
                                - generic: Note
                                - generic "Note" [ref=e160]:
                                  - textbox "Note, Required" [ref=e162]
                              - generic [ref=e164]:
                                - generic: Effective Date
                                - generic "Effective Date" [ref=e166]:
                                  - generic [ref=e167]:
                                    - textbox "Effective Date" [ref=e168]:
                                      - /placeholder: M/d/yyyy
                                      - text: 10/16/2026
                                    - button "Show date picker" [ref=e170]
                              - button "Batch Increment" [ref=e172] [cursor=pointer]
                            - status [ref=e174]
                  - generic [ref=e175]:
                    - heading [level=2] [ref=e176]:
                      - button "Inline + popover (1 field)" [expanded] [ref=e177] [cursor=pointer]
                    - region "Inline + popover (1 field)" [ref=e180]:
                      - button "Increment" [ref=e181] [cursor=pointer]
                  - generic [ref=e185]:
                    - heading [level=2] [ref=e186]:
                      - button "Full-page command (5 fields)" [expanded] [ref=e187] [cursor=pointer]
                    - region "Full-page command (5 fields)" [ref=e190]:
                      - generic:
                        - note [ref=e191]: Navigation state persistence (scroll, filter, sort across FullPage round-trip) lands in Story 4.3. The current demo proves routing + breadcrumb return only.
                        - link [ref=e192] [cursor=pointer]:
                          - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                          - generic [ref=e193]:
                            - generic:
                              - link [ref=e194]:
                                - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                              - text: Configure Counter
          - status [ref=e195]
    - generic [ref=e196]: Hexalith FrontComposer © 2026
```