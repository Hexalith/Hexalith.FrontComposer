# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> R15 owned Settings return cancels the actual Fluent delayed return after an operator Tab
- Location: specs/responsive-accessibility.spec.ts:959:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByTestId('fc-palette-trigger')
Expected: focused
Received: inactive
Timeout:  10000ms

Call log:
  - Expect "toBeFocused" getByTestId('fc-palette-trigger') with timeout 10000ms
  - waiting for getByTestId('fc-palette-trigger')
    24 × locator resolved to <fluent-button icon-only="" tabindex="0" role="button" appearance="subtle" data-testid="fc-palette-trigger" aria-label="Open command palette" _bl_82741488-badd-4541-bfd7-a280de283bbe="">…</fluent-button>
       - unexpected value "inactive"

```

```yaml
- button "Open command palette"
```

# Test source

```ts
  873  |   test(`R05 rejects unsupported composition ${effect}`, async ({ page }) => {
  874  |     await page.setContent(`<div style="background:black;${effect}"><p style="color:white">Meaningful label</p></div>`);
  875  |     await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/pixel evidence/);
  876  |     await page.locator('div').evaluate(node => { node.style.filter = 'none'; node.style.mixBlendMode = 'normal'; node.style.backdropFilter = 'none'; });
  877  |     await expectSurfaceContrast(page.locator('p'));
  878  |   });
  879  | }
  880  | 
  881  | test('R06 effective glyph fill determines text contrast', async ({ page }) => {
  882  |   await page.setContent('<p style="color:black;-webkit-text-fill-color:white;background:white">Invisible glyphs</p>');
  883  |   await expect(expectSurfaceContrast(page.locator('p'))).rejects.toThrow(/contrast failures/);
  884  |   await page.locator('p').evaluate(node => node.style.setProperty('-webkit-text-fill-color', 'black'));
  885  |   await expectSurfaceContrast(page.locator('p'));
  886  | });
  887  | 
  888  | test('R07 sibling background paint cannot be replaced with ancestor white', async ({ page }) => {
  889  |   await page.setContent('<div style="position:relative;background:white"><div id="under" style="position:absolute;inset:0;background:black"></div><p style="position:relative;color:black">Hidden black glyphs</p></div>');
  890  |   await expect(measureSurfaceContrast(page.locator('p'))).rejects.toThrow(/sibling background needs pixel evidence/);
  891  |   await page.locator('#under').evaluate(node => node.remove());
  892  |   await expectSurfaceContrast(page.locator('p'));
  893  | });
  894  | 
  895  | test('R08 invisible ancestor cannot certify focus geometry', async ({ page }) => {
  896  |   await page.setContent('<style>button{outline:none}button:focus{outline:2px solid black}</style><div style="opacity:0"><button>Action</button></div>');
  897  |   await page.locator('button').focus();
  898  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  899  |   await page.locator('div').evaluate(node => node.style.opacity = '1');
  900  |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  901  | });
  902  | 
  903  | test('R09 descendant extending over the target ring is an obstruction', async ({ page }) => {
  904  |   await page.setContent('<style>button{position:absolute;left:40px;top:40px;width:100px;height:40px;outline:none}button:focus{outline:2px solid black}</style><button>Action<span style="position:absolute;inset:-5px;background:white"></span></button>');
  905  |   await page.locator('button').focus();
  906  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('app content obscures target or focus ring');
  907  |   await page.locator('span').evaluate(node => node.remove());
  908  |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  909  | });
  910  | 
  911  | test('R10 generated meaningful text cannot disappear beside passing text', async ({ page }) => {
  912  |   await page.setContent('<style>div{background:white;color:black}div::before{content:"Generated label";color:#eee}</style><div>Passing label</div>');
  913  |   await expect(expectSurfaceContrast(page.locator('div'))).rejects.toThrow(/contrast failures/);
  914  |   await page.addStyleTag({ content: 'div::before{color:black}' });
  915  |   await expectSurfaceContrast(page.locator('div'));
  916  | });
  917  | 
  918  | test('R11 collapsed offset shadow paints no focus pixels', async ({ page }) => {
  919  |   await page.setContent('<style>button{appearance:none;margin:40px;outline:none}button:focus{box-shadow:10px 0 0 -100px black}</style><button>Action</button>');
  920  |   await page.locator('button').focus();
  921  |   expect((await focusGeometry(page.locator('button'))).failures).toContain('focused target has no visible focus indicator');
  922  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty/);
  923  |   await page.addStyleTag({ content: 'button:focus{box-shadow:10px 0 0 2px black}' });
  924  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  925  | });
  926  | 
  927  | test('R12 permanent shadow cannot certify an invisible focus-only layer', async ({ page }) => {
  928  |   await page.setContent('<style>button{margin:40px;background:white;outline:none;box-shadow:0 0 0 3px black}button:focus{box-shadow:0 0 0 3px black,0 0 0 1px white}</style><button>Action</button>');
  929  |   await page.locator('button').focus();
  930  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/Nonempty|contrast failures/);
  931  |   await page.addStyleTag({ content: 'button:focus{box-shadow:0 0 0 3px black,0 0 0 5px black}' });
  932  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  933  | });
  934  | 
  935  | test('R13 inset pseudo focus border compares against control paint', async ({ page }) => {
  936  |   await page.setContent('<style>button{position:relative;margin:40px;background:black;color:white;outline:none}button:focus::after{content:"";position:absolute;inset:0;border:2px solid black}</style><button>Action</button>');
  937  |   await page.locator('button').focus();
  938  |   await expect(expectSurfaceContrast(page.locator('button'), 'focus')).rejects.toThrow(/contrast failures/);
  939  |   await page.addStyleTag({ content: 'button:focus::after{border-color:white}' });
  940  |   await expectSurfaceContrast(page.locator('button'), 'focus');
  941  | });
  942  | 
  943  | test('R14 placeholder alpha determines effective contrast', async ({ page }) => {
  944  |   await page.setContent('<style>input{background:white;color:black}input::placeholder{color:black;opacity:.1}</style><input placeholder="Meaningful placeholder">');
  945  |   await expect(expectSurfaceContrast(page.locator('input'))).rejects.toThrow(/contrast failures/);
  946  |   await page.addStyleTag({ content: 'input::placeholder{opacity:1}' });
  947  |   await expectSurfaceContrast(page.locator('input'));
  948  | });
  949  | 
  950  | test('reflow rejects unlabelled nested horizontal scrolling and stale or unjustified target exceptions', async ({ page }) => {
  951  |   await page.setContent('<div style="width:100px;overflow:auto"><div style="width:200px">Long content</div></div><button id="small" style="width:10px;height:10px;padding:0">A</button>');
  952  |   await expect(expectNoPageOverflow(page)).rejects.toThrow(/scroll/);
  953  |   const record: TargetException = { selector: '#small', kind: 'Essential', rationale: 'Small fixture', keyboardPath: 'Tab', evidence: 'fixture' };
  954  |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('Essential');
  955  |   await page.locator('#small').evaluate(node => { node.style.width = node.style.height = '30px'; });
  956  |   expect((await inventoryTargets(page, [record])).inventory[0].failure).toContain('stale');
  957  | });
  958  | 
  959  | test('R15 owned Settings return cancels the actual Fluent delayed return after an operator Tab', async ({ page }) => {
  960  |   await page.goto('/counter');
  961  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  962  |   await page.goto('/__frontcomposer/specimens/page-toolbar');
  963  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  964  |   await page.getByTitle('Change theme').first().click();
  965  |   await page.getByRole('menuitem', { name: 'Dark', exact: true }).click();
  966  |   const toolbar = new (await import('../page-objects/page-toolbar-specimen.page.js')).PageToolbarSpecimenPage(page);
  967  |   await toolbar.summaryTab.focus();
  968  |   await toolbar.summaryTab.press('ArrowRight');
  969  |   await page.getByTestId('fc-palette-trigger').click();
  970  |   await expect(page.getByTestId('fc-palette-search')).toBeFocused();
  971  |   await page.getByTestId('fc-palette-search').locator('input').fill('no-match-accessibility-136');
  972  |   await page.keyboard.press('Escape');
> 973  |   await expect(page.getByTestId('fc-palette-trigger')).toBeFocused();
       |                                                        ^ Error: expect(locator).toBeFocused() failed
  974  |   await page.keyboard.press('Tab');
  975  |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  976  |   await page.keyboard.press('Enter');
  977  |   await expect(page.locator('#fc-settings-heading')).toBeFocused();
  978  |   await page.keyboard.press('Tab');
  979  |   await page.keyboard.press('Tab');
  980  |   await page.evaluate(async () => {
  981  |     const path = '/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js';
  982  |     const focus = await import(path) as { containDialogFocus: (testId: string) => boolean };
  983  |     if (!focus.containDialogFocus('fc-settings-dialog')) throw new Error('palette containment did not attach');
  984  |     const host = document.querySelector<HTMLElement>('[data-testid="fc-settings-dialog"]')!.closest('fluent-dialog')!;
  985  |     const w = window as typeof window & { __aeVendorReturn?: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } };
  986  |     const callbacks: (() => void)[] = [];
  987  |     const original = window.setTimeout;
  988  |     window.setTimeout = ((handler: TimerHandler, delay?: number, ...args: unknown[]) => {
  989  |       // Hold the pinned Fluent callback itself, rather than substitute a synthetic return.
  990  |       if (delay === 25 && typeof handler === 'function' && new Error().stack?.includes('Microsoft.FluentUI.AspNetCore.Components.lib.module.js')) {
  991  |         callbacks.push(() => handler(...args));
  992  |         return 0;
  993  |       }
  994  |       return original(handler, delay, ...args);
  995  |     }) as typeof window.setTimeout;
  996  |     w.__aeVendorReturn = { host, callbacks, restore: () => { window.setTimeout = original; } };
  997  |   });
  998  |   await page.keyboard.press('Escape');
  999  |   await expect(page.getByTestId('fc-settings-dialog')).toHaveCount(0);
  1000 |   await expect(page.getByTestId('fc-settings-button')).toBeFocused();
  1001 |   await page.keyboard.press('Shift+Tab');
  1002 |   const settings = page.getByTestId('fc-palette-trigger');
  1003 |   await expect(settings).toBeFocused();
  1004 |   const proof = await page.evaluate(() => {
  1005 |     const state = (window as typeof window & { __aeVendorReturn: { host: Element & { previousActiveElement?: Element | null }; callbacks: (() => void)[]; restore: () => void } }).__aeVendorReturn;
  1006 |     state.restore();
  1007 |     const proof = { queued: state.callbacks.length, cleared: state.host.previousActiveElement === null };
  1008 |     for (const callback of state.callbacks) callback();
  1009 |     return proof;
  1010 |   });
  1011 |   expect(proof.queued).toBeGreaterThan(0);
  1012 |   expect(proof.cleared).toBe(true);
  1013 |   await expect(settings).toBeFocused();
  1014 | });
  1015 | 
  1016 | 
  1017 | test('forced-color replacement capability is recorded for its engine and run', async ({ page }, info) => {
  1018 |   await page.setContent('<span style="color:rgb(255,0,0);background:rgb(0,255,0);forced-color-adjust:auto">Capability</span>');
  1019 |   await page.emulateMedia({ forcedColors: 'active' });
  1020 |   const forced = await page.locator('span').evaluate(element => {
  1021 |     const css = getComputedStyle(element);
  1022 |     return { forcedColors: matchMedia('(forced-colors: active)').matches, color: css.color, background: css.backgroundColor };
  1023 |   });
  1024 |   const authoredColorReplacement = forced.color !== 'rgb(255, 0, 0)' && forced.background !== 'rgb(0, 255, 0)';
  1025 |   if (!authoredColorReplacement) expect(info.project.name).toBe('webkit');
  1026 |   const path = info.outputPath(`forced-colors-capability-${info.project.name}.json`);
  1027 |   await (await import('node:fs/promises')).writeFile(path, JSON.stringify({ engine: info.project.name, runId: process.env.FC_A11Y_EVIDENCE_RUN_ID, testId: info.testId, attempt: info.retry, authoredColorReplacement, forced }));
  1028 |   await info.attach('forced-color-capability', { path, contentType: 'application/json' });
  1029 | });
  1030 | 
  1031 | 
  1032 | test('desktop rail flyout controls fit both 72px and 48px rails without horizontal scrolling', async ({ page }) => {
  1033 |   await page.setViewportSize({ width: 1600, height: 900 });
  1034 |   await page.goto('/__frontcomposer/specimens/type?density=compact');
  1035 |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  1036 |   const rail = page.getByTestId('fc-shell-navigation').getByTestId('fc-navigation-rail');
  1037 |   for (const width of [72, 48]) {
  1038 |     if (width === 48) await page.getByTestId('fc-hamburger-toggle').click();
  1039 |     await expect(rail).toHaveAttribute('data-rail-width', String(width));
  1040 |     await expect.poll(async () => (await rail.boundingBox())?.width).toBe(width);
  1041 |     for (const forcedColors of ['none', 'active'] as const) {
  1042 |       await page.emulateMedia({ forcedColors });
  1043 |       await expectNoPageOverflow(page);
  1044 |       const regions = await page.getByTestId('fc-shell-navigation').evaluate(element => ({ client: element.clientWidth, scroll: element.scrollWidth }));
  1045 |       expect(regions.scroll).toBeLessThanOrEqual(regions.client + 1);
  1046 |       await expect(rail.locator('[data-testid="fc-nav-flyout-trigger-Counter"]')).toHaveAttribute('icon-only', '');
  1047 |     }
  1048 |   }
  1049 | });
  1050 | 
```