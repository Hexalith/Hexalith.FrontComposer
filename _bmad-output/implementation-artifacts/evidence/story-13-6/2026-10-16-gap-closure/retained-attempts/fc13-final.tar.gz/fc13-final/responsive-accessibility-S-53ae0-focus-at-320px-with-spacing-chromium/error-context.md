# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> Story 13.6 responsive operator surfaces >> palette and settings retain reflow, every target, and modal focus at 320px with spacing
- Location: specs/responsive-accessibility.spec.ts:448:3

# Error details

```
Error: AE-05 focused visual geometry

AE-05 focused visual geometry

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "app content obscures target or focus ring: {\"target\":\"FLUENT-ACCORDION-ITEM#f35ce43d\",\"requireIndicator\":true,\"box\":{\"left\":64,\"top\":78,\"right\":256,\"bottom\":522},\"ring\":0,\"failures\":[\"app content obscures target or focus ring\"],\"occluder\":\"FLUENT-ACCORDION-ITEM#f35ce43d by SPAN# at 149.34375,237\"}",
+ ]

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /counter#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /counter#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - button "Toggle navigation" [ref=e12] [cursor=pointer]
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - generic [ref=e42]:
          - heading "Counter" [level=1] [ref=e43]
          - generic "Counter pages" [ref=e44]:
            - tablist [ref=e45]:
              - generic:
                - tab "Overview" [selected] [ref=e46] [cursor=pointer]
                - tab "Projection" [ref=e48] [cursor=pointer]
            - tabpanel "Overview" [ref=e50]:
              - generic [ref=e52]:
                - generic:
                  - generic [ref=e53]:
                    - heading [level=2] [ref=e54]:
                      - button "Create with an exact target" [expanded] [ref=e55] [cursor=pointer]
                    - region "Create with an exact target" [ref=e58]:
                      - group [ref=e60]:
                        - generic "Create Counter command form" [ref=e61]:
                          - generic [ref=e62]:
                            - generic [ref=e63]:
                              - generic [ref=e65]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e67]:
                                  - textbox "Counter key, Required" [ref=e69]
                              - generic [ref=e71]:
                                - generic: Initial Value
                                - generic "Initial Value" [ref=e73]:
                                  - textbox "Initial Value, Required" [ref=e75]: "0"
                              - button "Create Counter" [ref=e76] [cursor=pointer]
                            - status [ref=e78]
                  - generic [ref=e79]:
                    - heading [level=2] [ref=e80]:
                      - button "Update with an exact target" [expanded] [ref=e81] [cursor=pointer]
                    - region "Update with an exact target" [ref=e84]:
                      - group [ref=e86]:
                        - generic "Update Counter command form" [ref=e87]:
                          - generic [ref=e88]:
                            - generic [ref=e89]:
                              - generic [ref=e91]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e93]:
                                  - textbox "Counter key, Required" [ref=e95]
                              - generic [ref=e97]:
                                - generic: Amount
                                - generic "Amount" [ref=e99]:
                                  - textbox "Amount, Required" [ref=e101]: "1"
                              - button "Update Counter" [ref=e102] [cursor=pointer]
                            - status [ref=e104]
                  - generic [ref=e105]:
                    - heading [level=2] [ref=e106]:
                      - button "Compact inline (3 fields)" [expanded] [ref=e107] [cursor=pointer]
                    - region "Compact inline (3 fields)" [ref=e110]:
                      - group [ref=e112]:
                        - generic "Batch Increment command form" [ref=e113]:
                          - generic [ref=e114]:
                            - generic [ref=e115]:
                              - generic [ref=e117]:
                                - generic: Amount
                                - generic "Amount" [ref=e119]:
                                  - textbox "Amount, Required" [ref=e121]: "1"
                              - generic [ref=e123]:
                                - generic: Note
                                - generic "Note" [ref=e125]:
                                  - textbox "Note, Required" [ref=e127]
                              - generic [ref=e129]:
                                - generic: Effective Date
                                - generic "Effective Date" [ref=e131]:
                                  - generic [ref=e132]:
                                    - textbox "Effective Date" [ref=e133]:
                                      - /placeholder: M/d/yyyy
                                      - text: 10/16/2026
                                    - button "Show date picker" [ref=e135]
                              - button "Batch Increment" [ref=e137] [cursor=pointer]
                            - status [ref=e139]
                  - generic [ref=e140]:
                    - heading [level=2] [ref=e141]:
                      - button "Inline + popover (1 field)" [expanded] [ref=e142] [cursor=pointer]
                    - region "Inline + popover (1 field)" [ref=e145]:
                      - button "Increment" [ref=e146] [cursor=pointer]
                  - generic [ref=e150]:
                    - heading [level=2] [ref=e151]:
                      - button "Full-page command (5 fields)" [expanded] [ref=e152] [cursor=pointer]
                    - region "Full-page command (5 fields)" [ref=e155]:
                      - generic:
                        - note [ref=e156]: Navigation state persistence (scroll, filter, sort across FullPage round-trip) lands in Story 4.3. The current demo proves routing + breadcrumb return only.
                        - link [ref=e157] [cursor=pointer]:
                          - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                          - generic [ref=e158]:
                            - generic:
                              - link [ref=e159]:
                                - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                              - text: Configure Counter
          - status [ref=e160]
    - generic [ref=e161]: Hexalith FrontComposer © 2026
  - alertdialog [ref=e164]:
    - generic [ref=e165]:
      - heading "Settings" [level=2] [ref=e169]
      - generic [ref=e173]:
        - generic:
          - generic [active] [ref=e174]:
            - heading [level=2] [ref=e175]:
              - button "Display density" [expanded] [ref=e176] [cursor=pointer]
            - region "Display density" [ref=e179]:
              - generic:
                - generic "Display density" [ref=e181] [cursor=pointer]:
                  - generic:
                    - generic [ref=e182]:
                      - generic: Compact
                      - generic "Compact" [ref=e184]
                    - generic [ref=e186]:
                      - generic: Comfortable
                      - generic "Comfortable" [ref=e188]
                    - generic [ref=e190]:
                      - generic: Roomy
                      - generic "Roomy" [ref=e192]
                - generic [ref=e194]: Your device size is forcing Comfortable density. Your preference will re-apply at larger screen sizes.
          - heading [level=2] [ref=e199]:
            - button "Theme" [ref=e200] [cursor=pointer]
          - heading [level=2] [ref=e204]:
            - button "Preview" [ref=e205] [cursor=pointer]
      - generic [ref=e210]:
        - generic [ref=e211]:
          - generic [ref=e212] [cursor=pointer]: Restore defaults
          - generic [ref=e214]: Clears density preference and sets theme to follow system.
        - generic [ref=e215] [cursor=pointer]: Done
```

# Test source

```ts
  408 |     const ownsDropdownIndicator = (candidate: Element) => {
  409 |       // Fluent's light-DOM combobox and fallback SVG occupy sibling shadow slots.
  410 |       // Their common host owns the passive indicator, but not arbitrary overlapping siblings.
  411 |       const host = element.matches('button[slot="control"][role="combobox"]') ? element.parentElement : null;
  412 |       if (!host?.matches('fluent-dropdown') || element.assignedSlot?.getRootNode() !== host.shadowRoot) return false;
  413 |       const icon = candidate.closest('svg[aria-hidden="true"]');
  414 |       if (!icon || icon.matches('[tabindex],a[href]') || icon.querySelector('[tabindex],a[href]')) return false;
  415 |       const bounds = icon.getBoundingClientRect(), control = host.getBoundingClientRect();
  416 |       if (bounds.left < control.left || bounds.top < control.top || bounds.right > control.right || bounds.bottom > control.bottom) return false;
  417 |       for (let owner: Element | null = icon; owner && owner !== host; owner = parent(owner)) {
  418 |         if (owner instanceof HTMLSlotElement && owner.name === 'indicator' && owner.getRootNode() === host.shadowRoot) return true;
  419 |       }
  420 |       return false;
  421 |     };
  422 |     const related = (candidate: Element) => {
  423 |       if (contains(candidate, element) || ownsDropdownIndicator(candidate)) return true;
  424 |       if (!contains(element, candidate)) return false;
  425 |       const bounds = candidate.getBoundingClientRect(), css = getComputedStyle(candidate);
  426 |       // Ordinary flow content belongs to its target; a positioned opaque descendant
  427 |       // crossing the target frame can cover the indicator and must be measured.
  428 |       if (css.position === 'static') return true;
  429 |       const contained = bounds.left >= rect.left && bounds.top >= rect.top && bounds.right <= rect.right && bounds.bottom <= rect.bottom;
  430 |       const root = candidate.getRootNode();
  431 |       const nativePart = root instanceof ShadowRoot && root.host === element && candidate.matches('.control,.content,.indicator,.checked-indicator');
  432 |       return contained && (audit.parse(css.backgroundColor)[3] === 0 || nativePart);
  433 |     };
  434 |     // Test every overlapping app box at its intersection center. This detects even a small
  435 |     // off-center obstruction missed by center-only or in-viewport assertions.
  436 |     const candidates: Element[] = [];
  437 |     const visitOccluders = (root: Document | ShadowRoot) => {
  438 |       for (const candidate of root.querySelectorAll('*')) {
  439 |         candidates.push(candidate);
  440 |         if (candidate.shadowRoot) visitOccluders(candidate.shadowRoot);
  441 |       }
  442 |     };
  443 |     visitOccluders(document);
  444 |     const deepestHit = (x: number, y: number) => {
  445 |       let hit = document.elementFromPoint(x, y);
  446 |       while (hit?.shadowRoot) {
  447 |         const inner = hit.shadowRoot.elementFromPoint(x, y);
  448 |         if (!inner || inner === hit) break;
  449 |         hit = inner;
  450 |       }
  451 |       return hit;
  452 |     };
  453 |     for (const candidate of candidates) {
  454 |       if (related(candidate)) continue;
  455 |       const css = getComputedStyle(candidate), other = candidate.getBoundingClientRect();
  456 |       if (css.visibility === 'hidden' || css.display === 'none' || Number(css.opacity) === 0 || other.width === 0 || other.height === 0) continue;
  457 |       const left = Math.max(box.left, other.left), right = Math.min(box.right, other.right);
  458 |       const top = Math.max(box.top, other.top), bottom = Math.min(box.bottom, other.bottom);
  459 |       if (left >= right || top >= bottom) continue;
  460 |       const x = (left + right) / 2, y = (top + bottom) / 2;
  461 |       let hit: Element | null;
  462 |       const probe = candidate as HTMLElement;
  463 |       const originalStyle = probe.getAttribute('style');
  464 |       const pointerOptOut = css.pointerEvents === 'none';
  465 |       try {
  466 |         if (pointerOptOut) probe.style.setProperty('pointer-events', 'auto', 'important');
  467 |         hit = deepestHit(x, y);
  468 |       } finally {
  469 |         if (pointerOptOut) { if (originalStyle === null) probe.removeAttribute('style'); else probe.setAttribute('style', originalStyle); }
  470 |       }
  471 |       const insideTarget = x > rect.left + .5 && x < rect.right - .5 && y > rect.top + .5 && y < rect.bottom - .5;
  472 |       const paintsAtPoint = (hit: Element) => {
  473 |         const css = getComputedStyle(hit);
  474 |         const alpha = audit.parse(css.backgroundColor)[3];
  475 |         if (alpha > 0 || css.backgroundImage !== 'none' || hit instanceof SVGGraphicsElement || hit.matches('img,video,canvas')) return true;
  476 |         return [...hit.childNodes].filter(node => node.nodeType === Node.TEXT_NODE && node.textContent?.trim()).some(node => {
  477 |           const range = document.createRange(); range.selectNodeContents(node);
  478 |           return [...range.getClientRects()].some(text => x >= text.left && x <= text.right && y >= text.top && y <= text.bottom);
  479 |         });
  480 |       };
  481 |       const paintsAbove = (a: Element, b: Element) => {
  482 |         // Compare the first divergent stacking contexts, never maxima from unrelated levels.
  483 |         const context = (node: Element) => {
  484 |           const style = getComputedStyle(node);
  485 |           return node === document.documentElement || ['fixed','sticky'].includes(style.position) || style.zIndex !== 'auto' && (style.position !== 'static' || /flex|grid/u.test(getComputedStyle(parent(node) ?? document.documentElement).display)) || style.transform !== 'none' || Number(style.opacity) < 1 || style.isolation === 'isolate' || style.filter !== 'none' || style.perspective !== 'none' || /paint|layout|strict|content/u.test(style.contain) || style.mixBlendMode !== 'normal' || /transform|opacity|filter/u.test(style.willChange);
  486 |         };
  487 |         const chain = (node: Element) => { const nodes: Element[] = []; for (let current: Element | null = node; current; current = parent(current)) if (context(current)) nodes.unshift(current); return nodes; };
  488 |         const left = chain(a), right = chain(b); let index = 0;
  489 |         while (left[index] && left[index] === right[index]) index++;
  490 |         const first = left[index] ?? a, second = right[index] ?? b;
  491 |         const az = Number.parseInt(getComputedStyle(first).zIndex) || 0, bz = Number.parseInt(getComputedStyle(second).zIndex) || 0;
  492 |         if (az !== bz) return az > bz;
  493 |         if (first.getRootNode() !== second.getRootNode()) return null;
  494 |         const phase = (node: Element) => { const style = getComputedStyle(node); return context(node) || style.position !== 'static' ? 3 : /inline/u.test(style.display) ? 2 : style.cssFloat !== 'none' ? 1 : 0; };
  495 |         if (phase(first) !== phase(second)) return phase(first) > phase(second);
  496 |         return Boolean(second.compareDocumentPosition(first) & Node.DOCUMENT_POSITION_FOLLOWING);
  497 |       };
  498 |       // Outlines are painted outside hit boxes. Content behind the outline is not an
  499 |       // obstruction simply because elementFromPoint cannot hit that outline itself.
  500 |       if (hit && !related(hit) && (!pointerOptOut || paintsAtPoint(hit)) && (insideTarget || paintsAtPoint(hit) && paintsAbove(hit, element) !== false)) { occluder = `${element.tagName}#${element.id} by ${hit.tagName}#${hit.id} at ${x},${y}`; failures.push('app content obscures target or focus ring'); break; }
  501 |     }
  502 |     return { target: `${element.tagName}#${element.id}`, requireIndicator, box, ring, failures, occluder };
  503 |   }, requireIndicator);
  504 | }
  505 | 
  506 | export async function expectFocusVisible(target: Locator): Promise<void> {
  507 |   await expect(target).toBeFocused();
> 508 |   await expect.poll(async () => { const result = await focusGeometry(target); return result.failures.map(failure => `${failure}: ${JSON.stringify(result)}`); }, { message: 'AE-05 focused visual geometry' }).toEqual([]);
      |                                                                                                                                                                                                                ^ Error: AE-05 focused visual geometry
  509 | }
  510 | 
  511 | export async function expectTextContrast(target: Locator, minimum?: number, colorProperty = 'color') {
  512 |   const sample = await target.evaluate((element, property) => {
  513 |     const parse = (value: string) => {
  514 |       const channels = value.match(/[\d.]+/gu)?.map(Number) ?? [];
  515 |       if (channels.length < 3) throw new Error('Unsupported computed color');
  516 |       return [channels[0], channels[1], channels[2], channels[3] ?? 1];
  517 |     };
  518 |     const composite = (fg: number[], bg: number[]) => [0, 1, 2].map(i => fg[i] * fg[3] + bg[i] * (1 - fg[3])).concat(1);
  519 |     const backgrounds: number[][] = [];
  520 |     for (let current: Element | null = element; current; current = current.parentElement) backgrounds.push(parse(getComputedStyle(current).backgroundColor));
  521 |     let background = [255, 255, 255, 1];
  522 |     for (const layer of backgrounds.reverse()) background = composite(layer, background);
  523 |     const css = getComputedStyle(element), foreground = composite(parse(css.getPropertyValue(property)), background);
  524 |     const luminance = (color: number[]) => color.slice(0, 3).map(channel => { const c = channel / 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, c, i) => sum + c * [.2126, .7152, .0722][i], 0);
  525 |     const a = luminance(foreground), b = luminance(background);
  526 |     const large = Number.parseFloat(css.fontSize) >= 24 || Number.parseFloat(css.fontSize) >= 18.667 && Number.parseInt(css.fontWeight) >= 700;
  527 |     return { foreground, background, ratio: (Math.max(a, b) + .05) / (Math.min(a, b) + .05), minimum: large ? 3 : 4.5 };
  528 |   }, colorProperty);
  529 |   expect(sample.ratio, JSON.stringify(sample)).toBeGreaterThanOrEqual(minimum ?? sample.minimum);
  530 |   return sample;
  531 | }
  532 | 
  533 | /** Find actual clipped text ranges, including controls inside open shadow roots. */
  534 | export async function expectNoTextClipping(page: Page): Promise<void> {
  535 |   const failures = await page.evaluate(() => {
  536 |     const failures: string[] = [];
  537 |     const visit = (root: Document | ShadowRoot) => {
  538 |       for (const element of root.querySelectorAll('*')) {
  539 |         if (element.shadowRoot) visit(element.shadowRoot);
  540 |         if (element.closest('.fc-sr-only,[aria-hidden="true"],[hidden]') || element.getClientRects().length === 0) continue;
  541 |         const css = getComputedStyle(element);
  542 |         if (css.visibility === 'hidden' || css.clip !== 'auto' || css.clipPath !== 'none') continue;
  543 |         if (!/(hidden|clip)/u.test(css.overflowX + css.overflowY)) continue;
  544 |         const box = element.getBoundingClientRect();
  545 |         if (box.width < 2 || box.height < 2) continue;
  546 |         const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
  547 |         while (walker.nextNode()) {
  548 |           const node = walker.currentNode;
  549 |           if (!node.textContent?.trim() || node.parentElement?.closest('style,script,[hidden],.fc-sr-only,.fc-skip-link:not(:focus),[aria-hidden="true"]') || node.parentElement && getComputedStyle(node.parentElement).visibility === 'hidden') continue;
  550 |           const range = document.createRange(); range.selectNodeContents(node);
  551 |           // Native popovers/dialogs paint in the top layer and escape outer overflow
  552 |           // clips. Their own clipping boxes are still evaluated independently.
  553 |           let escapesOwner = false;
  554 |           for (let parent = node.parentElement; parent && parent !== element; parent = parent.parentElement) {
  555 |             if (parent.matches(':popover-open,:modal')) { escapesOwner = true; break; }
  556 |           }
  557 |           if (escapesOwner) continue;
  558 |           if ([...range.getClientRects()].some(text => {
  559 |             let left = text.left, right = text.right, top = text.top, bottom = text.bottom;
  560 |             // A nested scrollport owns its offscreen text; evaluate only the visible portion at
  561 |             // this ancestor. Each hidden/clip owner is independently checked by the outer loop.
  562 |             for (let parent = node.parentElement; parent && parent !== element; parent = parent.parentElement) {
  563 |               const style = getComputedStyle(parent), clip = parent.getBoundingClientRect();
  564 |               if (/(auto|scroll|hidden|clip)/u.test(style.overflowX)) { left = Math.max(left, clip.left); right = Math.min(right, clip.right); }
  565 |               if (/(auto|scroll|hidden|clip)/u.test(style.overflowY)) { top = Math.max(top, clip.top); bottom = Math.min(bottom, clip.bottom); }
  566 |             }
  567 |             return right > left && bottom > top && (
  568 |               /(hidden|clip)/u.test(css.overflowX) && (left < box.left - 1 || right > box.right + 1)
  569 |               || /(hidden|clip)/u.test(css.overflowY) && (top < box.top - 1 || bottom > box.bottom + 1));
  570 |           })) {
  571 |             failures.push(element.id ? `#${element.id}` : `${element.tagName.toLowerCase()}.${String(element.className).trim().replace(/\s+/gu, '.')}`); break;
  572 |           }
  573 |         }
  574 |       }
  575 |     };
  576 |     visit(document);
  577 |     return [...new Set(failures)];
  578 |   });
  579 |   expect(failures, 'AE-03 clipped text ranges').toEqual([]);
  580 | }
  581 | 
  582 | export type ContrastKind = 'text' | 'border' | 'icon' | 'focus' | 'cue';
  583 | 
  584 | /** Sample actual painted nodes in the composed tree; empty/unsupported samples fail closed. */
  585 | export async function measureSurfaceContrast(root: Locator, kind: ContrastKind = 'text') {
  586 |   await preparePaintAudit(root);
  587 |   return root.evaluate((scope, sampleKind) => {
  588 |     const parent = (node: Element): Element | null => node.assignedSlot ?? node.parentElement ?? (node.getRootNode() instanceof ShadowRoot ? (node.getRootNode() as ShadowRoot).host : null);
  589 |     const audit = (window as typeof window & { __aePaintAudit: PaintAudit }).__aePaintAudit;
  590 |     const parse = audit.parse;
  591 |     const resting = sampleKind === 'focus' ? audit.resting(scope) : new Map();
  592 |     const composite = (fg: number[], bg: number[]) => [0, 1, 2].map(i => fg[i] * fg[3] + bg[i] * (1 - fg[3])).concat(1);
  593 |     const background = (element: Element | null) => {
  594 |       const layers: number[][] = [];
  595 |       for (let current = element; current; current = parent(current)) {
  596 |         const css = getComputedStyle(current);
  597 |         if (css.backgroundImage !== 'none') throw new Error('Background image needs pixel evidence');
  598 |         if (css.filter !== 'none' || css.mixBlendMode !== 'normal' || css.getPropertyValue('backdrop-filter') && css.getPropertyValue('backdrop-filter') !== 'none') throw new Error('Filtered or blended paint needs pixel evidence');
  599 |         if (Number(css.opacity) > 0 && Number(css.opacity) < 1) throw new Error(`Translucent group needs pixel evidence: ${current.tagName}.${current.className} opacity=${css.opacity}`);
  600 |         layers.push(parse(css.backgroundColor));
  601 |       }
  602 |       return layers.reverse().reduce((bg, fg) => composite(fg, bg), [255, 255, 255, 1]);
  603 |     };
  604 |     const luminance = (color: number[]) => color.slice(0, 3).map(channel => { const c = channel / 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, c, i) => sum + c * [.2126, .7152, .0722][i], 0);
  605 |     const visible = (element: Element) => {
  606 |       if (element.getClientRects().length === 0 && getComputedStyle(element).display !== 'contents') return false;
  607 |       for (let current: Element | null = element; current; current = parent(current)) {
  608 |         const css = getComputedStyle(current);
```