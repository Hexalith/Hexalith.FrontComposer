# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> held generated recovery cancels after user scope change in dark
- Location: specs/accessibility-state-matrix.spec.ts:597:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.fc-expanded-row-hidden-banner-text')
Expected: 0
Received: 1
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" locator('.fc-expanded-row-hidden-banner-text') with timeout 10000ms
  - waiting for locator('.fc-expanded-row-hidden-banner-text')
    24 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=dark#fc-main-content
  - link "Skip to navigation" [ref=e4]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=dark#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic:
                  - generic:
                    - button "Close"
                - generic:
                  - generic:
                    - generic:
                      - generic:
                        - navigation "Primary navigation":
                          - generic:
                            - button "Counter"
                            - generic:
                              - generic:
                                - button "More Counter pages"
                            - button "Default"
                            - button "Specimens"
                            - generic:
                              - generic:
                                - button "More Specimens pages"
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Dark"
                - generic [aria-hidden] [ref=e22]: Dark
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]: Density set to Comfortable.
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - main [ref=e43]:
          - generic [ref=e44]:
            - paragraph [ref=e45]: FrontComposer accessibility specimen
            - heading "Type, theme, density, lifecycle, and navigation specimen" [level=1] [ref=e46]
            - paragraph [ref=e47]: Generated shell surfaces rendered with deterministic local data.
            - link "Skip to command form" [ref=e48]:
              - /url: "#fc-specimen-command-form"
          - region [ref=e49]:
            - heading "Theme and density controls" [level=2] [ref=e50]
            - generic [ref=e51]:
              - link "light" [ref=e52]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "dark" [ref=e53]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "compact" [ref=e54]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "comfortable" [ref=e55]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=comfortable&generatedGrid=true&accessibilityScenarios=true
              - link "roomy" [ref=e56]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=roomy&generatedGrid=true&accessibilityScenarios=true
          - region [ref=e57]:
            - heading "Type ramp" [level=2] [ref=e58]
            - generic [ref=e59]:
              - article [ref=e60]:
                - paragraph [ref=e61]: Display
                - generic [ref=e62]: FrontComposer Display
              - article [ref=e63]:
                - paragraph [ref=e64]: Title
                - generic [ref=e65]: Generated command title
              - article [ref=e66]:
                - paragraph [ref=e67]: Subtitle
                - generic [ref=e68]: Projection subtitle and context
              - article [ref=e69]:
                - paragraph [ref=e70]: Body
                - generic [ref=e71]: Readable generated body text
              - article [ref=e72]:
                - paragraph [ref=e73]: Caption
                - generic [ref=e74]: Supplemental metadata caption
              - article [ref=e75]:
                - paragraph [ref=e76]: Code
                - generic [ref=e77]: FC-STATIC-0001
          - region [ref=e78]:
            - heading "Semantic color tokens" [level=2] [ref=e79]
            - generic [ref=e80]:
              - article [ref=e81]:
                - heading "light theme" [level=3] [ref=e82]
                - generic [ref=e83]:
                  - generic [ref=e85]: Neutral
                  - strong [ref=e86]: Available
                - generic [ref=e87]:
                  - generic [ref=e89]: Informational
                  - strong [ref=e90]: Queued
                - generic [ref=e91]:
                  - generic [ref=e93]: Success
                  - strong [ref=e94]: Confirmed
                - generic [ref=e95]:
                  - generic [ref=e97]: Warning
                  - strong [ref=e98]: Needs review
                - generic [ref=e99]:
                  - generic [ref=e101]: Danger
                  - strong [ref=e102]: Rejected
                - generic [ref=e103]:
                  - generic [ref=e105]: Accent
                  - strong [ref=e106]: Selected
              - article [ref=e107]:
                - heading "dark theme" [level=3] [ref=e108]
                - generic [ref=e109]:
                  - generic [ref=e111]: Neutral
                  - strong [ref=e112]: Available
                - generic [ref=e113]:
                  - generic [ref=e115]: Informational
                  - strong [ref=e116]: Queued
                - generic [ref=e117]:
                  - generic [ref=e119]: Success
                  - strong [ref=e120]: Confirmed
                - generic [ref=e121]:
                  - generic [ref=e123]: Warning
                  - strong [ref=e124]: Needs review
                - generic [ref=e125]:
                  - generic [ref=e127]: Danger
                  - strong [ref=e128]: Rejected
                - generic [ref=e129]:
                  - generic [ref=e131]: Accent
                  - strong [ref=e132]: Selected
          - region [ref=e133]:
            - heading "Density states" [level=2] [ref=e134]
            - generic [ref=e135]:
              - article [ref=e136]:
                - heading "compact density" [level=3] [ref=e137]
                - button "Primary action" [ref=e138]
                - generic [ref=e139]:
                  - text: Label
                  - textbox "compact density text input" [ref=e140]: compact sample
              - article [ref=e141]:
                - heading "comfortable density" [level=3] [ref=e142]
                - button "Primary action" [ref=e143]
                - generic [ref=e144]:
                  - text: Label
                  - textbox "comfortable density text input" [ref=e145]: comfortable sample
              - article [ref=e146]:
                - heading "roomy density" [level=3] [ref=e147]
                - button "Primary action" [ref=e148]
                - generic [ref=e149]:
                  - text: Label
                  - textbox "roomy density text input" [ref=e150]: roomy sample
          - region [ref=e151]:
            - heading "Generated projection DataGrid and badge states" [level=2] [ref=e152]
            - status [ref=e153]
            - paragraph [ref=e154]: 6 specimen status
            - group "Status filter chips" [ref=e155]:
              - button "Neutral, currently inactive" [ref=e156] [cursor=pointer]:
                - generic [ref=e157]: Neutral
              - button "Info, currently inactive" [ref=e158] [cursor=pointer]:
                - generic [ref=e159]: Info
              - button "Success, currently inactive" [ref=e160] [cursor=pointer]:
                - generic [ref=e161]: Success
              - button "Warning, currently inactive" [ref=e162] [cursor=pointer]:
                - generic [ref=e163]: Warning
              - button "Danger, currently inactive" [ref=e164] [cursor=pointer]:
                - generic [ref=e165]: Danger
              - button "Accent, currently inactive" [ref=e166] [cursor=pointer]:
                - generic [ref=e167]: Accent
            - text: 6 specimen status
            - region "specimen status" [ref=e168]:
              - table [ref=e169]:
                - rowgroup [ref=e170]:
                  - row [ref=e171]:
                    - columnheader "Id" [ref=e172]
                    - columnheader "Name" [ref=e176]
                    - columnheader "Status" [ref=e180]
                    - columnheader "Owner" [ref=e184]
                - rowgroup [ref=e188]:
                  - row [aria-hidden] [ref=e189]
              - region "Details for"
          - region "Automated accessibility scenarios" [ref=e190]:
            - heading "Fixed accessibility scenarios" [level=2] [ref=e191]
            - generic [ref=e192]:
              - generic [ref=e193] [cursor=pointer]: validation
              - generic [ref=e195] [cursor=pointer]: returned-rejection
              - generic [ref=e197] [cursor=pointer]: exception-rejection
              - generic [ref=e199] [cursor=pointer]: forbidden
              - generic [ref=e201] [cursor=pointer]: unavailable
              - generic [ref=e203] [cursor=pointer]: blank-unavailable
              - generic [ref=e205] [cursor=pointer]: rate-limited
              - generic [ref=e207] [cursor=pointer]: blank-rate-limited
              - generic [ref=e209] [cursor=pointer]: transport
              - generic [ref=e211] [cursor=pointer]: admission
              - generic [ref=e213] [cursor=pointer]: policy
              - generic [ref=e215] [cursor=pointer]: accepted
            - paragraph [ref=e217]: validation
            - generic [ref=e218]:
              - button "Run accessibility specimen" [ref=e219] [cursor=pointer]
              - status [ref=e223]
            - status "New item added outside current filters" [ref=e225]: New item. It may not match current filters yet.
            - generic [ref=e226]:
              - generic [ref=e227] [cursor=pointer]: Idle
              - generic [ref=e229] [cursor=pointer]: Submitting
              - generic [ref=e231] [cursor=pointer]: Acknowledged
              - generic [ref=e233] [cursor=pointer]: Syncing
              - generic [ref=e235] [cursor=pointer]: Confirmed
              - generic [ref=e237] [cursor=pointer]: Rejected
              - generic [ref=e239] [cursor=pointer]: IdempotentConfirmed
              - generic [ref=e241] [cursor=pointer]: NeedsReview
              - generic [ref=e243] [cursor=pointer]: Warning
              - generic [ref=e245] [cursor=pointer]: Degraded
              - generic [ref=e247] [cursor=pointer]: DegradedExhausted
            - generic [ref=e249]:
              - generic: Observable lifecycle specimen
              - status [ref=e250]
            - generic [ref=e251]:
              - generic [ref=e252] [cursor=pointer]: Connected
              - generic [ref=e254] [cursor=pointer]: Reconnecting
              - generic [ref=e256] [cursor=pointer]: Disconnected
              - generic [ref=e258] [cursor=pointer]: Start held page
              - generic [ref=e260] [cursor=pointer]: Complete held page
              - generic [ref=e262] [cursor=pointer]: Complete capped page
              - generic [ref=e264] [cursor=pointer]: Apply no-match filter
              - generic [ref=e266] [cursor=pointer]: Reset filter
            - generic [ref=e268]:
              - generic [ref=e269] [cursor=pointer]: Load two rows
              - generic [ref=e271] [cursor=pointer]: Complete missing row result
              - generic [ref=e273] [cursor=pointer]: Complete empty result
              - generic [ref=e275] [cursor=pointer]: Complete failed result
              - generic [ref=e277] [cursor=pointer]: Start pending result
              - generic [ref=e279] [cursor=pointer]: Complete delayed missing result
              - generic [ref=e281] [cursor=pointer]: Change fixed tenant
              - generic [ref=e283] [cursor=pointer]: Change fixed user
              - generic [ref=e285] [cursor=pointer]: Repeat completed result
          - region [ref=e287]:
            - heading "Generated Counter projection grid" [level=2] [ref=e288]
            - status [ref=e289]
            - paragraph [ref=e290]: 1 counters
            - text: 1 counters
            - region "counters" [ref=e291]:
              - group [ref=e292]: The expanded item is not in the current results.
              - table [ref=e293]:
                - rowgroup [ref=e294]:
                  - row [ref=e295]:
                    - columnheader "Id" [ref=e296]
                    - columnheader "Count" [ref=e300]
                    - columnheader "Last changed" [ref=e304]
                    - columnheader "Metadata (custom renderer needed)" [ref=e308]
                - rowgroup [ref=e312]:
                  - row [ref=e313]:
                    - gridcell "FC-AE-2" [ref=e314]
                    - gridcell "2" [ref=e315]
                    - gridcell "1/15/2026" [ref=e316]
                    - gridcell [ref=e317]:
                      - generic "Metadata with unsupported type System.Collections.Generic.Dictionary requires a custom renderer" [ref=e318]:
                        - strong [ref=e319]: Metadata
                        - text: (System.Collections.Generic.Dictionary) This field requires a custom renderer.
                        - link "Learn how to customize this field" [ref=e320]:
                          - /url: https://hexalith.github.io/FrontComposer/diagnostics/HFC1002
              - region "Details for FC-AE-1"
          - region [ref=e321]:
            - heading "Command form and lifecycle states" [level=2] [ref=e322]
            - form "Specimen command form" [ref=e323]:
              - generic [ref=e324]:
                - text: Counter name
                - textbox "Counter name" [ref=e325]: Specimen counter
              - generic [ref=e326]:
                - text: Amount
                - spinbutton "Amount" [ref=e327]: "3"
              - button "Submit command" [ref=e328]
              - button "Cancel" [ref=e329]
            - list "Five command lifecycle states" [ref=e330]:
              - listitem [ref=e331]:
                - strong [ref=e332]: Idle
                - text: Ready to submit.
              - listitem [ref=e333]:
                - strong [ref=e334]: Submitting
                - text: Submitting command.
              - listitem [ref=e335]:
                - strong [ref=e336]: Acknowledged
                - text: Command accepted by the host.
              - listitem [ref=e337]:
                - strong [ref=e338]: Syncing
                - text: Waiting for projection synchronization.
              - listitem [ref=e339]:
                - strong [ref=e340]: Confirmed or rejected
                - text: Terminal confirmation and rejection states remain text-visible.
          - region [ref=e341]:
            - heading "Destructive command confirmation" [level=2] [ref=e342]
            - group [ref=e344]:
              - generic "Purge Specimen Record command form" [ref=e345]:
                - generic [ref=e346]:
                  - generic [ref=e347]:
                    - group "Purge details" [ref=e348]:
                      - generic [ref=e351]:
                        - generic: Record Id
                        - generic "Record Id" [ref=e353]:
                          - textbox "Record Id, Required" [ref=e355]: FC-1002
                        - generic: Record to purge.
                      - generic [ref=e358]:
                        - generic: Reason
                        - generic "Reason" [ref=e360]:
                          - textbox "Reason, Required" [ref=e362]: QA destructive confirmation coverage
                        - generic: Why this purge is required.
                    - generic [ref=e365]:
                      - generic: Retention
                      - generic "Retention" [ref=e367] [cursor=pointer]:
                        - combobox "Retention" [ref=e369]
                      - generic: How long the purged record stays recoverable.
                    - button "Purge Specimen Record" [ref=e374] [cursor=pointer]
                  - status [ref=e376]
          - region [ref=e377]:
            - heading "Policy-gated command authorization" [level=2] [ref=e378]
            - group [ref=e380]:
              - generic "Policy Allowed Specimen command form" [ref=e381]:
                - generic [ref=e382]:
                  - generic [ref=e383]:
                    - generic [ref=e385]:
                      - generic: Record Id
                      - generic "Record Id" [ref=e387]:
                        - textbox "Record Id, Required" [ref=e389]: FC-AUTH-ALLOW
                    - generic [ref=e391]:
                      - generic: Reason
                      - generic "Reason" [ref=e393]:
                        - textbox "Reason, Required" [ref=e395]: QA policy allowed coverage
                    - button "Policy Allowed Specimen" [ref=e396] [cursor=pointer]
                  - status [ref=e398]
            - group [ref=e399]:
              - group [ref=e400]:
                - heading "Permission required" [level=2] [ref=e401]
                - paragraph [ref=e402]: You do not have permission to Policy Denied Specimen.
          - region [ref=e403]:
            - heading "Expanded detail view" [level=2] [ref=e404]
            - group [ref=e405]:
              - generic "Open projection details for FC-1002" [ref=e406]
              - generic [ref=e407]:
                - term [ref=e408]: Correlation
                - definition [ref=e409]: fc-correlation-0002
                - term [ref=e410]: Last synchronized
                - definition [ref=e411]: 2026-01-15 13:45 UTC
          - navigation "Specimen multi-level navigation" [ref=e412]:
            - heading "Multi-level navigation" [level=2] [ref=e413]
            - list [ref=e414]:
              - listitem [ref=e415]:
                - link "Foundation" [ref=e416]:
                  - /url: "#fc-type-ramp-title"
              - listitem [ref=e417]:
                - button "Generated surfaces" [expanded] [ref=e418]
                - list [ref=e419]:
                  - listitem [ref=e420]:
                    - link "Projection grid" [ref=e421]:
                      - /url: "#fc-badge-grid-title"
                  - listitem [ref=e422]:
                    - link "Command lifecycle" [ref=e423]:
                      - /url: "#fc-specimen-command-title"
    - generic [ref=e424]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  544 |     const cue = page.getByTestId('fc-ae-fresh-presentation');
  545 |     await expect(cue).toContainText(/new|updated/i);
  546 |     await evidence(page, cue, `fresh-presentation-${theme}`, info);
  547 |     await expectSurfaceContrast(cue, 'border');
  548 |   });
  549 | }
  550 | 
  551 | test('paint measurement follows slots, ignores unpainted pseudo borders and sees native modal text through inert ancestors', async ({ page }) => {
  552 |   await page.setContent('<style>#edge{border:1px solid #eee;background:white}#edge::after{content:"";border-bottom:2px solid black;transform:scaleX(0);display:block}</style><div id="host" style="color:black;background:black">Slotted readable label</div><div id="edge">Boundary</div><div inert><dialog id="modal"><p>Visible modal text</p></dialog></div>');
  553 |   await page.locator('#host').evaluate(element => { element.attachShadow({ mode: 'open' }).innerHTML = '<style>slot{color:white}</style><slot></slot>'; });
  554 |   expect((await expectSurfaceContrast(page.locator('#host')))[0].ratio).toBe(21);
  555 |   expect((await expectSurfaceContrast(page.locator('#host').locator('slot')))[0].ratio).toBe(21);
  556 |   await expect(expectSurfaceContrast(page.locator('#edge'), 'border')).rejects.toThrow(/contrast failures/);
  557 |   await page.addStyleTag({ content: '#edge::after{transform:scaleX(1)}' });
  558 |   expect((await expectSurfaceContrast(page.locator('#edge'), 'border')).some(sample => sample.ratio >= 3)).toBe(true);
  559 |   await page.locator('#modal').evaluate(element => (element as HTMLDialogElement).showModal());
  560 |   await expectSurfaceContrast(page.locator('#modal'));
  561 | });
  562 | 
  563 | 
  564 | test('validation links keep native same-page href activation when focus enhancement is unavailable', async ({ page }, info) => {
  565 |   await page.route('**/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js', async route => {
  566 |     const response = await route.fetch();
  567 |     const body = (await response.text())
  568 |       .replace('export function focusValidationOutcome(', 'export function unavailableFocusValidationOutcome(')
  569 |       .replace('export function focusValidationTarget(', 'export function unavailableFocusValidationTarget(')
  570 |       + "\nexport function focusValidationOutcome(){throw new Error('Fixed focus-enhancement fixture unavailable');}\nexport function focusValidationTarget(){throw new Error('Fixed focus-enhancement fixture unavailable');}\n";
  571 |     await route.fulfill({ response, body });
  572 |   });
  573 |   await ready(page, '/__frontcomposer/specimens/type', 'light');
  574 |   await page.getByTestId('fc-destructive-command-specimen').getByRole('button', { name: 'Purge Specimen Record', exact: true }).click();
  575 |   const link = page.getByTestId('fc-validation-summary').getByRole('link', { name: 'The Retention field is required.', exact: true });
  576 |   await expect(link).toHaveCount(1);
  577 |   const href = await link.getAttribute('href');
  578 |   expect(href).toMatch(/__frontcomposer\/specimens\/type#.+-Retention$/u);
  579 |   await link.focus();
  580 |   await page.keyboard.press('Shift+Tab');
  581 |   await page.keyboard.press('Tab');
  582 |   await expect(link).toBeFocused();
  583 |   await page.keyboard.press('Enter');
  584 |   await expect(page).toHaveURL(new URL(href!, await page.locator('base').getAttribute('href').then(base => new URL(base!, page.url()).href)).href);
  585 |   await info.attach('native-validation-link-fallback', { body: JSON.stringify({ role: 'link', href, activation: 'keyboard Enter', duplicateKeyboardStops: false }), contentType: 'application/json' });
  586 | });
  587 | 
  588 | test('G09 forced-color focus geometry rejects a mode-specific clipped ring', async ({ page }) => {
  589 |   await page.setContent('<style>button{position:fixed;left:2px;top:40px;width:80px;height:40px;appearance:none;outline:none}button:focus{outline:2px solid black}@media(forced-colors:active){button:focus{outline-width:6px}}</style><button>Save</button>');
  590 |   await page.locator('button').focus();
  591 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  592 |   await page.emulateMedia({ forcedColors: 'active' });
  593 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('viewport clips target or focus ring');
  594 | });
  595 | 
  596 | for (const theme of ['light', 'dark']) for (const scope of ['tenant', 'user']) {
  597 |   test(`held generated recovery cancels after ${scope} scope change in ${theme}`, async ({ page }) => {
  598 |     await page.route('**/fc-focus.js', async route => {
  599 |       const response = await route.fetch();
  600 |       const source = (await response.text()).replace('export function focusReplacementHeading(key, headingId)', 'function originalFocusReplacementHeading(key, headingId)');
  601 |       await route.fulfill({ response, body: source + `
  602 | export async function focusReplacementHeading(key, headingId) {
  603 |   const gate = window.__aeRecoveryGate;
  604 |   if (gate?.hold) {
  605 |     gate.entered = true;
  606 |     gate.capturedDetached = focusBeforeReplacement.get(key) instanceof HTMLElement && !focusBeforeReplacement.get(key).isConnected;
  607 |     await new Promise(resolve => { gate.release = () => { gate.released = true; resolve(); }; });
  608 |   }
  609 |   if (gate?.hold) gate.captureStillOwned = focusBeforeReplacement.has(key);
  610 |   const result = originalFocusReplacementHeading(key, headingId);
  611 |   if (gate?.hold) gate.returned = result;
  612 |   return result;
  613 | }` });
  614 |     });
  615 |     await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  616 |     const grid = page.getByTestId('fc-generated-counter-grid');
  617 |     await grid.scrollIntoViewIfNeeded();
  618 |     await expect(grid.locator('[data-fc-datagrid]')).toBeVisible();
  619 |     await expect(grid.locator('tbody tr.fluent-data-grid-row').first()).toBeVisible();
  620 |     await page.getByTestId('fc-ae-rows-two').click();
  621 |     // The control above the grid may scroll its virtualized rows out of view.
  622 |     // Establish the completed two-row render before entering the focus recovery sequence.
  623 |     await grid.scrollIntoViewIfNeeded();
  624 |     await expect(grid.locator('tbody tr.fluent-data-grid-row')).toHaveCount(2);
  625 |     await expect(grid.getByRole('gridcell', { name: 'FC-AE-2', exact: true })).toBeVisible();
  626 |     await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  627 |     const detail = grid.locator('.fc-expand-in-row-detail');
  628 |     await expect(detail).toContainText('FC-AE-1');
  629 |     await detail.locator('a,button,fluent-button,[tabindex="0"]').first().focus();
  630 |     const arm = async () => page.evaluate(() => { (window as typeof window & { __aeRecoveryGate: unknown }).__aeRecoveryGate = { hold: true, entered: false, released: false }; });
  631 |     const entered = async () => {
  632 |       await expect.poll(() => page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { entered: boolean; capturedDetached?: boolean } }).__aeRecoveryGate)).toMatchObject({ entered: true, capturedDetached: true });
  633 |       await expect(detail.locator('a,button,fluent-button,[tabindex="0"]')).toHaveCount(0);
  634 |       await expect(grid.locator('.fc-expanded-row-hidden-banner-text')).toBeVisible();
  635 |     };
  636 |     const release = async () => {
  637 |       await page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { release: () => void } }).__aeRecoveryGate.release());
  638 |       await expect.poll(() => page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { returned?: boolean; captureStillOwned?: boolean } }).__aeRecoveryGate)).toMatchObject({ returned: false, captureStillOwned: false });
  639 |     };
  640 |     await arm();
  641 |     await page.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  642 |     await entered();
  643 |     await page.getByTestId(`fc-ae-scope-${scope}`).dispatchEvent('click');
> 644 |     await expect(page.locator('.fc-expanded-row-hidden-banner-text')).toHaveCount(0);
      |                                                                       ^ Error: expect(locator).toHaveCount(expected) failed
  645 |     const current = page.getByTestId('fc-ae-rows-two');
  646 |     await expect(current).toBeVisible();
  647 |     await current.focus();
  648 |     await release();
  649 |     await expect(current).toBeFocused();
  650 |     await expect(page.locator('.fc-expanded-row-hidden-banner-text')).toHaveCount(0);
  651 |     await expect(page.getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status')).not.toContainText('not in the current results');
  652 |   });
  653 | }
  654 | 
```