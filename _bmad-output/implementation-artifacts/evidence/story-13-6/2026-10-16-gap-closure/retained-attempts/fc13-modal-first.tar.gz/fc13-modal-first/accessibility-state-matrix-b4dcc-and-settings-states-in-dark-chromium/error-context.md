# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> active toolbar, tabs, palette and settings states in dark
- Location: specs/accessibility-state-matrix.spec.ts:327:3

# Error details

```
Error: text contrast failures

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 21

- Array []
+ Array [
+   Object {
+     "background": Array [
+       255,
+       255,
+       255,
+       1,
+     ],
+     "foreground": Array [
+       255,
+       255,
+       255,
+       1,
+     ],
+     "minimum": 4.5,
+     "node": "p",
+     "owner": 3,
+     "paint": "Activity panel content",
+     "ratio": 1,
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/page-toolbar#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/page-toolbar#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Counter
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Dark"
                - generic [aria-hidden] [ref=e22]: Dark
          - button "Toggle developer overlay (Ctrl+Shift+D)" [ref=e27] [cursor=pointer]
          - button "Open command palette" [ref=e31] [cursor=pointer]
          - button "Open settings" [ref=e35] [cursor=pointer]
          - button "Account menu" [ref=e40] [cursor=pointer]
    - generic [ref=e43]:
      - status [ref=e44]: Density set to Comfortable.
      - main [ref=e45]:
        - status [ref=e46]
        - status [ref=e47]
        - main [ref=e49]:
          - generic [ref=e50]:
            - paragraph [ref=e51]: FrontComposer accessibility specimen
            - heading "Page toolbar specimen" [level=1] [ref=e52]
            - paragraph [ref=e53]: Reusable search, filter, view, action, and tab toolbar rendered with Fluent UI.
          - region [ref=e54]:
            - heading "Toolbar" [level=2] [ref=e55]
            - toolbar "Orders page tools" [ref=e57]:
              - generic "Search orders" [ref=e59]:
                - searchbox "Search orders" [ref=e61]: open
              - button "Order filters" [ref=e62] [cursor=pointer]
              - button "View options" [ref=e65] [cursor=pointer]
              - generic [ref=e70]: Refresh
          - region [ref=e73]:
            - heading "Page tabs" [level=2] [ref=e74]
            - generic "Order sections" [ref=e75]:
              - tablist [ref=e76]:
                - generic:
                  - tab "Summary" [ref=e77] [cursor=pointer]
                  - tab "Activity" [active] [selected] [ref=e79] [cursor=pointer]
                  - tab "Archived" [disabled]
                  - tab "History" [ref=e81] [cursor=pointer]
              - tabpanel "Activity" [ref=e83]:
                - paragraph [ref=e85]: Activity panel content
          - region [ref=e86]:
            - heading "Toolbar state" [level=2] [ref=e87]
            - generic [ref=e88]:
              - generic [ref=e89]: "Current search: open"
              - generic [ref=e90]: "Active tab: activity"
              - generic [ref=e91]: "Refresh count: 0"
    - generic [ref=e92]: Counter © 2026
```

# Test source

```ts
  593 |       // Reject it until a pixel measurement can establish its compositing order.
  594 |       if (sampleKind === 'text' || sampleKind === 'icon') {
  595 |         const root = element.getRootNode();
  596 |         if (root instanceof Document || root instanceof ShadowRoot) for (const candidate of root.querySelectorAll('*')) {
  597 |           if (candidate === element || candidate.contains(element) || element.contains(candidate)) continue;
  598 |           const css = getComputedStyle(candidate), rect = candidate.getBoundingClientRect();
  599 |           if (!['absolute', 'fixed'].includes(css.position) || css.visibility === 'hidden' || Number(css.opacity) === 0 || parse(css.backgroundColor)[3] === 0) continue;
  600 |           if (boxes.some(box => rect.left < box.right && rect.right > box.left && rect.top < box.bottom && rect.bottom > box.top)) throw new Error('Overlapping sibling background needs pixel evidence');
  601 |         }
  602 |       }
  603 |       const color = parse(value); color[3] *= alpha;
  604 |       if (color[3] === 0 && sampleKind !== 'icon') return;
  605 |       const bg = background(outside ? parent(element) : element);
  606 |       const fg = composite(color, bg), a = luminance(fg), b = luminance(bg);
  607 |       const owner = controlOwner(element);
  608 |       if (!owners.has(owner)) owners.set(owner, owners.size);
  609 |       samples.push({ owner: owners.get(owner)!, node: `${element.tagName.toLowerCase()}${element.id ? '#' + element.id : ''}`, paint: label, foreground: fg, background: bg, ratio: (Math.max(a, b) + .05) / (Math.min(a, b) + .05), minimum });
  610 |     };
  611 |     const sampledText = new Set<Node>();
  612 |     const visited = new Set<Element>();
  613 |     const visit = (element: Element) => {
  614 |       if (visited.has(element) || !visible(element)) return;
  615 |       visited.add(element);
  616 |       const css = getComputedStyle(element);
  617 |       if (sampleKind === 'text') {
  618 |         if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
  619 |           const placeholder = getComputedStyle(element, '::placeholder');
  620 |           const glyph = (style: CSSStyleDeclaration) => style.getPropertyValue('-webkit-text-fill-color') || style.color;
  621 |           const paint = element.value.trim() ? glyph(css) : element.getAttribute('placeholder') ? glyph(placeholder) : null;
  622 |           if (paint) sample(element, paint, element.value.trim() ? 'input value' : 'input placeholder', 4.5, false, element.value.trim() ? 1 : Number(placeholder.opacity));
  623 |         }
  624 |         const textNodes = element instanceof HTMLSlotElement ? element.assignedNodes({ flatten: true }) : element.childNodes;
  625 |         for (const node of textNodes) if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim() && !sampledText.has(node)) {
  626 |           sampledText.add(node);
  627 |           const range = document.createRange(); range.selectNodeContents(node);
  628 |           if (![...range.getClientRects()].some(box => box.width > 0 && box.height > 0)) continue;
  629 |           const textOwner = (node as Text).assignedSlot ?? element;
  630 |           const textCss = getComputedStyle(textOwner);
  631 |           const large = parseFloat(textCss.fontSize) >= 24 || parseFloat(textCss.fontSize) >= 18.667 && parseInt(textCss.fontWeight) >= 700;
  632 |           sample(textOwner, textCss.getPropertyValue('-webkit-text-fill-color') || textCss.color, node.textContent.trim().slice(0, 80), large ? 3 : 4.5, false, 1, [...range.getClientRects()]);
  633 |         }
  634 |         for (const pseudo of ['::before', '::after']) {
  635 |           const generated = getComputedStyle(element, pseudo);
  636 |           if (!generated.content || ['none','normal','""',"''"].includes(generated.content) || generated.visibility === 'hidden' || generated.display === 'none' || Number(generated.opacity) === 0) continue;
  637 |           if (!/^("[^"]*"|'[^']*')$/u.test(generated.content)) throw new Error('Generated content needs pixel evidence');
  638 |           if (parse(generated.backgroundColor)[3] > 0 || generated.backgroundImage !== 'none') throw new Error('Generated text background needs pixel evidence');
  639 |           sample(element, generated.getPropertyValue('-webkit-text-fill-color') || generated.color, `${pseudo} generated text`, 4.5, false, Number(generated.opacity));
  640 |         }
  641 |       } else if (sampleKind === 'icon' && element.matches('svg path,svg polygon,svg circle,svg rect,svg ellipse,svg line,svg polyline,svg use,svg text')) {
  642 |         if (element.matches('use')) throw new Error('SVG use instance needs pixel evidence');
  643 |         for (const property of ['fill', 'stroke']) {
  644 |           const paint = css.getPropertyValue(property);
  645 |           if (property === 'stroke' && parseFloat(css.strokeWidth) <= 0 || property === 'fill' && element.matches('line,polyline')) continue;
  646 |           if (paint !== 'none') { const opacity = css.getPropertyValue(`${property}-opacity`); sample(element, paint, `icon ${property}`, 3, false, parseFloat(opacity) / (opacity.endsWith('%') ? 100 : 1)); }
  647 |         }
  648 |       } else if (sampleKind === 'border') {
  649 |         for (const pseudo of [null, '::before', '::after']) {
  650 |           const edge = getComputedStyle(element, pseudo);
  651 |           if (pseudo && (edge.content === 'none' || edge.visibility === 'hidden' || Number(edge.opacity) === 0)) continue;
  652 |           if (edge.transform !== 'none') { const matrix = new DOMMatrixReadOnly(edge.transform); if (matrix.a === 0 || matrix.d === 0) continue; }
  653 |           for (const side of ['top', 'right', 'bottom', 'left']) if (parseFloat(edge.getPropertyValue(`border-${side}-width`)) > 0 && !['none', 'hidden'].includes(edge.getPropertyValue(`border-${side}-style`))) sample(element, edge.getPropertyValue(`border-${side}-color`), `${pseudo ?? 'element'} border-${side}`, 3, !pseudo, Number(edge.opacity));
  654 |         }
  655 |       } else if (sampleKind === 'focus' || sampleKind === 'cue') {
  656 |         for (const pseudo of [null, '::before', '::after']) {
  657 |           const paint = getComputedStyle(element, pseudo);
  658 |           if (paint.visibility === 'hidden' || paint.display === 'none' || Number(paint.opacity) === 0 || pseudo && paint.content === 'none') continue;
  659 |           if (paint.transform !== 'none') { const matrix = new DOMMatrixReadOnly(paint.transform); if (matrix.a === 0 || matrix.d === 0) continue; }
  660 |           const qualifies = (keys: string[]) => sampleKind === 'cue' || audit.changed(element, pseudo, paint, resting, keys);
  661 |           if (qualifies(['outline-width','outline-style','outline-color','outline-offset']) && parseFloat(paint.outlineWidth) > 0 && paint.outlineStyle !== 'none') {
  662 |             const offset = parseFloat(paint.outlineOffset);
  663 |             if (offset < 0 && offset + parseFloat(paint.outlineWidth) > 0) throw new Error('Straddling outline adjacency needs pixel evidence');
  664 |             sample(element, paint.outlineColor, `${pseudo ?? 'element'} outline`, 3, offset >= 0, Number(paint.opacity));
  665 |           }
  666 |           if (qualifies(['box-shadow'])) for (const shadow of audit.shadows(element, pseudo, paint, resting)) {
  667 |             if (/\binset\b/u.test(shadow)) continue;
  668 |             const lengths = shadow.replace(/[a-z][a-z0-9-]*\([^()]*\)/giu, '').match(/-?[\d.]+px/gu)?.map(Number.parseFloat) ?? [];
  669 |             const bounds = element.getBoundingClientRect(), spread = lengths[3] ?? 0;
  670 |             if (bounds.width + 2 * spread <= 0 || bounds.height + 2 * spread <= 0 || lengths.length < 2 || (lengths[2] ?? 0) > 0 || lengths[0] === 0 && lengths[1] === 0 && (lengths[3] ?? 0) <= 0) continue;
  671 |             for (const color of shadow.match(/[a-z][a-z0-9-]*\([^()]*\)/giu) ?? []) sample(element, color, `${pseudo ?? 'element'} box-shadow`, 3, true, Number(paint.opacity));
  672 |           }
  673 |           if (pseudo && qualifies(['border-top-width','border-right-width','border-bottom-width','border-left-width','border-top-color','border-right-color','border-bottom-color','border-left-color'])) for (const side of ['top', 'right', 'bottom', 'left']) if (parseFloat(paint.getPropertyValue(`border-${side}-width`)) > 0 && !['none', 'hidden'].includes(paint.getPropertyValue(`border-${side}-style`))) sample(element, paint.getPropertyValue(`border-${side}-color`), `${pseudo} border-${side}`, 3, false, Number(paint.opacity));
  674 |         }
  675 |       }
  676 |       if (element instanceof HTMLSlotElement) for (const child of element.assignedElements({ flatten: true })) visit(child);
  677 |       if (element.shadowRoot) for (const child of element.shadowRoot.children) visit(child);
  678 |       for (const child of element.children) if (!child.matches('style,script,template')) visit(child);
  679 |     };
  680 |     visit(scope);
  681 |     return samples;
  682 |   }, kind);
  683 | }
  684 | 
  685 | export async function expectSurfaceContrast(root: Locator, kind: ContrastKind = 'text') {
  686 |   const samples = await measureSurfaceContrast(root, kind);
  687 |   expect(samples.length, `Nonempty ${kind} contrast inventory`).toBeGreaterThan(0);
  688 |   // A Fluent control may paint a contrasting edge plus a two-color separator.
  689 |   // Alternatives belong to that unique control; another control cannot mask a failure.
  690 |   const owners = new Set(samples.map(sample => sample.owner));
  691 |   const passingOwners = new Set([...owners].filter(owner => samples.some(sample => sample.owner === owner && sample.ratio >= sample.minimum)));
  692 |   const failures = samples.filter(sample => sample.ratio < sample.minimum && (!(kind === 'focus' || kind === 'cue' || kind === 'border') || !passingOwners.has(sample.owner)));
> 693 |   expect(failures, `${kind} contrast failures`).toEqual([]);
      |                                                 ^ Error: text contrast failures
  694 |   return samples;
  695 | }
  696 | 
  697 | /** Diagnostic element captures must leave the operator's scroll/focus geometry unchanged. */
  698 | export async function screenshotPreservingScroll(target: Locator, options?: Parameters<Locator['screenshot']>[0]) {
  699 |   const positions = await target.evaluateHandle(() => {
  700 |     const elements = new Set<Element>([document.scrollingElement ?? document.documentElement]);
  701 |     const visit = (root: Document | ShadowRoot) => { for (const element of root.querySelectorAll('*')) {
  702 |       if (element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth || element.scrollTop || element.scrollLeft) elements.add(element);
  703 |       if (element.shadowRoot) visit(element.shadowRoot);
  704 |     } };
  705 |     visit(document);
  706 |     return [...elements].map(element => ({ element, left: element.scrollLeft, top: element.scrollTop }));
  707 |   });
  708 |   try { return await target.screenshot(options); }
  709 |   finally {
  710 |     await positions.evaluate(records => { for (const { element, left, top } of records) if (element.isConnected) element.scrollTo({ left, top, behavior: 'instant' }); });
  711 |     await positions.dispose();
  712 |   }
  713 | }
  714 | 
  715 | /** Wait for finite theme/control paint transitions without changing the active styling. */
  716 | export async function settlePaint(page: Page): Promise<void> {
  717 |   await page.evaluate(async () => {
  718 |     for (let pass = 0; pass < 5; pass++) {
  719 |       await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  720 |       const roots: (Document | ShadowRoot)[] = [document];
  721 |       const collect = (root: Document | ShadowRoot) => { for (const element of root.querySelectorAll('*')) if (element.shadowRoot) { roots.push(element.shadowRoot); collect(element.shadowRoot); } };
  722 |       collect(document);
  723 |       const animations = roots.flatMap(root => root.getAnimations()).filter(animation => animation.playState === 'running' && Number.isFinite(Number(animation.effect?.getComputedTiming().endTime)));
  724 |       if (!animations.length) return;
  725 |       await Promise.allSettled(animations.map(animation => animation.finished));
  726 |     }
  727 |   });
  728 | }
  729 | 
```