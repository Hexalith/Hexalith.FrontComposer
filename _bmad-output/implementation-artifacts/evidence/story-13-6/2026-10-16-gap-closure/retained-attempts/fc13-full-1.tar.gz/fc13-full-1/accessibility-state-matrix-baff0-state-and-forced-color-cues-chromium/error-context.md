# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> AE complete state matrix dark >> generated-forms: composed text, targets, current-state and forced-color cues
- Location: specs/accessibility-state-matrix.spec.ts:235:7

# Error details

```
Error: locator.evaluate: Error: Generated content needs pixel evidence
    at visit (eval at evaluate (:311:30), <anonymous>:177:70)
    at visit (eval at evaluate (:311:30), <anonymous>:232:11)
    at visit (eval at evaluate (:311:30), <anonymous>:233:80)
    at visit (eval at evaluate (:311:30), <anonymous>:234:90)
    at visit (eval at evaluate (:311:30), <anonymous>:234:90)
    at visit (eval at evaluate (:311:30), <anonymous>:234:90)
    at visit (eval at evaluate (:311:30), <anonymous>:234:90)
    at visit (eval at evaluate (:311:30), <anonymous>:234:90)
    at visit (eval at evaluate (:311:30), <anonymous>:234:90)
    at visit (eval at evaluate (:311:30), <anonymous>:232:11)
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /counter#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /counter#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [active] [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Dark"
                - generic [aria-hidden] [ref=e22]: Dark
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]: Density set to Comfortable.
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - generic [ref=e42]:
          - heading "Counter" [level=1] [ref=e43]
          - generic "Counter pages" [ref=e44]:
            - tablist [ref=e45]:
              - generic:
                - tab "Overview" [selected] [ref=e46] [cursor=pointer]
                - tab "Projection" [ref=e48] [cursor=pointer]
            - tabpanel "Overview" [ref=e50]:
              - generic [ref=e52]:
                - generic:
                  - generic [ref=e53]:
                    - heading [level=2] [ref=e54]:
                      - button "Create with an exact target" [expanded] [ref=e55] [cursor=pointer]
                    - region "Create with an exact target" [ref=e58]:
                      - group [ref=e60]:
                        - generic "Create Counter command form" [ref=e61]:
                          - generic [ref=e62]:
                            - generic [ref=e63]:
                              - generic [ref=e65]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e67]:
                                  - textbox "Counter key, Required" [ref=e69]
                              - generic [ref=e71]:
                                - generic: Initial Value
                                - generic "Initial Value" [ref=e73]:
                                  - textbox "Initial Value, Required" [ref=e75]: "0"
                              - button "Create Counter" [ref=e76] [cursor=pointer]
                            - status [ref=e78]
                  - generic [ref=e79]:
                    - heading [level=2] [ref=e80]:
                      - button "Update with an exact target" [expanded] [ref=e81] [cursor=pointer]
                    - region "Update with an exact target" [ref=e84]:
                      - group [ref=e86]:
                        - generic "Update Counter command form" [ref=e87]:
                          - generic [ref=e88]:
                            - generic [ref=e89]:
                              - generic [ref=e91]:
                                - generic: Counter key
                                - generic "Counter key" [ref=e93]:
                                  - textbox "Counter key, Required" [ref=e95]
                              - generic [ref=e97]:
                                - generic: Amount
                                - generic "Amount" [ref=e99]:
                                  - textbox "Amount, Required" [ref=e101]: "1"
                              - button "Update Counter" [ref=e102] [cursor=pointer]
                            - status [ref=e104]
                  - generic [ref=e105]:
                    - heading [level=2] [ref=e106]:
                      - button "Compact inline (3 fields)" [expanded] [ref=e107] [cursor=pointer]
                    - region "Compact inline (3 fields)" [ref=e110]:
                      - group [ref=e112]:
                        - generic "Batch Increment command form" [ref=e113]:
                          - generic [ref=e114]:
                            - generic [ref=e115]:
                              - generic [ref=e117]:
                                - generic: Amount
                                - generic "Amount" [ref=e119]:
                                  - textbox "Amount, Required" [ref=e121]: "1"
                              - generic [ref=e123]:
                                - generic: Note
                                - generic "Note" [ref=e125]:
                                  - textbox "Note, Required" [ref=e127]
                              - generic [ref=e129]:
                                - generic: Effective Date
                                - generic "Effective Date" [ref=e131]:
                                  - generic [ref=e132]:
                                    - textbox "Effective Date" [ref=e133]:
                                      - /placeholder: M/d/yyyy
                                      - text: 10/16/2026
                                    - button "Show date picker" [ref=e135]
                              - button "Batch Increment" [ref=e137] [cursor=pointer]
                            - status [ref=e139]
                  - generic [ref=e140]:
                    - heading [level=2] [ref=e141]:
                      - button "Inline + popover (1 field)" [expanded] [ref=e142] [cursor=pointer]
                    - region "Inline + popover (1 field)" [ref=e145]:
                      - button "Increment" [ref=e146] [cursor=pointer]
                  - generic [ref=e150]:
                    - heading [level=2] [ref=e151]:
                      - button "Full-page command (5 fields)" [expanded] [ref=e152] [cursor=pointer]
                    - region "Full-page command (5 fields)" [ref=e155]:
                      - generic:
                        - note [ref=e156]: Navigation state persistence (scroll, filter, sort across FullPage round-trip) lands in Story 4.3. The current demo proves routing + breadcrumb return only.
                        - link [ref=e157] [cursor=pointer]:
                          - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                          - generic [ref=e158]:
                            - generic:
                              - link [ref=e159]:
                                - /url: /commands/Counter/ConfigureCounterCommand?returnPath=%2Fcounter&projectionTypeFqn=Counter.Domain.CounterProjection
                              - text: Configure Counter
          - status [ref=e160]
    - generic [ref=e161]: Hexalith FrontComposer © 2026
```