# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> AE complete state matrix dark >> toolbar: composed text, targets, current-state and forced-color cues
- Location: specs/accessibility-state-matrix.spec.ts:235:7

# Error details

```
Error: Forced-color focused geometry: toolbar-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "app content obscures target or focus ring",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/page-toolbar#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/page-toolbar#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [active] [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Dark"
                - generic [aria-hidden] [ref=e22]: Dark
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]: Density set to Comfortable.
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - main [ref=e43]:
          - generic [ref=e44]:
            - paragraph [ref=e45]: FrontComposer accessibility specimen
            - heading "Page toolbar specimen" [level=1] [ref=e46]
            - paragraph [ref=e47]: Reusable search, filter, view, action, and tab toolbar rendered with Fluent UI.
          - region [ref=e48]:
            - heading "Toolbar" [level=2] [ref=e49]
            - toolbar "Orders page tools" [ref=e51]:
              - generic "Search orders" [ref=e53]:
                - searchbox "Search orders" [ref=e55]: open
              - button "Order filters" [ref=e56] [cursor=pointer]
              - button "View options" [ref=e59] [cursor=pointer]
              - generic [ref=e64]: Refresh
          - region [ref=e67]:
            - heading "Page tabs" [level=2] [ref=e68]
            - generic "Order sections" [ref=e69]:
              - tablist [ref=e70]:
                - generic:
                  - tab "Summary" [selected] [ref=e71] [cursor=pointer]
                  - tab "Activity" [ref=e73] [cursor=pointer]
                  - tab "Archived" [disabled]
                  - tab "History" [ref=e75] [cursor=pointer]
              - tabpanel "Summary" [ref=e77]:
                - paragraph [ref=e79]: Summary panel content
          - region [ref=e80]:
            - heading "Toolbar state" [level=2] [ref=e81]
            - generic [ref=e82]:
              - generic [ref=e83]: "Current search: open"
              - generic [ref=e84]: "Active tab: summary"
              - generic [ref=e85]: "Refresh count: 0"
    - generic [ref=e86]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  1   | import { PageToolbarSpecimenPage } from '../page-objects/page-toolbar-specimen.page.js';
  2   | import { fillFieldByLabel } from '../helpers/fluent-fields.js';
  3   | import { writeFile } from 'node:fs/promises';
  4   | import { expect, test } from '../fixtures/index.js';
  5   | import type { Locator, Page, TestInfo } from '@playwright/test';
  6   | import { applyTextSpacing, focusGeometry, expectFocusVisible, expectNoPageOverflow, expectNoTextClipping, expectSurfaceContrast, expectTargetSizes, measureSurfaceContrast, screenshotPreservingScroll, settlePaint } from '../helpers/responsive-accessibility.js';
  7   | import { expectNoBlockingAxeViolations } from '../helpers/a11y.js';
  8   | import { LIFECYCLE_STATES } from '../fixtures/lifecycle.fixture.js';
  9   | 
  10  | const scenarioPath = '/__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact';
  11  | const outcomes = ['validation', 'returned-rejection', 'exception-rejection', 'forbidden', 'unavailable', 'blank-unavailable', 'rate-limited', 'blank-rate-limited', 'transport', 'admission', 'policy'] as const;
  12  | 
  13  | async function ready(page: Page, path: string, theme: string) {
  14  |   await page.goto(path);
  15  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  16  |   await page.getByTitle('Change theme').first().click();
  17  |   await page.getByRole('menuitem', { name: theme === 'dark' ? 'Dark' : 'Light', exact: true }).click();
  18  |   await page.setViewportSize({ width: 320, height: 900 });
  19  |   await page.emulateMedia({ reducedMotion: 'reduce' });
  20  |   await applyTextSpacing(page);
  21  |   await settlePaint(page);
  22  | }
  23  | 
  24  | async function evidence(page: Page, root: Locator, state: string, info: TestInfo, icons?: Locator) {
  25  |   await expect(root).toBeVisible();
  26  |   await expectNoPageOverflow(page);
  27  |   await expectNoTextClipping(page);
  28  |   await settlePaint(page);
  29  |   const theme = state.endsWith('-dark') ? 'Dark' : 'Light';
  30  |   await expect(page.getByTitle('Change theme').first().locator('span[aria-hidden="true"]')).toHaveText(theme);
  31  |   const themePaint = await page.locator('.fc-shell-root').evaluate(element => {
  32  |     const css = getComputedStyle(element), background = css.getPropertyValue('--colorNeutralBackground1').trim();
  33  |     const canvas = document.createElement('canvas'); canvas.width = canvas.height = 1;
  34  |     const context = canvas.getContext('2d')!; context.fillStyle = background; context.fillRect(0, 0, 1, 1);
  35  |     return { background, rgb: [...context.getImageData(0, 0, 1, 1).data].slice(0, 3) };
  36  |   });
  37  |   expect(themePaint.rgb.reduce((sum, channel) => sum + channel, 0) < 384, 'Actual Fluent theme paint').toBe(theme === 'Dark');
  38  |   const reducedMotion = await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  39  |   expect(reducedMotion).toBe(true);
  40  |   const collectCues = async () => {
  41  |     const cues = [];
  42  |     if (state.startsWith('generated-validation-')) cues.push(await expectSurfaceContrast(root, 'focus'));
  43  |     if (state.startsWith('fresh-presentation-')) cues.push(await expectSurfaceContrast(root, 'border'));
  44  |     if (state.startsWith('generated-missing-lost-focus-')) cues.push(await expectSurfaceContrast(root, 'focus'));
  45  |     if (state.startsWith('tabs-active-')) cues.push(await expectSurfaceContrast(root.locator('[aria-selected="true"]'), 'focus'));
  46  |     if (state.startsWith('palette-selected-')) cues.push(await expectSurfaceContrast(root.locator('.fc-palette-option-selected'), 'cue'));
  47  |     if (state.startsWith('destructive-dialog-')) cues.push(await expectSurfaceContrast(page.getByTestId('fc-destructive-cancel'), 'focus'));
  48  |     if (state.startsWith('abandonment-')) cues.push(await expectSurfaceContrast(page.getByTestId('fc-form-abandonment-stay'), 'focus'));
  49  |     if (state.startsWith('rail-')) cues.push(await expectSurfaceContrast(page.getByTestId('fc-shell-navigation').getByTestId('fc-navigation-rail').locator('[aria-current="page"]'), 'border'));
  50  |     if (state.startsWith('settings-')) cues.push(await expectSurfaceContrast(root.locator('fluent-radio:focus'), 'focus'));
  51  |     if (state.startsWith('theme-menu-')) cues.push(await expectSurfaceContrast(root.locator('[role="menuitem"]:focus'), 'focus'));
  52  |     return cues;
  53  |   };
  54  |   const cues = await collectCues();
  55  |   const exceptions: import('../helpers/responsive-accessibility.js').TargetException[] = state.startsWith('settings-')
  56  |     ? ['Compact', 'Comfortable', 'Roomy'].map(value => ({ selector: `fluent-radio[name="fc-density-select"][value="${value}"]`, kind: 'Spacing' as const, rationale: 'Fluent density radio keeps its native visual size with a clear 24px spacing circle.', keyboardPath: 'Settings → Density; Tab and arrows', evidence: `ae-state-${state}.json target inventory` }))
  57  |     : state.startsWith('abandonment-') ? [{ selector: 'nav[aria-label="breadcrumb"] > a', kind: 'Spacing', rationale: 'The full-page breadcrumb link is isolated from all neighboring targets; its 24px circle is measured against the complete inventory.', keyboardPath: 'Full-page form → Counter breadcrumb (Shift+Tab)', evidence: `ae-state-${state}.json target inventory` }] : [];
  58  |   const targets = await expectTargetSizes(page, exceptions);
  59  |   const text = await expectSurfaceContrast(root);
  60  |   const paintedIcons = await measureSurfaceContrast(icons ?? root, 'icon');
  61  |   const icon = paintedIcons.length ? await expectSurfaceContrast(icons ?? root, 'icon') : [];
  62  |   const collectBoundaries = async () => {
  63  |     const boundaries = [];
  64  |     for (const control of await root.locator('fluent-text-input:not([disabled]),fluent-number-input:not([disabled]),fluent-dropdown:not([disabled]),fluent-combobox:not([disabled])').all()) {
  65  |       if (await control.isVisible()) boundaries.push(await expectSurfaceContrast(control, 'border'));
  66  |     }
  67  |     return boundaries;
  68  |   };
  69  |   const boundaries = await collectBoundaries();
  70  |   await page.emulateMedia({ forcedColors: 'active', reducedMotion: 'reduce' });
  71  |   await settlePaint(page);
  72  |   const forcedColors = await page.evaluate(() => matchMedia('(forced-colors: active)').matches);
  73  |   const forcedColorsPaint = await page.evaluate(() => {
  74  |     const probe = document.createElement('div');
  75  |     probe.style.cssText = 'position:fixed;left:-10000px;color:rgb(255,0,0);background:rgb(0,255,0);forced-color-adjust:auto';
  76  |     document.body.append(probe);
  77  |     const css = getComputedStyle(probe), changed = css.color !== 'rgb(255, 0, 0)' && css.backgroundColor !== 'rgb(0, 255, 0)';
  78  |     probe.remove(); return changed;
  79  |   });
  80  |   const systemText = forcedColorsPaint ? await expectSurfaceContrast(root) : [];
  81  |   const systemIcon = forcedColorsPaint && icon.length ? await expectSurfaceContrast(icons ?? root, 'icon') : [];
  82  |   const systemBoundaries = forcedColorsPaint ? await collectBoundaries() : [];
  83  |   const systemCues = forcedColorsPaint ? await collectCues() : [];
  84  |   const forcedColorsStatus = forcedColorsPaint ? 'painted system palette' : 'unsupported authored-color replacement; media rules only';
  85  |   if (!forcedColorsPaint) expect(info.project.name, 'Only the probed WebKit engine lacks forced palette emulation').toBe('webkit');
  86  |   await expect(root).toBeVisible();
  87  |   await expectNoPageOverflow(page);
  88  |   await expectNoTextClipping(page);
  89  |   const focused = page.locator(':focus').first();
  90  |   const active = await page.evaluate(() => document.activeElement?.tagName ?? 'BODY');
  91  |   const operatorFocused = !['BODY','HTML'].includes(active) && await focused.count() > 0;
  92  |   const systemFocus = operatorFocused
  93  |     ? { mode: 'forced-colors', status: 'measured', ...await focusGeometry(focused, { requireIndicator: await focused.evaluate(element => element.matches(':focus-visible') || Boolean(element.shadowRoot?.querySelector(':focus-visible'))) }) }
  94  |     : { mode: 'forced-colors', status: 'none', target: active };
> 95  |   if ('failures' in systemFocus) expect(systemFocus.failures, `Forced-color focused geometry: ${state}`).toEqual([]);
      |                                                                                                          ^ Error: Forced-color focused geometry: toolbar-dark
  96  |   const systemSnapshot = forcedColorsPaint ? `system-state-${state}.png` : null;
  97  |   if (systemSnapshot) await screenshotPreservingScroll(root, { path: info.outputPath(systemSnapshot) });
  98  |   await page.emulateMedia({ forcedColors: 'none' });
  99  |   await settlePaint(page);
  100 |   const path = info.outputPath(`ae-state-${state}.json`);
  101 |   await writeFile(path, JSON.stringify({ testId: info.testId, attempt: info.retry, state, engine: info.project.name, runId: process.env.FC_A11Y_EVIDENCE_RUN_ID, viewport: page.viewportSize(), theme, themePaint, targets, text, icon, boundaries, cues, decorativeIconExemptions: ['.fc-empty-state-body__icon: redundant illustration accompanying complete visible empty-state text', '.fluent-skeleton: decorative loading skeleton accompanying aria-busy and its accessible name'], forcedColors, forcedColorsPaint, forcedColorsStatus, systemText, systemIcon, systemBoundaries, systemCues, systemFocus, systemSnapshot, reducedMotion }, null, 2));
  102 |   await info.attach(`state-${state}`, { path, contentType: 'application/json' });
  103 | }
  104 | 
  105 | for (const theme of ['light', 'dark']) {
  106 |   test.describe(`AE complete state matrix ${theme}`, () => {
  107 |     test.beforeEach(async ({ page }) => {
  108 |       await page.addInitScript(() => { localStorage.clear(); sessionStorage.clear(); });
  109 |     });
  110 | 
  111 |     for (const outcome of outcomes) {
  112 |       test(`generated zero-field ${outcome}: safe feedback, focus, owner, next attempt`, async ({ page }, info) => {
  113 |         await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  114 |         const root = page.getByTestId('fc-ae-scenarios');
  115 |         await root.getByTestId(`fc-ae-select-${outcome}`).click();
  116 |         const trigger = root.getByRole('button', { name: 'Run accessibility specimen', exact: true });
  117 |         await trigger.focus();
  118 |         await page.keyboard.press('Shift+Tab');
  119 |         await page.keyboard.press('Tab');
  120 |         await page.keyboard.press('Enter');
  121 |         const feedback = root.getByTestId('fc-zero-field-outcome');
  122 |         await expect(feedback).toBeVisible();
  123 |         await expect(feedback).toHaveAttribute('aria-live', 'off');
  124 |         await expect(trigger).toBeFocused();
  125 |         await expect(feedback).not.toHaveText(/^\s*$/u);
  126 |         await expect(feedback.locator('a,button,fluent-button')).toHaveCount(0);
  127 |         if (outcome.includes('rate-limited')) await expect(feedback).toContainText('Retry after 17 seconds.');
  128 |         const copy = (await feedback.innerText()).trim();
  129 |         await expect(root.getByTestId('fc-surface-status').filter({ hasText: outcome.includes('rejection') ? /rejected/i : copy })).toHaveCount(1);
  130 |         await expect(root.locator('[role="alert"],[aria-live="assertive"]')).toHaveCount(0);
  131 |         await evidence(page, feedback, `zero-${outcome}-${theme}`, info);
  132 |         await expectFocusVisible(trigger);
  133 |         await expectSurfaceContrast(trigger, 'focus');
  134 |         // No automatic pre-accept retry: the independent dispatch counter stays at one (zero for denials).
  135 |         await page.waitForTimeout(350);
  136 |         await root.getByTestId('fc-ae-select-accepted').click();
  137 |         await expect(root.getByTestId('fc-ae-command-probe')).toHaveAttribute('data-dispatch-count', ['admission', 'policy'].includes(outcome) ? '0' : '1');
  138 |         await expect(feedback).toHaveText(copy);
  139 |         await trigger.click();
  140 |         await expect(feedback).toHaveCount(0);
  141 |         await expect(page.locator('.fc-pending-command-summary')).toBeVisible();
  142 |         if (outcome === 'validation') await evidence(page, page.locator('.fc-pending-command-summary'), `zero-accepted-${theme}`, info);
  143 |         await info.attach(`zero-field-${outcome}-${theme}.json`, { body: JSON.stringify({ outcome, theme, copy, preAcceptRetries: 0, observedOwnerCount: 1, heardSpeech: 'not observed' }), contentType: 'application/json' });
  144 |       });
  145 |     }
  146 | 
  147 |     test('real generated detail removal preserves external focus and deduplicates completed results', async ({ page }, info) => {
  148 |       await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  149 |       const grid = page.getByTestId('fc-generated-counter-grid');
  150 |       const controls = page.getByTestId('fc-ae-scenarios');
  151 |       await controls.getByTestId('fc-ae-rows-two').click();
  152 |       await expect(grid.locator('tbody tr.fluent-data-grid-row')).toHaveCount(2);
  153 |       await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  154 |       const detail = grid.locator('.fc-expand-in-row-detail');
  155 |       await expect(detail).toContainText('FC-AE-1');
  156 |       const external = controls.getByTestId('fc-ae-rows-two');
  157 |       await external.focus();
  158 |       await controls.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  159 |       const explanation = grid.locator('.fc-expanded-row-hidden-banner-text');
  160 |       await expect(explanation).toContainText('not in the current results');
  161 |       await expect(external).toBeFocused();
  162 |       await expect(grid.getByTestId('fc-expanded-row-hidden-banner-clear')).toHaveCount(0);
  163 |       await expect(grid.getByTestId('fc-surface-status')).toContainText('not in the current results');
  164 |       const revision = await grid.locator('[data-message-revision]').getAttribute('data-message-revision');
  165 |       await controls.getByTestId('fc-ae-rows-repeat').dispatchEvent('click');
  166 |       await expect(grid.locator('[data-message-revision]')).toHaveAttribute('data-message-revision', revision!);
  167 |       await expect(external).toBeFocused();
  168 |       await evidence(page, explanation, `generated-missing-external-${theme}`, info);
  169 |     });
  170 | 
  171 |     test('real generated detail loss focuses its neutral non-live explanation', async ({ page }, info) => {
  172 |       await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  173 |       const grid = page.getByTestId('fc-generated-counter-grid');
  174 |       const controls = page.getByTestId('fc-ae-scenarios');
  175 |       await controls.getByTestId('fc-ae-rows-two').click();
  176 |       await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  177 |       const detail = grid.locator('.fc-expand-in-row-detail');
  178 |       await expect(detail).toContainText('FC-AE-1');
  179 |       const detailControl = detail.locator('a,button,fluent-button,[tabindex="0"]').first();
  180 |       await detailControl.focus();
  181 |       await expect(detailControl).toBeFocused();
  182 |       await controls.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  183 |       const explanation = grid.locator('.fc-expanded-row-hidden-banner-text');
  184 |       await expect(explanation).toBeFocused();
  185 |       await expect(explanation).toContainText('not in the current results');
  186 |       await expect(grid.getByTestId('fc-surface-status')).not.toContainText('not in the current results');
  187 |       await expect(explanation.locator('xpath=..')).toHaveAttribute('aria-live', 'off');
  188 |       await evidence(page, explanation, `generated-missing-lost-focus-${theme}`, info);
  189 |       await expectFocusVisible(explanation);
  190 |     });
  191 | 
  192 |     test('all eleven actual lifecycle wrapper states retain immediate text and system-color cues', async ({ page }, info) => {
  193 |       await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  194 |       const root = page.getByTestId('fc-ae-scenarios');
  195 |       const wrapper = page.getByTestId('fc-lifecycle-ae-state');
```