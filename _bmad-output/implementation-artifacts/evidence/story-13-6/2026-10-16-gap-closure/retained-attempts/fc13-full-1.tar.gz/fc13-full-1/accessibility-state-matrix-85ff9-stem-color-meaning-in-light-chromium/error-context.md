# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> fresh-row presentation retains text boundary and system-color meaning in light
- Location: specs/accessibility-state-matrix.spec.ts:542:3

# Error details

```
Error: Forced-color focused geometry: fresh-presentation-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "app content obscures target or focus ring",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=light#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=light#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [active] [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]: Density set to Comfortable.
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - main [ref=e43]:
          - generic [ref=e44]:
            - paragraph [ref=e45]: FrontComposer accessibility specimen
            - heading "Type, theme, density, lifecycle, and navigation specimen" [level=1] [ref=e46]
            - paragraph [ref=e47]: Generated shell surfaces rendered with deterministic local data.
            - link "Skip to command form" [ref=e48] [cursor=pointer]:
              - /url: "#fc-specimen-command-form"
          - region [ref=e49]:
            - heading "Theme and density controls" [level=2] [ref=e50]
            - generic [ref=e51]:
              - link "light" [ref=e52] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "dark" [ref=e53] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "compact" [ref=e54] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "comfortable" [ref=e55] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=comfortable&generatedGrid=true&accessibilityScenarios=true
              - link "roomy" [ref=e56] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=roomy&generatedGrid=true&accessibilityScenarios=true
          - region [ref=e57]:
            - heading "Type ramp" [level=2] [ref=e58]
            - generic [ref=e59]:
              - article [ref=e60]:
                - paragraph [ref=e61]: Display
                - generic [ref=e62]: FrontComposer Display
              - article [ref=e63]:
                - paragraph [ref=e64]: Title
                - generic [ref=e65]: Generated command title
              - article [ref=e66]:
                - paragraph [ref=e67]: Subtitle
                - generic [ref=e68]: Projection subtitle and context
              - article [ref=e69]:
                - paragraph [ref=e70]: Body
                - generic [ref=e71]: Readable generated body text
              - article [ref=e72]:
                - paragraph [ref=e73]: Caption
                - generic [ref=e74]: Supplemental metadata caption
              - article [ref=e75]:
                - paragraph [ref=e76]: Code
                - generic [ref=e77]: FC-STATIC-0001
          - region [ref=e78]:
            - heading "Semantic color tokens" [level=2] [ref=e79]
            - generic [ref=e80]:
              - article [ref=e81]:
                - heading "light theme" [level=3] [ref=e82]
                - generic [ref=e83]:
                  - generic [ref=e85]: Neutral
                  - strong [ref=e86]: Available
                - generic [ref=e87]:
                  - generic [ref=e89]: Informational
                  - strong [ref=e90]: Queued
                - generic [ref=e91]:
                  - generic [ref=e93]: Success
                  - strong [ref=e94]: Confirmed
                - generic [ref=e95]:
                  - generic [ref=e97]: Warning
                  - strong [ref=e98]: Needs review
                - generic [ref=e99]:
                  - generic [ref=e101]: Danger
                  - strong [ref=e102]: Rejected
                - generic [ref=e103]:
                  - generic [ref=e105]: Accent
                  - strong [ref=e106]: Selected
              - article [ref=e107]:
                - heading "dark theme" [level=3] [ref=e108]
                - generic [ref=e109]:
                  - generic [ref=e111]: Neutral
                  - strong [ref=e112]: Available
                - generic [ref=e113]:
                  - generic [ref=e115]: Informational
                  - strong [ref=e116]: Queued
                - generic [ref=e117]:
                  - generic [ref=e119]: Success
                  - strong [ref=e120]: Confirmed
                - generic [ref=e121]:
                  - generic [ref=e123]: Warning
                  - strong [ref=e124]: Needs review
                - generic [ref=e125]:
                  - generic [ref=e127]: Danger
                  - strong [ref=e128]: Rejected
                - generic [ref=e129]:
                  - generic [ref=e131]: Accent
                  - strong [ref=e132]: Selected
          - region [ref=e133]:
            - heading "Density states" [level=2] [ref=e134]
            - generic [ref=e135]:
              - article [ref=e136]:
                - heading "compact density" [level=3] [ref=e137]
                - button "Primary action" [ref=e138]
                - generic [ref=e139]:
                  - text: Label
                  - textbox "compact density text input" [ref=e140]: compact sample
              - article [ref=e141]:
                - heading "comfortable density" [level=3] [ref=e142]
                - button "Primary action" [ref=e143]
                - generic [ref=e144]:
                  - text: Label
                  - textbox "comfortable density text input" [ref=e145]: comfortable sample
              - article [ref=e146]:
                - heading "roomy density" [level=3] [ref=e147]
                - button "Primary action" [ref=e148]
                - generic [ref=e149]:
                  - text: Label
                  - textbox "roomy density text input" [ref=e150]: roomy sample
          - region [ref=e151]:
            - heading "Generated projection DataGrid and badge states" [level=2] [ref=e152]
            - status [ref=e153]
            - paragraph [ref=e154]: 6 specimen status
            - group "Status filter chips" [ref=e155]:
              - button "Neutral, currently inactive" [ref=e156] [cursor=pointer]:
                - generic [ref=e157]: Neutral
              - button "Info, currently inactive" [ref=e158] [cursor=pointer]:
                - generic [ref=e159]: Info
              - button "Success, currently inactive" [ref=e160] [cursor=pointer]:
                - generic [ref=e161]: Success
              - button "Warning, currently inactive" [ref=e162] [cursor=pointer]:
                - generic [ref=e163]: Warning
              - button "Danger, currently inactive" [ref=e164] [cursor=pointer]:
                - generic [ref=e165]: Danger
              - button "Accent, currently inactive" [ref=e166] [cursor=pointer]:
                - generic [ref=e167]: Accent
            - text: 6 specimen status
            - region "specimen status" [ref=e168]:
              - table [ref=e169]:
                - rowgroup [ref=e170]:
                  - row [ref=e171]:
                    - columnheader "Id" [ref=e172]
                    - columnheader "Name" [ref=e176]
                    - columnheader "Status" [ref=e180]
                    - columnheader "Owner" [ref=e184]
                - rowgroup [ref=e188]:
                  - row [ref=e189]:
                    - gridcell "FC-1000" [ref=e190]
                    - gridcell "Neutral projection" [ref=e191]
                    - gridcell [ref=e192]:
                      - 'img "Status: Neutral" [ref=e193]'
                    - gridcell "Shell" [ref=e196]
                  - row [ref=e197]:
                    - gridcell "FC-1001" [ref=e198]
                    - gridcell "Info projection" [ref=e199]
                    - gridcell [ref=e200]:
                      - 'img "Status: Info" [ref=e201]'
                    - gridcell "SourceTools" [ref=e204]
                  - row [ref=e205]:
                    - gridcell "FC-1002" [ref=e206]
                    - gridcell "Success projection" [ref=e207]
                    - gridcell [ref=e208]:
                      - 'img "Status: Success" [ref=e209]'
                    - gridcell "Contracts" [ref=e212]
                  - row [ref=e213]:
                    - gridcell "FC-1003" [ref=e214]
                    - gridcell "Warning projection" [ref=e215]
                    - gridcell [ref=e216]:
                      - 'img "Status: Warning" [ref=e217]'
                    - gridcell "Testing" [ref=e220]
                  - row [ref=e221]:
                    - gridcell "FC-1004" [ref=e222]
                    - gridcell "Danger projection" [ref=e223]
                    - gridcell [ref=e224]:
                      - 'img "Status: Danger" [ref=e225]'
                    - gridcell "CI" [ref=e228]
                  - row [ref=e229]:
                    - gridcell "FC-1005" [ref=e230]
                    - gridcell "Accent projection" [ref=e231]
                    - gridcell [ref=e232]:
                      - 'img "Status: Accent" [ref=e233]'
                    - gridcell "Docs" [ref=e236]
              - region "Details for"
          - region "Automated accessibility scenarios" [ref=e237]:
            - heading "Fixed accessibility scenarios" [level=2] [ref=e238]
            - generic [ref=e239]:
              - generic [ref=e240] [cursor=pointer]: validation
              - generic [ref=e242] [cursor=pointer]: returned-rejection
              - generic [ref=e244] [cursor=pointer]: exception-rejection
              - generic [ref=e246] [cursor=pointer]: forbidden
              - generic [ref=e248] [cursor=pointer]: unavailable
              - generic [ref=e250] [cursor=pointer]: blank-unavailable
              - generic [ref=e252] [cursor=pointer]: rate-limited
              - generic [ref=e254] [cursor=pointer]: blank-rate-limited
              - generic [ref=e256] [cursor=pointer]: transport
              - generic [ref=e258] [cursor=pointer]: admission
              - generic [ref=e260] [cursor=pointer]: policy
              - generic [ref=e262] [cursor=pointer]: accepted
            - paragraph [ref=e264]: validation
            - generic [ref=e265]:
              - button "Run accessibility specimen" [ref=e266] [cursor=pointer]
              - status [ref=e270]
            - status "New item added outside current filters" [ref=e272]: New item. It may not match current filters yet.
            - generic [ref=e273]:
              - generic [ref=e274] [cursor=pointer]: Idle
              - generic [ref=e276] [cursor=pointer]: Submitting
              - generic [ref=e278] [cursor=pointer]: Acknowledged
              - generic [ref=e280] [cursor=pointer]: Syncing
              - generic [ref=e282] [cursor=pointer]: Confirmed
              - generic [ref=e284] [cursor=pointer]: Rejected
              - generic [ref=e286] [cursor=pointer]: IdempotentConfirmed
              - generic [ref=e288] [cursor=pointer]: NeedsReview
              - generic [ref=e290] [cursor=pointer]: Warning
              - generic [ref=e292] [cursor=pointer]: Degraded
              - generic [ref=e294] [cursor=pointer]: DegradedExhausted
            - generic [ref=e296]:
              - generic: Observable lifecycle specimen
              - status [ref=e297]
            - generic [ref=e298]:
              - generic [ref=e299] [cursor=pointer]: Connected
              - generic [ref=e301] [cursor=pointer]: Reconnecting
              - generic [ref=e303] [cursor=pointer]: Disconnected
              - generic [ref=e305] [cursor=pointer]: Start held page
              - generic [ref=e307] [cursor=pointer]: Complete held page
              - generic [ref=e309] [cursor=pointer]: Complete capped page
              - generic [ref=e311] [cursor=pointer]: Apply no-match filter
              - generic [ref=e313] [cursor=pointer]: Reset filter
            - generic [ref=e315]:
              - generic [ref=e316] [cursor=pointer]: Load two rows
              - generic [ref=e318] [cursor=pointer]: Complete missing row result
              - generic [ref=e320] [cursor=pointer]: Complete empty result
              - generic [ref=e322] [cursor=pointer]: Complete failed result
              - generic [ref=e324] [cursor=pointer]: Start pending result
              - generic [ref=e326] [cursor=pointer]: Complete delayed missing result
              - generic [ref=e328] [cursor=pointer]: Change fixed tenant
              - generic [ref=e330] [cursor=pointer]: Change fixed user
              - generic [ref=e332] [cursor=pointer]: Repeat completed result
          - region [ref=e334]:
            - heading "Generated Counter projection grid" [level=2] [ref=e335]
            - status [ref=e336]
            - paragraph [ref=e337]: 1 counters
            - text: 1 counters
            - region "counters" [ref=e338]:
              - table [ref=e339]:
                - rowgroup [ref=e340]:
                  - row [ref=e341]:
                    - columnheader "Id" [ref=e342]
                    - columnheader "Count" [ref=e346]
                    - columnheader "Last changed" [ref=e350]
                    - columnheader "Metadata (custom renderer needed)" [ref=e354]
                - rowgroup [ref=e358]:
                  - row [ref=e359]:
                    - gridcell "fc-correlation-0002" [ref=e360]
                    - gridcell "42" [ref=e361]
                    - gridcell "1/15/2026" [ref=e362]
                    - gridcell [ref=e363]:
                      - generic "Metadata with unsupported type System.Collections.Generic.Dictionary requires a custom renderer" [ref=e364]:
                        - strong [ref=e365]: Metadata
                        - text: (System.Collections.Generic.Dictionary) This field requires a custom renderer.
                        - link "Learn how to customize this field" [ref=e366] [cursor=pointer]:
                          - /url: https://hexalith.github.io/FrontComposer/diagnostics/HFC1002
              - region "Details for"
          - region [ref=e367]:
            - heading "Command form and lifecycle states" [level=2] [ref=e368]
            - form "Specimen command form" [ref=e369]:
              - generic [ref=e370]:
                - text: Counter name
                - textbox "Counter name" [ref=e371]: Specimen counter
              - generic [ref=e372]:
                - text: Amount
                - spinbutton "Amount" [ref=e373]: "3"
              - button "Submit command" [ref=e374]
              - button "Cancel" [ref=e375]
            - list "Five command lifecycle states" [ref=e376]:
              - listitem [ref=e377]:
                - strong [ref=e378]: Idle
                - text: Ready to submit.
              - listitem [ref=e379]:
                - strong [ref=e380]: Submitting
                - text: Submitting command.
              - listitem [ref=e381]:
                - strong [ref=e382]: Acknowledged
                - text: Command accepted by the host.
              - listitem [ref=e383]:
                - strong [ref=e384]: Syncing
                - text: Waiting for projection synchronization.
              - listitem [ref=e385]:
                - strong [ref=e386]: Confirmed or rejected
                - text: Terminal confirmation and rejection states remain text-visible.
          - region [ref=e387]:
            - heading "Destructive command confirmation" [level=2] [ref=e388]
            - group [ref=e390]:
              - generic "Purge Specimen Record command form" [ref=e391]:
                - generic [ref=e392]:
                  - generic [ref=e393]:
                    - group "Purge details" [ref=e394]:
                      - generic [ref=e397]:
                        - generic: Record Id
                        - generic "Record Id" [ref=e399]:
                          - textbox "Record Id, Required" [ref=e401]: FC-1002
                        - generic: Record to purge.
                      - generic [ref=e404]:
                        - generic: Reason
                        - generic "Reason" [ref=e406]:
                          - textbox "Reason, Required" [ref=e408]: QA destructive confirmation coverage
                        - generic: Why this purge is required.
                    - generic [ref=e411]:
                      - generic: Retention
                      - generic "Retention" [ref=e413] [cursor=pointer]:
                        - combobox "Retention" [ref=e415]
                      - generic: How long the purged record stays recoverable.
                    - button "Purge Specimen Record" [ref=e420] [cursor=pointer]
                  - status [ref=e422]
          - region [ref=e423]:
            - heading "Policy-gated command authorization" [level=2] [ref=e424]
            - group [ref=e426]:
              - generic "Policy Allowed Specimen command form" [ref=e427]:
                - generic [ref=e428]:
                  - generic [ref=e429]:
                    - generic [ref=e431]:
                      - generic: Record Id
                      - generic "Record Id" [ref=e433]:
                        - textbox "Record Id, Required" [ref=e435]: FC-AUTH-ALLOW
                    - generic [ref=e437]:
                      - generic: Reason
                      - generic "Reason" [ref=e439]:
                        - textbox "Reason, Required" [ref=e441]: QA policy allowed coverage
                    - button "Policy Allowed Specimen" [ref=e442] [cursor=pointer]
                  - status [ref=e444]
            - group [ref=e445]:
              - group [ref=e446]:
                - heading "Permission required" [level=2] [ref=e447]
                - paragraph [ref=e448]: You do not have permission to Policy Denied Specimen.
          - region [ref=e449]:
            - heading "Expanded detail view" [level=2] [ref=e450]
            - group [ref=e451]:
              - generic "Open projection details for FC-1002" [ref=e452]
              - generic [ref=e453]:
                - term [ref=e454]: Correlation
                - definition [ref=e455]: fc-correlation-0002
                - term [ref=e456]: Last synchronized
                - definition [ref=e457]: 2026-01-15 13:45 UTC
          - navigation "Specimen multi-level navigation" [ref=e458]:
            - heading "Multi-level navigation" [level=2] [ref=e459]
            - list [ref=e460]:
              - listitem [ref=e461]:
                - link "Foundation" [ref=e462] [cursor=pointer]:
                  - /url: "#fc-type-ramp-title"
              - listitem [ref=e463]:
                - button "Generated surfaces" [expanded] [ref=e464]
                - list [ref=e465]:
                  - listitem [ref=e466]:
                    - link "Projection grid" [ref=e467] [cursor=pointer]:
                      - /url: "#fc-badge-grid-title"
                  - listitem [ref=e468]:
                    - link "Command lifecycle" [ref=e469] [cursor=pointer]:
                      - /url: "#fc-specimen-command-title"
    - generic [ref=e470]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  1   | import { PageToolbarSpecimenPage } from '../page-objects/page-toolbar-specimen.page.js';
  2   | import { fillFieldByLabel } from '../helpers/fluent-fields.js';
  3   | import { writeFile } from 'node:fs/promises';
  4   | import { expect, test } from '../fixtures/index.js';
  5   | import type { Locator, Page, TestInfo } from '@playwright/test';
  6   | import { applyTextSpacing, focusGeometry, expectFocusVisible, expectNoPageOverflow, expectNoTextClipping, expectSurfaceContrast, expectTargetSizes, measureSurfaceContrast, screenshotPreservingScroll, settlePaint } from '../helpers/responsive-accessibility.js';
  7   | import { expectNoBlockingAxeViolations } from '../helpers/a11y.js';
  8   | import { LIFECYCLE_STATES } from '../fixtures/lifecycle.fixture.js';
  9   | 
  10  | const scenarioPath = '/__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact';
  11  | const outcomes = ['validation', 'returned-rejection', 'exception-rejection', 'forbidden', 'unavailable', 'blank-unavailable', 'rate-limited', 'blank-rate-limited', 'transport', 'admission', 'policy'] as const;
  12  | 
  13  | async function ready(page: Page, path: string, theme: string) {
  14  |   await page.goto(path);
  15  |   await page.locator('.fc-shell-root[data-fc-interactive="true"]').waitFor();
  16  |   await page.getByTitle('Change theme').first().click();
  17  |   await page.getByRole('menuitem', { name: theme === 'dark' ? 'Dark' : 'Light', exact: true }).click();
  18  |   await page.setViewportSize({ width: 320, height: 900 });
  19  |   await page.emulateMedia({ reducedMotion: 'reduce' });
  20  |   await applyTextSpacing(page);
  21  |   await settlePaint(page);
  22  | }
  23  | 
  24  | async function evidence(page: Page, root: Locator, state: string, info: TestInfo, icons?: Locator) {
  25  |   await expect(root).toBeVisible();
  26  |   await expectNoPageOverflow(page);
  27  |   await expectNoTextClipping(page);
  28  |   await settlePaint(page);
  29  |   const theme = state.endsWith('-dark') ? 'Dark' : 'Light';
  30  |   await expect(page.getByTitle('Change theme').first().locator('span[aria-hidden="true"]')).toHaveText(theme);
  31  |   const themePaint = await page.locator('.fc-shell-root').evaluate(element => {
  32  |     const css = getComputedStyle(element), background = css.getPropertyValue('--colorNeutralBackground1').trim();
  33  |     const canvas = document.createElement('canvas'); canvas.width = canvas.height = 1;
  34  |     const context = canvas.getContext('2d')!; context.fillStyle = background; context.fillRect(0, 0, 1, 1);
  35  |     return { background, rgb: [...context.getImageData(0, 0, 1, 1).data].slice(0, 3) };
  36  |   });
  37  |   expect(themePaint.rgb.reduce((sum, channel) => sum + channel, 0) < 384, 'Actual Fluent theme paint').toBe(theme === 'Dark');
  38  |   const reducedMotion = await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  39  |   expect(reducedMotion).toBe(true);
  40  |   const collectCues = async () => {
  41  |     const cues = [];
  42  |     if (state.startsWith('generated-validation-')) cues.push(await expectSurfaceContrast(root, 'focus'));
  43  |     if (state.startsWith('fresh-presentation-')) cues.push(await expectSurfaceContrast(root, 'border'));
  44  |     if (state.startsWith('generated-missing-lost-focus-')) cues.push(await expectSurfaceContrast(root, 'focus'));
  45  |     if (state.startsWith('tabs-active-')) cues.push(await expectSurfaceContrast(root.locator('[aria-selected="true"]'), 'focus'));
  46  |     if (state.startsWith('palette-selected-')) cues.push(await expectSurfaceContrast(root.locator('.fc-palette-option-selected'), 'cue'));
  47  |     if (state.startsWith('destructive-dialog-')) cues.push(await expectSurfaceContrast(page.getByTestId('fc-destructive-cancel'), 'focus'));
  48  |     if (state.startsWith('abandonment-')) cues.push(await expectSurfaceContrast(page.getByTestId('fc-form-abandonment-stay'), 'focus'));
  49  |     if (state.startsWith('rail-')) cues.push(await expectSurfaceContrast(page.getByTestId('fc-shell-navigation').getByTestId('fc-navigation-rail').locator('[aria-current="page"]'), 'border'));
  50  |     if (state.startsWith('settings-')) cues.push(await expectSurfaceContrast(root.locator('fluent-radio:focus'), 'focus'));
  51  |     if (state.startsWith('theme-menu-')) cues.push(await expectSurfaceContrast(root.locator('[role="menuitem"]:focus'), 'focus'));
  52  |     return cues;
  53  |   };
  54  |   const cues = await collectCues();
  55  |   const exceptions: import('../helpers/responsive-accessibility.js').TargetException[] = state.startsWith('settings-')
  56  |     ? ['Compact', 'Comfortable', 'Roomy'].map(value => ({ selector: `fluent-radio[name="fc-density-select"][value="${value}"]`, kind: 'Spacing' as const, rationale: 'Fluent density radio keeps its native visual size with a clear 24px spacing circle.', keyboardPath: 'Settings → Density; Tab and arrows', evidence: `ae-state-${state}.json target inventory` }))
  57  |     : state.startsWith('abandonment-') ? [{ selector: 'nav[aria-label="breadcrumb"] > a', kind: 'Spacing', rationale: 'The full-page breadcrumb link is isolated from all neighboring targets; its 24px circle is measured against the complete inventory.', keyboardPath: 'Full-page form → Counter breadcrumb (Shift+Tab)', evidence: `ae-state-${state}.json target inventory` }] : [];
  58  |   const targets = await expectTargetSizes(page, exceptions);
  59  |   const text = await expectSurfaceContrast(root);
  60  |   const paintedIcons = await measureSurfaceContrast(icons ?? root, 'icon');
  61  |   const icon = paintedIcons.length ? await expectSurfaceContrast(icons ?? root, 'icon') : [];
  62  |   const collectBoundaries = async () => {
  63  |     const boundaries = [];
  64  |     for (const control of await root.locator('fluent-text-input:not([disabled]),fluent-number-input:not([disabled]),fluent-dropdown:not([disabled]),fluent-combobox:not([disabled])').all()) {
  65  |       if (await control.isVisible()) boundaries.push(await expectSurfaceContrast(control, 'border'));
  66  |     }
  67  |     return boundaries;
  68  |   };
  69  |   const boundaries = await collectBoundaries();
  70  |   await page.emulateMedia({ forcedColors: 'active', reducedMotion: 'reduce' });
  71  |   await settlePaint(page);
  72  |   const forcedColors = await page.evaluate(() => matchMedia('(forced-colors: active)').matches);
  73  |   const forcedColorsPaint = await page.evaluate(() => {
  74  |     const probe = document.createElement('div');
  75  |     probe.style.cssText = 'position:fixed;left:-10000px;color:rgb(255,0,0);background:rgb(0,255,0);forced-color-adjust:auto';
  76  |     document.body.append(probe);
  77  |     const css = getComputedStyle(probe), changed = css.color !== 'rgb(255, 0, 0)' && css.backgroundColor !== 'rgb(0, 255, 0)';
  78  |     probe.remove(); return changed;
  79  |   });
  80  |   const systemText = forcedColorsPaint ? await expectSurfaceContrast(root) : [];
  81  |   const systemIcon = forcedColorsPaint && icon.length ? await expectSurfaceContrast(icons ?? root, 'icon') : [];
  82  |   const systemBoundaries = forcedColorsPaint ? await collectBoundaries() : [];
  83  |   const systemCues = forcedColorsPaint ? await collectCues() : [];
  84  |   const forcedColorsStatus = forcedColorsPaint ? 'painted system palette' : 'unsupported authored-color replacement; media rules only';
  85  |   if (!forcedColorsPaint) expect(info.project.name, 'Only the probed WebKit engine lacks forced palette emulation').toBe('webkit');
  86  |   await expect(root).toBeVisible();
  87  |   await expectNoPageOverflow(page);
  88  |   await expectNoTextClipping(page);
  89  |   const focused = page.locator(':focus').first();
  90  |   const active = await page.evaluate(() => document.activeElement?.tagName ?? 'BODY');
  91  |   const operatorFocused = !['BODY','HTML'].includes(active) && await focused.count() > 0;
  92  |   const systemFocus = operatorFocused
  93  |     ? { mode: 'forced-colors', status: 'measured', ...await focusGeometry(focused, { requireIndicator: await focused.evaluate(element => element.matches(':focus-visible') || Boolean(element.shadowRoot?.querySelector(':focus-visible'))) }) }
  94  |     : { mode: 'forced-colors', status: 'none', target: active };
> 95  |   if ('failures' in systemFocus) expect(systemFocus.failures, `Forced-color focused geometry: ${state}`).toEqual([]);
      |                                                                                                          ^ Error: Forced-color focused geometry: fresh-presentation-light
  96  |   const systemSnapshot = forcedColorsPaint ? `system-state-${state}.png` : null;
  97  |   if (systemSnapshot) await screenshotPreservingScroll(root, { path: info.outputPath(systemSnapshot) });
  98  |   await page.emulateMedia({ forcedColors: 'none' });
  99  |   await settlePaint(page);
  100 |   const path = info.outputPath(`ae-state-${state}.json`);
  101 |   await writeFile(path, JSON.stringify({ testId: info.testId, attempt: info.retry, state, engine: info.project.name, runId: process.env.FC_A11Y_EVIDENCE_RUN_ID, viewport: page.viewportSize(), theme, themePaint, targets, text, icon, boundaries, cues, decorativeIconExemptions: ['.fc-empty-state-body__icon: redundant illustration accompanying complete visible empty-state text', '.fluent-skeleton: decorative loading skeleton accompanying aria-busy and its accessible name'], forcedColors, forcedColorsPaint, forcedColorsStatus, systemText, systemIcon, systemBoundaries, systemCues, systemFocus, systemSnapshot, reducedMotion }, null, 2));
  102 |   await info.attach(`state-${state}`, { path, contentType: 'application/json' });
  103 | }
  104 | 
  105 | for (const theme of ['light', 'dark']) {
  106 |   test.describe(`AE complete state matrix ${theme}`, () => {
  107 |     test.beforeEach(async ({ page }) => {
  108 |       await page.addInitScript(() => { localStorage.clear(); sessionStorage.clear(); });
  109 |     });
  110 | 
  111 |     for (const outcome of outcomes) {
  112 |       test(`generated zero-field ${outcome}: safe feedback, focus, owner, next attempt`, async ({ page }, info) => {
  113 |         await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  114 |         const root = page.getByTestId('fc-ae-scenarios');
  115 |         await root.getByTestId(`fc-ae-select-${outcome}`).click();
  116 |         const trigger = root.getByRole('button', { name: 'Run accessibility specimen', exact: true });
  117 |         await trigger.focus();
  118 |         await page.keyboard.press('Shift+Tab');
  119 |         await page.keyboard.press('Tab');
  120 |         await page.keyboard.press('Enter');
  121 |         const feedback = root.getByTestId('fc-zero-field-outcome');
  122 |         await expect(feedback).toBeVisible();
  123 |         await expect(feedback).toHaveAttribute('aria-live', 'off');
  124 |         await expect(trigger).toBeFocused();
  125 |         await expect(feedback).not.toHaveText(/^\s*$/u);
  126 |         await expect(feedback.locator('a,button,fluent-button')).toHaveCount(0);
  127 |         if (outcome.includes('rate-limited')) await expect(feedback).toContainText('Retry after 17 seconds.');
  128 |         const copy = (await feedback.innerText()).trim();
  129 |         await expect(root.getByTestId('fc-surface-status').filter({ hasText: outcome.includes('rejection') ? /rejected/i : copy })).toHaveCount(1);
  130 |         await expect(root.locator('[role="alert"],[aria-live="assertive"]')).toHaveCount(0);
  131 |         await evidence(page, feedback, `zero-${outcome}-${theme}`, info);
  132 |         await expectFocusVisible(trigger);
  133 |         await expectSurfaceContrast(trigger, 'focus');
  134 |         // No automatic pre-accept retry: the independent dispatch counter stays at one (zero for denials).
  135 |         await page.waitForTimeout(350);
  136 |         await root.getByTestId('fc-ae-select-accepted').click();
  137 |         await expect(root.getByTestId('fc-ae-command-probe')).toHaveAttribute('data-dispatch-count', ['admission', 'policy'].includes(outcome) ? '0' : '1');
  138 |         await expect(feedback).toHaveText(copy);
  139 |         await trigger.click();
  140 |         await expect(feedback).toHaveCount(0);
  141 |         await expect(page.locator('.fc-pending-command-summary')).toBeVisible();
  142 |         if (outcome === 'validation') await evidence(page, page.locator('.fc-pending-command-summary'), `zero-accepted-${theme}`, info);
  143 |         await info.attach(`zero-field-${outcome}-${theme}.json`, { body: JSON.stringify({ outcome, theme, copy, preAcceptRetries: 0, observedOwnerCount: 1, heardSpeech: 'not observed' }), contentType: 'application/json' });
  144 |       });
  145 |     }
  146 | 
  147 |     test('real generated detail removal preserves external focus and deduplicates completed results', async ({ page }, info) => {
  148 |       await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  149 |       const grid = page.getByTestId('fc-generated-counter-grid');
  150 |       const controls = page.getByTestId('fc-ae-scenarios');
  151 |       await controls.getByTestId('fc-ae-rows-two').click();
  152 |       await expect(grid.locator('tbody tr.fluent-data-grid-row')).toHaveCount(2);
  153 |       await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  154 |       const detail = grid.locator('.fc-expand-in-row-detail');
  155 |       await expect(detail).toContainText('FC-AE-1');
  156 |       const external = controls.getByTestId('fc-ae-rows-two');
  157 |       await external.focus();
  158 |       await controls.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  159 |       const explanation = grid.locator('.fc-expanded-row-hidden-banner-text');
  160 |       await expect(explanation).toContainText('not in the current results');
  161 |       await expect(external).toBeFocused();
  162 |       await expect(grid.getByTestId('fc-expanded-row-hidden-banner-clear')).toHaveCount(0);
  163 |       await expect(grid.getByTestId('fc-surface-status')).toContainText('not in the current results');
  164 |       const revision = await grid.locator('[data-message-revision]').getAttribute('data-message-revision');
  165 |       await controls.getByTestId('fc-ae-rows-repeat').dispatchEvent('click');
  166 |       await expect(grid.locator('[data-message-revision]')).toHaveAttribute('data-message-revision', revision!);
  167 |       await expect(external).toBeFocused();
  168 |       await evidence(page, explanation, `generated-missing-external-${theme}`, info);
  169 |     });
  170 | 
  171 |     test('real generated detail loss focuses its neutral non-live explanation', async ({ page }, info) => {
  172 |       await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  173 |       const grid = page.getByTestId('fc-generated-counter-grid');
  174 |       const controls = page.getByTestId('fc-ae-scenarios');
  175 |       await controls.getByTestId('fc-ae-rows-two').click();
  176 |       await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  177 |       const detail = grid.locator('.fc-expand-in-row-detail');
  178 |       await expect(detail).toContainText('FC-AE-1');
  179 |       const detailControl = detail.locator('a,button,fluent-button,[tabindex="0"]').first();
  180 |       await detailControl.focus();
  181 |       await expect(detailControl).toBeFocused();
  182 |       await controls.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  183 |       const explanation = grid.locator('.fc-expanded-row-hidden-banner-text');
  184 |       await expect(explanation).toBeFocused();
  185 |       await expect(explanation).toContainText('not in the current results');
  186 |       await expect(grid.getByTestId('fc-surface-status')).not.toContainText('not in the current results');
  187 |       await expect(explanation.locator('xpath=..')).toHaveAttribute('aria-live', 'off');
  188 |       await evidence(page, explanation, `generated-missing-lost-focus-${theme}`, info);
  189 |       await expectFocusVisible(explanation);
  190 |     });
  191 | 
  192 |     test('all eleven actual lifecycle wrapper states retain immediate text and system-color cues', async ({ page }, info) => {
  193 |       await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  194 |       const root = page.getByTestId('fc-ae-scenarios');
  195 |       const wrapper = page.getByTestId('fc-lifecycle-ae-state');
```