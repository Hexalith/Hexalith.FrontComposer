# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> held generated recovery cancels after user scope change in light
- Location: specs/accessibility-state-matrix.spec.ts:597:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.fc-expanded-row-hidden-banner-text')
Expected: 0
Received: 1
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" locator('.fc-expanded-row-hidden-banner-text') with timeout 10000ms
  - waiting for locator('.fc-expanded-row-hidden-banner-text')
    24 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=light#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?generatedGrid=true&accessibilityScenarios=true&density=compact&theme=light#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]:
            - button "Toggle navigation" [ref=e12] [cursor=pointer]
            - generic:
              - generic:
                - generic: Counter
                - generic: Default
                - generic: Specimens
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - generic [ref=e37]:
      - status [ref=e38]: Density set to Comfortable.
      - main [ref=e39]:
        - status [ref=e40]
        - status [ref=e41]
        - main [ref=e43]:
          - generic [ref=e44]:
            - paragraph [ref=e45]: FrontComposer accessibility specimen
            - heading "Type, theme, density, lifecycle, and navigation specimen" [level=1] [ref=e46]
            - paragraph [ref=e47]: Generated shell surfaces rendered with deterministic local data.
            - link "Skip to command form" [ref=e48] [cursor=pointer]:
              - /url: "#fc-specimen-command-form"
          - region [ref=e49]:
            - heading "Theme and density controls" [level=2] [ref=e50]
            - generic [ref=e51]:
              - link "light" [ref=e52] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "dark" [ref=e53] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "compact" [ref=e54] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact&generatedGrid=true&accessibilityScenarios=true
              - link "comfortable" [ref=e55] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=comfortable&generatedGrid=true&accessibilityScenarios=true
              - link "roomy" [ref=e56] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=roomy&generatedGrid=true&accessibilityScenarios=true
          - region [ref=e57]:
            - heading "Type ramp" [level=2] [ref=e58]
            - generic [ref=e59]:
              - article [ref=e60]:
                - paragraph [ref=e61]: Display
                - generic [ref=e62]: FrontComposer Display
              - article [ref=e63]:
                - paragraph [ref=e64]: Title
                - generic [ref=e65]: Generated command title
              - article [ref=e66]:
                - paragraph [ref=e67]: Subtitle
                - generic [ref=e68]: Projection subtitle and context
              - article [ref=e69]:
                - paragraph [ref=e70]: Body
                - generic [ref=e71]: Readable generated body text
              - article [ref=e72]:
                - paragraph [ref=e73]: Caption
                - generic [ref=e74]: Supplemental metadata caption
              - article [ref=e75]:
                - paragraph [ref=e76]: Code
                - generic [ref=e77]: FC-STATIC-0001
          - region [ref=e78]:
            - heading "Semantic color tokens" [level=2] [ref=e79]
            - generic [ref=e80]:
              - article [ref=e81]:
                - heading "light theme" [level=3] [ref=e82]
                - generic [ref=e83]:
                  - generic [ref=e85]: Neutral
                  - strong [ref=e86]: Available
                - generic [ref=e87]:
                  - generic [ref=e89]: Informational
                  - strong [ref=e90]: Queued
                - generic [ref=e91]:
                  - generic [ref=e93]: Success
                  - strong [ref=e94]: Confirmed
                - generic [ref=e95]:
                  - generic [ref=e97]: Warning
                  - strong [ref=e98]: Needs review
                - generic [ref=e99]:
                  - generic [ref=e101]: Danger
                  - strong [ref=e102]: Rejected
                - generic [ref=e103]:
                  - generic [ref=e105]: Accent
                  - strong [ref=e106]: Selected
              - article [ref=e107]:
                - heading "dark theme" [level=3] [ref=e108]
                - generic [ref=e109]:
                  - generic [ref=e111]: Neutral
                  - strong [ref=e112]: Available
                - generic [ref=e113]:
                  - generic [ref=e115]: Informational
                  - strong [ref=e116]: Queued
                - generic [ref=e117]:
                  - generic [ref=e119]: Success
                  - strong [ref=e120]: Confirmed
                - generic [ref=e121]:
                  - generic [ref=e123]: Warning
                  - strong [ref=e124]: Needs review
                - generic [ref=e125]:
                  - generic [ref=e127]: Danger
                  - strong [ref=e128]: Rejected
                - generic [ref=e129]:
                  - generic [ref=e131]: Accent
                  - strong [ref=e132]: Selected
          - region [ref=e133]:
            - heading "Density states" [level=2] [ref=e134]
            - generic [ref=e135]:
              - article [ref=e136]:
                - heading "compact density" [level=3] [ref=e137]
                - button "Primary action" [ref=e138]
                - generic [ref=e139]:
                  - text: Label
                  - textbox "compact density text input" [ref=e140]: compact sample
              - article [ref=e141]:
                - heading "comfortable density" [level=3] [ref=e142]
                - button "Primary action" [ref=e143]
                - generic [ref=e144]:
                  - text: Label
                  - textbox "comfortable density text input" [ref=e145]: comfortable sample
              - article [ref=e146]:
                - heading "roomy density" [level=3] [ref=e147]
                - button "Primary action" [ref=e148]
                - generic [ref=e149]:
                  - text: Label
                  - textbox "roomy density text input" [ref=e150]: roomy sample
          - region [ref=e151]:
            - heading "Generated projection DataGrid and badge states" [level=2] [ref=e152]
            - status [ref=e153]
            - paragraph [ref=e154]: 6 specimen status
            - group "Status filter chips" [ref=e155]:
              - button "Neutral, currently inactive" [ref=e156] [cursor=pointer]:
                - generic [ref=e157]: Neutral
              - button "Info, currently inactive" [ref=e158] [cursor=pointer]:
                - generic [ref=e159]: Info
              - button "Success, currently inactive" [ref=e160] [cursor=pointer]:
                - generic [ref=e161]: Success
              - button "Warning, currently inactive" [ref=e162] [cursor=pointer]:
                - generic [ref=e163]: Warning
              - button "Danger, currently inactive" [ref=e164] [cursor=pointer]:
                - generic [ref=e165]: Danger
              - button "Accent, currently inactive" [ref=e166] [cursor=pointer]:
                - generic [ref=e167]: Accent
            - text: 6 specimen status
            - region "specimen status" [ref=e168]:
              - table [ref=e169]:
                - rowgroup [ref=e170]:
                  - row [ref=e171]:
                    - columnheader "Id" [ref=e172]
                    - columnheader "Name" [ref=e176]
                    - columnheader "Status" [ref=e180]
                    - columnheader "Owner" [ref=e184]
                - rowgroup [ref=e188]:
                  - row [ref=e189]:
                    - gridcell "FC-1000" [ref=e190]
                    - gridcell "Neutral projection" [ref=e191]
                    - gridcell [ref=e192]:
                      - 'img "Status: Neutral" [ref=e193]'
                    - gridcell "Shell" [ref=e196]
                  - row [ref=e197]:
                    - gridcell "FC-1001" [ref=e198]
                    - gridcell "Info projection" [ref=e199]
                    - gridcell [ref=e200]:
                      - 'img "Status: Info" [ref=e201]'
                    - gridcell "SourceTools" [ref=e204]
                  - row [ref=e205]:
                    - gridcell "FC-1002" [ref=e206]
                    - gridcell "Success projection" [ref=e207]
                    - gridcell [ref=e208]:
                      - 'img "Status: Success" [ref=e209]'
                    - gridcell "Contracts" [ref=e212]
                  - row [ref=e213]:
                    - gridcell "FC-1003" [ref=e214]
                    - gridcell "Warning projection" [ref=e215]
                    - gridcell [ref=e216]:
                      - 'img "Status: Warning" [ref=e217]'
                    - gridcell "Testing" [ref=e220]
                  - row [ref=e221]:
                    - gridcell "FC-1004" [ref=e222]
                    - gridcell "Danger projection" [ref=e223]
                    - gridcell [ref=e224]:
                      - 'img "Status: Danger" [ref=e225]'
                    - gridcell "CI" [ref=e228]
                  - row [ref=e229]:
                    - gridcell "FC-1005" [ref=e230]
                    - gridcell "Accent projection" [ref=e231]
                    - gridcell [ref=e232]:
                      - 'img "Status: Accent" [ref=e233]'
                    - gridcell "Docs" [ref=e236]
              - region "Details for"
          - region "Automated accessibility scenarios" [ref=e237]:
            - heading "Fixed accessibility scenarios" [level=2] [ref=e238]
            - generic [ref=e239]:
              - generic [ref=e240] [cursor=pointer]: validation
              - generic [ref=e242] [cursor=pointer]: returned-rejection
              - generic [ref=e244] [cursor=pointer]: exception-rejection
              - generic [ref=e246] [cursor=pointer]: forbidden
              - generic [ref=e248] [cursor=pointer]: unavailable
              - generic [ref=e250] [cursor=pointer]: blank-unavailable
              - generic [ref=e252] [cursor=pointer]: rate-limited
              - generic [ref=e254] [cursor=pointer]: blank-rate-limited
              - generic [ref=e256] [cursor=pointer]: transport
              - generic [ref=e258] [cursor=pointer]: admission
              - generic [ref=e260] [cursor=pointer]: policy
              - generic [ref=e262] [cursor=pointer]: accepted
            - paragraph [ref=e264]: validation
            - generic [ref=e265]:
              - button "Run accessibility specimen" [ref=e266] [cursor=pointer]
              - status [ref=e270]
            - status "New item added outside current filters" [ref=e272]: New item. It may not match current filters yet.
            - generic [ref=e273]:
              - generic [ref=e274] [cursor=pointer]: Idle
              - generic [ref=e276] [cursor=pointer]: Submitting
              - generic [ref=e278] [cursor=pointer]: Acknowledged
              - generic [ref=e280] [cursor=pointer]: Syncing
              - generic [ref=e282] [cursor=pointer]: Confirmed
              - generic [ref=e284] [cursor=pointer]: Rejected
              - generic [ref=e286] [cursor=pointer]: IdempotentConfirmed
              - generic [ref=e288] [cursor=pointer]: NeedsReview
              - generic [ref=e290] [cursor=pointer]: Warning
              - generic [ref=e292] [cursor=pointer]: Degraded
              - generic [ref=e294] [cursor=pointer]: DegradedExhausted
            - generic [ref=e296]:
              - generic: Observable lifecycle specimen
              - status [ref=e297]
            - generic [ref=e298]:
              - generic [ref=e299] [cursor=pointer]: Connected
              - generic [ref=e301] [cursor=pointer]: Reconnecting
              - generic [ref=e303] [cursor=pointer]: Disconnected
              - generic [ref=e305] [cursor=pointer]: Start held page
              - generic [ref=e307] [cursor=pointer]: Complete held page
              - generic [ref=e309] [cursor=pointer]: Complete capped page
              - generic [ref=e311] [cursor=pointer]: Apply no-match filter
              - generic [ref=e313] [cursor=pointer]: Reset filter
            - generic [ref=e315]:
              - generic [ref=e316] [cursor=pointer]: Load two rows
              - generic [ref=e318] [cursor=pointer]: Complete missing row result
              - generic [ref=e320] [cursor=pointer]: Complete empty result
              - generic [ref=e322] [cursor=pointer]: Complete failed result
              - generic [ref=e324] [cursor=pointer]: Start pending result
              - generic [ref=e326] [cursor=pointer]: Complete delayed missing result
              - generic [ref=e328] [cursor=pointer]: Change fixed tenant
              - generic [ref=e330] [cursor=pointer]: Change fixed user
              - generic [ref=e332] [cursor=pointer]: Repeat completed result
          - region [ref=e334]:
            - heading "Generated Counter projection grid" [level=2] [ref=e335]
            - status [ref=e336]
            - paragraph [ref=e337]: 1 counters
            - text: 1 counters
            - region "counters" [ref=e338]:
              - group [ref=e339]: The expanded item is not in the current results.
              - table [ref=e340]:
                - rowgroup [ref=e341]:
                  - row [ref=e342]:
                    - columnheader "Id" [ref=e343]
                    - columnheader "Count" [ref=e347]
                    - columnheader "Last changed" [ref=e351]
                    - columnheader "Metadata (custom renderer needed)" [ref=e355]
                - rowgroup [ref=e359]:
                  - row [ref=e360]:
                    - gridcell "FC-AE-2" [ref=e361]
                    - gridcell "2" [ref=e362]
                    - gridcell "1/15/2026" [ref=e363]
                    - gridcell [ref=e364]:
                      - generic "Metadata with unsupported type System.Collections.Generic.Dictionary requires a custom renderer" [ref=e365]:
                        - strong [ref=e366]: Metadata
                        - text: (System.Collections.Generic.Dictionary) This field requires a custom renderer.
                        - link "Learn how to customize this field" [ref=e367] [cursor=pointer]:
                          - /url: https://hexalith.github.io/FrontComposer/diagnostics/HFC1002
              - region "Details for FC-AE-1"
          - region [ref=e368]:
            - heading "Command form and lifecycle states" [level=2] [ref=e369]
            - form "Specimen command form" [ref=e370]:
              - generic [ref=e371]:
                - text: Counter name
                - textbox "Counter name" [ref=e372]: Specimen counter
              - generic [ref=e373]:
                - text: Amount
                - spinbutton "Amount" [ref=e374]: "3"
              - button "Submit command" [ref=e375]
              - button "Cancel" [ref=e376]
            - list "Five command lifecycle states" [ref=e377]:
              - listitem [ref=e378]:
                - strong [ref=e379]: Idle
                - text: Ready to submit.
              - listitem [ref=e380]:
                - strong [ref=e381]: Submitting
                - text: Submitting command.
              - listitem [ref=e382]:
                - strong [ref=e383]: Acknowledged
                - text: Command accepted by the host.
              - listitem [ref=e384]:
                - strong [ref=e385]: Syncing
                - text: Waiting for projection synchronization.
              - listitem [ref=e386]:
                - strong [ref=e387]: Confirmed or rejected
                - text: Terminal confirmation and rejection states remain text-visible.
          - region [ref=e388]:
            - heading "Destructive command confirmation" [level=2] [ref=e389]
            - group [ref=e391]:
              - generic "Purge Specimen Record command form" [ref=e392]:
                - generic [ref=e393]:
                  - generic [ref=e394]:
                    - group "Purge details" [ref=e395]:
                      - generic [ref=e398]:
                        - generic: Record Id
                        - generic "Record Id" [ref=e400]:
                          - textbox "Record Id, Required" [ref=e402]: FC-1002
                        - generic: Record to purge.
                      - generic [ref=e405]:
                        - generic: Reason
                        - generic "Reason" [ref=e407]:
                          - textbox "Reason, Required" [ref=e409]: QA destructive confirmation coverage
                        - generic: Why this purge is required.
                    - generic [ref=e412]:
                      - generic: Retention
                      - generic "Retention" [ref=e414] [cursor=pointer]:
                        - combobox "Retention" [ref=e416]
                      - generic: How long the purged record stays recoverable.
                    - button "Purge Specimen Record" [ref=e421] [cursor=pointer]
                  - status [ref=e423]
          - region [ref=e424]:
            - heading "Policy-gated command authorization" [level=2] [ref=e425]
            - group [ref=e427]:
              - generic "Policy Allowed Specimen command form" [ref=e428]:
                - generic [ref=e429]:
                  - generic [ref=e430]:
                    - generic [ref=e432]:
                      - generic: Record Id
                      - generic "Record Id" [ref=e434]:
                        - textbox "Record Id, Required" [ref=e436]: FC-AUTH-ALLOW
                    - generic [ref=e438]:
                      - generic: Reason
                      - generic "Reason" [ref=e440]:
                        - textbox "Reason, Required" [ref=e442]: QA policy allowed coverage
                    - button "Policy Allowed Specimen" [ref=e443] [cursor=pointer]
                  - status [ref=e445]
            - group [ref=e446]:
              - group [ref=e447]:
                - heading "Permission required" [level=2] [ref=e448]
                - paragraph [ref=e449]: You do not have permission to Policy Denied Specimen.
          - region [ref=e450]:
            - heading "Expanded detail view" [level=2] [ref=e451]
            - group [ref=e452]:
              - generic "Open projection details for FC-1002" [ref=e453]
              - generic [ref=e454]:
                - term [ref=e455]: Correlation
                - definition [ref=e456]: fc-correlation-0002
                - term [ref=e457]: Last synchronized
                - definition [ref=e458]: 2026-01-15 13:45 UTC
          - navigation "Specimen multi-level navigation" [ref=e459]:
            - heading "Multi-level navigation" [level=2] [ref=e460]
            - list [ref=e461]:
              - listitem [ref=e462]:
                - link "Foundation" [ref=e463] [cursor=pointer]:
                  - /url: "#fc-type-ramp-title"
              - listitem [ref=e464]:
                - button "Generated surfaces" [expanded] [ref=e465]
                - list [ref=e466]:
                  - listitem [ref=e467]:
                    - link "Projection grid" [ref=e468] [cursor=pointer]:
                      - /url: "#fc-badge-grid-title"
                  - listitem [ref=e469]:
                    - link "Command lifecycle" [ref=e470] [cursor=pointer]:
                      - /url: "#fc-specimen-command-title"
    - generic [ref=e471]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  544 |     const cue = page.getByTestId('fc-ae-fresh-presentation');
  545 |     await expect(cue).toContainText(/new|updated/i);
  546 |     await evidence(page, cue, `fresh-presentation-${theme}`, info);
  547 |     await expectSurfaceContrast(cue, 'border');
  548 |   });
  549 | }
  550 | 
  551 | test('paint measurement follows slots, ignores unpainted pseudo borders and sees native modal text through inert ancestors', async ({ page }) => {
  552 |   await page.setContent('<style>#edge{border:1px solid #eee;background:white}#edge::after{content:"";border-bottom:2px solid black;transform:scaleX(0);display:block}</style><div id="host" style="color:black;background:black">Slotted readable label</div><div id="edge">Boundary</div><div inert><dialog id="modal"><p>Visible modal text</p></dialog></div>');
  553 |   await page.locator('#host').evaluate(element => { element.attachShadow({ mode: 'open' }).innerHTML = '<style>slot{color:white}</style><slot></slot>'; });
  554 |   expect((await expectSurfaceContrast(page.locator('#host')))[0].ratio).toBe(21);
  555 |   expect((await expectSurfaceContrast(page.locator('#host').locator('slot')))[0].ratio).toBe(21);
  556 |   await expect(expectSurfaceContrast(page.locator('#edge'), 'border')).rejects.toThrow(/contrast failures/);
  557 |   await page.addStyleTag({ content: '#edge::after{transform:scaleX(1)}' });
  558 |   expect((await expectSurfaceContrast(page.locator('#edge'), 'border')).some(sample => sample.ratio >= 3)).toBe(true);
  559 |   await page.locator('#modal').evaluate(element => (element as HTMLDialogElement).showModal());
  560 |   await expectSurfaceContrast(page.locator('#modal'));
  561 | });
  562 | 
  563 | 
  564 | test('validation links keep native same-page href activation when focus enhancement is unavailable', async ({ page }, info) => {
  565 |   await page.route('**/_content/Hexalith.FrontComposer.Shell/js/fc-focus.js', async route => {
  566 |     const response = await route.fetch();
  567 |     const body = (await response.text())
  568 |       .replace('export function focusValidationOutcome(', 'export function unavailableFocusValidationOutcome(')
  569 |       .replace('export function focusValidationTarget(', 'export function unavailableFocusValidationTarget(')
  570 |       + "\nexport function focusValidationOutcome(){throw new Error('Fixed focus-enhancement fixture unavailable');}\nexport function focusValidationTarget(){throw new Error('Fixed focus-enhancement fixture unavailable');}\n";
  571 |     await route.fulfill({ response, body });
  572 |   });
  573 |   await ready(page, '/__frontcomposer/specimens/type', 'light');
  574 |   await page.getByTestId('fc-destructive-command-specimen').getByRole('button', { name: 'Purge Specimen Record', exact: true }).click();
  575 |   const link = page.getByTestId('fc-validation-summary').getByRole('link', { name: 'The Retention field is required.', exact: true });
  576 |   await expect(link).toHaveCount(1);
  577 |   const href = await link.getAttribute('href');
  578 |   expect(href).toMatch(/__frontcomposer\/specimens\/type#.+-Retention$/u);
  579 |   await link.focus();
  580 |   await page.keyboard.press('Shift+Tab');
  581 |   await page.keyboard.press('Tab');
  582 |   await expect(link).toBeFocused();
  583 |   await page.keyboard.press('Enter');
  584 |   await expect(page).toHaveURL(new URL(href!, await page.locator('base').getAttribute('href').then(base => new URL(base!, page.url()).href)).href);
  585 |   await info.attach('native-validation-link-fallback', { body: JSON.stringify({ role: 'link', href, activation: 'keyboard Enter', duplicateKeyboardStops: false }), contentType: 'application/json' });
  586 | });
  587 | 
  588 | test('G09 forced-color focus geometry rejects a mode-specific clipped ring', async ({ page }) => {
  589 |   await page.setContent('<style>button{position:fixed;left:2px;top:40px;width:80px;height:40px;appearance:none;outline:none}button:focus{outline:2px solid black}@media(forced-colors:active){button:focus{outline-width:6px}}</style><button>Save</button>');
  590 |   await page.locator('button').focus();
  591 |   expect((await focusGeometry(page.locator('button'))).failures).toEqual([]);
  592 |   await page.emulateMedia({ forcedColors: 'active' });
  593 |   expect((await focusGeometry(page.locator('button'))).failures).toContain('viewport clips target or focus ring');
  594 | });
  595 | 
  596 | for (const theme of ['light', 'dark']) for (const scope of ['tenant', 'user']) {
  597 |   test(`held generated recovery cancels after ${scope} scope change in ${theme}`, async ({ page }) => {
  598 |     await page.route('**/fc-focus.js', async route => {
  599 |       const response = await route.fetch();
  600 |       const source = (await response.text()).replace('export function focusReplacementHeading(key, headingId)', 'function originalFocusReplacementHeading(key, headingId)');
  601 |       await route.fulfill({ response, body: source + `
  602 | export async function focusReplacementHeading(key, headingId) {
  603 |   const gate = window.__aeRecoveryGate;
  604 |   if (gate?.hold) {
  605 |     gate.entered = true;
  606 |     gate.capturedDetached = focusBeforeReplacement.get(key) instanceof HTMLElement && !focusBeforeReplacement.get(key).isConnected;
  607 |     await new Promise(resolve => { gate.release = () => { gate.released = true; resolve(); }; });
  608 |   }
  609 |   if (gate?.hold) gate.captureStillOwned = focusBeforeReplacement.has(key);
  610 |   const result = originalFocusReplacementHeading(key, headingId);
  611 |   if (gate?.hold) gate.returned = result;
  612 |   return result;
  613 | }` });
  614 |     });
  615 |     await ready(page, `${scenarioPath}&theme=${theme}`, theme);
  616 |     const grid = page.getByTestId('fc-generated-counter-grid');
  617 |     await grid.scrollIntoViewIfNeeded();
  618 |     await expect(grid.locator('[data-fc-datagrid]')).toBeVisible();
  619 |     await expect(grid.locator('tbody tr.fluent-data-grid-row').first()).toBeVisible();
  620 |     await page.getByTestId('fc-ae-rows-two').click();
  621 |     // The control above the grid may scroll its virtualized rows out of view.
  622 |     // Establish the completed two-row render before entering the focus recovery sequence.
  623 |     await grid.scrollIntoViewIfNeeded();
  624 |     await expect(grid.locator('tbody tr.fluent-data-grid-row')).toHaveCount(2);
  625 |     await expect(grid.getByRole('gridcell', { name: 'FC-AE-2', exact: true })).toBeVisible();
  626 |     await grid.getByRole('gridcell', { name: 'FC-AE-1', exact: true }).click();
  627 |     const detail = grid.locator('.fc-expand-in-row-detail');
  628 |     await expect(detail).toContainText('FC-AE-1');
  629 |     await detail.locator('a,button,fluent-button,[tabindex="0"]').first().focus();
  630 |     const arm = async () => page.evaluate(() => { (window as typeof window & { __aeRecoveryGate: unknown }).__aeRecoveryGate = { hold: true, entered: false, released: false }; });
  631 |     const entered = async () => {
  632 |       await expect.poll(() => page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { entered: boolean; capturedDetached?: boolean } }).__aeRecoveryGate)).toMatchObject({ entered: true, capturedDetached: true });
  633 |       await expect(detail.locator('a,button,fluent-button,[tabindex="0"]')).toHaveCount(0);
  634 |       await expect(grid.locator('.fc-expanded-row-hidden-banner-text')).toBeVisible();
  635 |     };
  636 |     const release = async () => {
  637 |       await page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { release: () => void } }).__aeRecoveryGate.release());
  638 |       await expect.poll(() => page.evaluate(() => (window as typeof window & { __aeRecoveryGate: { returned?: boolean; captureStillOwned?: boolean } }).__aeRecoveryGate)).toMatchObject({ returned: false, captureStillOwned: false });
  639 |     };
  640 |     await arm();
  641 |     await page.getByTestId('fc-ae-rows-missing').dispatchEvent('click');
  642 |     await entered();
  643 |     await page.getByTestId(`fc-ae-scope-${scope}`).dispatchEvent('click');
> 644 |     await expect(page.locator('.fc-expanded-row-hidden-banner-text')).toHaveCount(0);
      |                                                                       ^ Error: expect(locator).toHaveCount(expected) failed
  645 |     const current = page.getByTestId('fc-ae-rows-two');
  646 |     await expect(current).toBeVisible();
  647 |     await current.focus();
  648 |     await release();
  649 |     await expect(current).toBeFocused();
  650 |     await expect(page.locator('.fc-expanded-row-hidden-banner-text')).toHaveCount(0);
  651 |     await expect(page.getByTestId('fc-ae-scenarios').getByTestId('fc-surface-status')).not.toContainText('not in the current results');
  652 |   });
  653 | }
  654 | 
```