# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: responsive-accessibility.spec.ts >> Story 13.6 responsive operator surfaces >> type states retain contrast, system colors and immediate reduced-motion cues in light
- Location: specs/responsive-accessibility.spec.ts:383:5

# Error details

```
Error: Horizontal scroll regions must be labelled grids or tablists

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "DIV#",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?theme=light&density=compact#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /__frontcomposer/specimens/type?theme=light&density=compact#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - button "Toggle navigation" [ref=e12] [cursor=pointer]
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - button "Change theme" [ref=e19] [cursor=pointer]:
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "FU" [ref=e35] [cursor=pointer]
    - navigation "Primary navigation" [ref=e39]:
      - generic [ref=e40]:
        - button "Counter" [ref=e41] [cursor=pointer]
        - button "More Counter pages" [ref=e47] [cursor=pointer]
        - button "Default" [ref=e54] [cursor=pointer]
        - button "Specimens" [ref=e59] [cursor=pointer]
        - button "More Specimens pages" [ref=e65] [cursor=pointer]
    - generic [ref=e72]:
      - status [ref=e73]: Density set to Compact.
      - main [ref=e74]:
        - status [ref=e75]
        - status [ref=e76]
        - main [ref=e78]:
          - generic [ref=e79]:
            - paragraph [ref=e80]: FrontComposer accessibility specimen
            - heading "Type, theme, density, lifecycle, and navigation specimen" [active] [level=1] [ref=e81]
            - paragraph [ref=e82]: Generated shell surfaces rendered with deterministic local data.
            - link "Skip to command form" [ref=e83] [cursor=pointer]:
              - /url: "#fc-specimen-command-form"
          - region [ref=e84]:
            - heading "Theme and density controls" [level=2] [ref=e85]
            - generic [ref=e86]:
              - link "light" [ref=e87] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact
              - link "dark" [ref=e88] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=dark&density=compact
              - link "compact" [ref=e89] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=compact
              - link "comfortable" [ref=e90] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=comfortable
              - link "roomy" [ref=e91] [cursor=pointer]:
                - /url: /__frontcomposer/specimens/type?theme=light&density=roomy
          - region [ref=e92]:
            - heading "Type ramp" [level=2] [ref=e93]
            - generic [ref=e94]:
              - article [ref=e95]:
                - paragraph [ref=e96]: Display
                - generic [ref=e97]: FrontComposer Display
              - article [ref=e98]:
                - paragraph [ref=e99]: Title
                - generic [ref=e100]: Generated command title
              - article [ref=e101]:
                - paragraph [ref=e102]: Subtitle
                - generic [ref=e103]: Projection subtitle and context
              - article [ref=e104]:
                - paragraph [ref=e105]: Body
                - generic [ref=e106]: Readable generated body text
              - article [ref=e107]:
                - paragraph [ref=e108]: Caption
                - generic [ref=e109]: Supplemental metadata caption
              - article [ref=e110]:
                - paragraph [ref=e111]: Code
                - generic [ref=e112]: FC-STATIC-0001
          - region [ref=e113]:
            - heading "Semantic color tokens" [level=2] [ref=e114]
            - generic [ref=e115]:
              - article [ref=e116]:
                - heading "light theme" [level=3] [ref=e117]
                - generic [ref=e118]:
                  - generic [ref=e120]: Neutral
                  - strong [ref=e121]: Available
                - generic [ref=e122]:
                  - generic [ref=e124]: Informational
                  - strong [ref=e125]: Queued
                - generic [ref=e126]:
                  - generic [ref=e128]: Success
                  - strong [ref=e129]: Confirmed
                - generic [ref=e130]:
                  - generic [ref=e132]: Warning
                  - strong [ref=e133]: Needs review
                - generic [ref=e134]:
                  - generic [ref=e136]: Danger
                  - strong [ref=e137]: Rejected
                - generic [ref=e138]:
                  - generic [ref=e140]: Accent
                  - strong [ref=e141]: Selected
              - article [ref=e142]:
                - heading "dark theme" [level=3] [ref=e143]
                - generic [ref=e144]:
                  - generic [ref=e146]: Neutral
                  - strong [ref=e147]: Available
                - generic [ref=e148]:
                  - generic [ref=e150]: Informational
                  - strong [ref=e151]: Queued
                - generic [ref=e152]:
                  - generic [ref=e154]: Success
                  - strong [ref=e155]: Confirmed
                - generic [ref=e156]:
                  - generic [ref=e158]: Warning
                  - strong [ref=e159]: Needs review
                - generic [ref=e160]:
                  - generic [ref=e162]: Danger
                  - strong [ref=e163]: Rejected
                - generic [ref=e164]:
                  - generic [ref=e166]: Accent
                  - strong [ref=e167]: Selected
          - region [ref=e168]:
            - heading "Density states" [level=2] [ref=e169]
            - generic [ref=e170]:
              - article [ref=e171]:
                - heading "compact density" [level=3] [ref=e172]
                - button "Primary action" [ref=e173]
                - generic [ref=e174]:
                  - text: Label
                  - textbox "compact density text input" [ref=e175]: compact sample
              - article [ref=e176]:
                - heading "comfortable density" [level=3] [ref=e177]
                - button "Primary action" [ref=e178]
                - generic [ref=e179]:
                  - text: Label
                  - textbox "comfortable density text input" [ref=e180]: comfortable sample
              - article [ref=e181]:
                - heading "roomy density" [level=3] [ref=e182]
                - button "Primary action" [ref=e183]
                - generic [ref=e184]:
                  - text: Label
                  - textbox "roomy density text input" [ref=e185]: roomy sample
          - region [ref=e186]:
            - heading "Generated projection DataGrid and badge states" [level=2] [ref=e187]
            - status [ref=e188]
            - paragraph [ref=e189]: 6 specimen status
            - group "Status filter chips" [ref=e190]:
              - button "Neutral, currently inactive" [ref=e191] [cursor=pointer]:
                - generic [ref=e192]: Neutral
              - button "Info, currently inactive" [ref=e193] [cursor=pointer]:
                - generic [ref=e194]: Info
              - button "Success, currently inactive" [ref=e195] [cursor=pointer]:
                - generic [ref=e196]: Success
              - button "Warning, currently inactive" [ref=e197] [cursor=pointer]:
                - generic [ref=e198]: Warning
              - button "Danger, currently inactive" [ref=e199] [cursor=pointer]:
                - generic [ref=e200]: Danger
              - button "Accent, currently inactive" [ref=e201] [cursor=pointer]:
                - generic [ref=e202]: Accent
            - text: 6 specimen status
            - region "specimen status" [ref=e203]:
              - table [ref=e204]:
                - rowgroup [ref=e205]:
                  - row [ref=e206]:
                    - cell [ref=e207]:
                      - generic [ref=e208]:
                        - text: FC-1000Neutral projection
                        - 'img "Status: Neutral" [ref=e210]'
                        - text: Shell
                  - row [ref=e213]:
                    - cell [ref=e214]:
                      - generic [ref=e215]:
                        - text: FC-1001Info projection
                        - 'img "Status: Info" [ref=e217]'
                        - text: SourceTools
                  - row [ref=e220]:
                    - cell [ref=e221]:
                      - generic [ref=e222]:
                        - text: FC-1002Success projection
                        - 'img "Status: Success" [ref=e224]'
                        - text: Contracts
                  - row [ref=e227]:
                    - cell [ref=e228]:
                      - generic [ref=e229]:
                        - text: FC-1003Warning projection
                        - 'img "Status: Warning" [ref=e231]'
                        - text: Testing
                  - row [ref=e234]:
                    - cell [ref=e235]:
                      - generic [ref=e236]:
                        - text: FC-1004Danger projection
                        - 'img "Status: Danger" [ref=e238]'
                        - text: CI
                  - row [ref=e241]:
                    - cell [ref=e242]:
                      - generic [ref=e243]:
                        - text: FC-1005Accent projection
                        - 'img "Status: Accent" [ref=e245]'
                        - text: Docs
              - region "Details for"
          - region [ref=e248]:
            - heading "Generated Counter projection grid" [level=2] [ref=e249]
            - status [ref=e250]
            - paragraph [ref=e251]: 1 counters
            - text: 1 counters
            - region "counters" [ref=e252]:
              - table [ref=e253]:
                - rowgroup [ref=e254]:
                  - row [ref=e255]:
                    - cell [ref=e256]:
                      - generic [ref=e257]:
                        - text: fc-correlation-0002421/15/2026
                        - generic "Metadata with unsupported type System.Collections.Generic.Dictionary requires a custom renderer" [ref=e259]:
                          - strong [ref=e260]: Metadata
                          - text: (System.Collections.Generic.Dictionary) This field requires a custom renderer.
                          - link "Learn how to customize this field" [ref=e261] [cursor=pointer]:
                            - /url: https://hexalith.github.io/FrontComposer/diagnostics/HFC1002
              - region "Details for"
          - region [ref=e262]:
            - heading "Command form and lifecycle states" [level=2] [ref=e263]
            - form "Specimen command form" [ref=e264]:
              - generic [ref=e265]:
                - text: Counter name
                - textbox "Counter name" [ref=e266]: Specimen counter
              - generic [ref=e267]:
                - text: Amount
                - spinbutton "Amount" [ref=e268]: "3"
              - button "Submit command" [ref=e269]
              - button "Cancel" [ref=e270]
            - list "Five command lifecycle states" [ref=e271]:
              - listitem [ref=e272]:
                - strong [ref=e273]: Idle
                - text: Ready to submit.
              - listitem [ref=e274]:
                - strong [ref=e275]: Submitting
                - text: Submitting command.
              - listitem [ref=e276]:
                - strong [ref=e277]: Acknowledged
                - text: Command accepted by the host.
              - listitem [ref=e278]:
                - strong [ref=e279]: Syncing
                - text: Waiting for projection synchronization.
              - listitem [ref=e280]:
                - strong [ref=e281]: Confirmed or rejected
                - text: Terminal confirmation and rejection states remain text-visible.
          - region [ref=e282]:
            - heading "Destructive command confirmation" [level=2] [ref=e283]
            - group [ref=e285]:
              - generic "Purge Specimen Record command form" [ref=e286]:
                - generic [ref=e287]:
                  - generic [ref=e288]:
                    - group "Purge details" [ref=e289]:
                      - generic [ref=e292]:
                        - generic: Record Id
                        - generic "Record Id" [ref=e294]:
                          - textbox "Record Id, Required" [ref=e296]: FC-1002
                        - generic: Record to purge.
                      - generic [ref=e299]:
                        - generic: Reason
                        - generic "Reason" [ref=e301]:
                          - textbox "Reason, Required" [ref=e303]: QA destructive confirmation coverage
                        - generic: Why this purge is required.
                    - generic [ref=e306]:
                      - generic: Retention
                      - generic "Retention" [ref=e308] [cursor=pointer]:
                        - combobox "Retention" [ref=e310]
                      - generic: How long the purged record stays recoverable.
                    - button "Purge Specimen Record" [ref=e315] [cursor=pointer]
                  - status [ref=e317]
          - region [ref=e318]:
            - heading "Policy-gated command authorization" [level=2] [ref=e319]
            - group [ref=e321]:
              - generic "Policy Allowed Specimen command form" [ref=e322]:
                - generic [ref=e323]:
                  - generic [ref=e324]:
                    - generic [ref=e326]:
                      - generic: Record Id
                      - generic "Record Id" [ref=e328]:
                        - textbox "Record Id, Required" [ref=e330]: FC-AUTH-ALLOW
                    - generic [ref=e332]:
                      - generic: Reason
                      - generic "Reason" [ref=e334]:
                        - textbox "Reason, Required" [ref=e336]: QA policy allowed coverage
                    - button "Policy Allowed Specimen" [ref=e337] [cursor=pointer]
                  - status [ref=e339]
            - group [ref=e340]:
              - group [ref=e341]:
                - heading "Permission required" [level=2] [ref=e342]
                - paragraph [ref=e343]: You do not have permission to Policy Denied Specimen.
          - region [ref=e344]:
            - heading "Expanded detail view" [level=2] [ref=e345]
            - group [ref=e346]:
              - generic "Open projection details for FC-1002" [ref=e347]
              - generic [ref=e348]:
                - term [ref=e349]: Correlation
                - definition [ref=e350]: fc-correlation-0002
                - term [ref=e351]: Last synchronized
                - definition [ref=e352]: 2026-01-15 13:45 UTC
          - navigation "Specimen multi-level navigation" [ref=e353]:
            - heading "Multi-level navigation" [level=2] [ref=e354]
            - list [ref=e355]:
              - listitem [ref=e356]:
                - link "Foundation" [ref=e357] [cursor=pointer]:
                  - /url: "#fc-type-ramp-title"
              - listitem [ref=e358]:
                - button "Generated surfaces" [expanded] [ref=e359]
                - list [ref=e360]:
                  - listitem [ref=e361]:
                    - link "Projection grid" [ref=e362] [cursor=pointer]:
                      - /url: "#fc-badge-grid-title"
                  - listitem [ref=e363]:
                    - link "Command lifecycle" [ref=e364] [cursor=pointer]:
                      - /url: "#fc-specimen-command-title"
    - generic [ref=e365]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  1   | import { expect, type Locator, type Page } from '@playwright/test';
  2   | 
  3   | export type TargetException = {
  4   |   selector: string;
  5   |   kind: 'Inline' | 'Spacing' | 'Equivalent' | 'User Agent Control' | 'Essential';
  6   |   rationale: string;
  7   |   keyboardPath: string;
  8   |   evidence: string;
  9   |   equivalentSelector?: string;
  10  |   essentialReason?: string;
  11  | };
  12  | 
  13  | /** Apply all four overrides through rerenders, including shadow roots attached later. */
  14  | export async function applyTextSpacing(page: Page): Promise<void> {
  15  |   await page.evaluate(() => {
  16  |     const owner = window as unknown as { aeSpacingCleanup?: () => void };
  17  |     owner.aeSpacingCleanup?.();
  18  |     const css = '* { line-height: 1.5 !important; letter-spacing: .12em !important; word-spacing: .16em !important; } p { margin-block-end: 2em !important; }';
  19  |     const roots = new Set<Document | ShadowRoot>();
  20  |     const visit = (root: Document | ShadowRoot) => {
  21  |       if (!roots.has(root)) { roots.add(root); observer.observe(root instanceof Document ? root.documentElement : root, { childList: true, subtree: true }); }
  22  |       if (!root.querySelector('[data-ae-text-spacing]')) {
  23  |         const style = document.createElement('style'); style.dataset.aeTextSpacing = 'true'; style.textContent = css;
  24  |         (root instanceof Document ? root.head : root).append(style);
  25  |       }
  26  |       root.querySelectorAll('*').forEach(element => { if (element.shadowRoot) visit(element.shadowRoot); });
  27  |     };
  28  |     const observer = new MutationObserver(() => { for (const root of roots) visit(root); });
  29  |     const original = Element.prototype.attachShadow;
  30  |     const patched = function (this: Element, init: ShadowRootInit) { const root = original.call(this, init); visit(root); return root; };
  31  |     Element.prototype.attachShadow = patched;
  32  |     owner.aeSpacingCleanup = () => {
  33  |       observer.disconnect();
  34  |       if (Element.prototype.attachShadow === patched) Element.prototype.attachShadow = original;
  35  |       for (const root of roots) root.querySelectorAll('[data-ae-text-spacing]').forEach(style => style.remove());
  36  |       delete owner.aeSpacingCleanup;
  37  |     };
  38  |     visit(document);
  39  |   });
  40  | }
  41  | 
  42  | /** Remove the overrides and their observer/prototype seam before a restoration round trip. */
  43  | export async function removeTextSpacing(page: Page): Promise<void> {
  44  |   await page.evaluate(() => (window as unknown as { aeSpacingCleanup?: () => void }).aeSpacingCleanup?.());
  45  | }
  46  | 
  47  | export async function expectNoPageOverflow(page: Page): Promise<void> {
  48  |   const geometry = await page.evaluate(() => {
  49  |     const root = document.scrollingElement ?? document.documentElement;
  50  |     const unlabelled: string[] = [];
  51  |     const visit = (scope: Document | ShadowRoot) => {
  52  |       for (const element of scope.querySelectorAll('*')) {
  53  |         if (element.shadowRoot) visit(element.shadowRoot);
  54  |         const style = getComputedStyle(element), box = element.getBoundingClientRect();
  55  |         if (box.width === 0 || box.height === 0 || style.visibility === 'hidden' || element.closest('[hidden],[aria-hidden="true"]')) continue;
  56  |         if (!/(auto|scroll)/u.test(style.overflowX) || element.scrollWidth <= element.clientWidth + 1) continue;
  57  |         const labelOwner = element.matches('fluent-tablist') && element.parentElement?.matches('.fluent-tabs') ? element.parentElement : element;
  58  |         const label = labelOwner.getAttribute('aria-label')?.trim() || labelOwner.getAttribute('aria-labelledby')?.split(/\s+/u).map(id => element.ownerDocument.getElementById(id)?.textContent?.trim()).filter(Boolean).join(' ');
  59  |         const grid = element.matches('[role="region"]') && Boolean(element.querySelector('[role="grid"],table,[data-fc-datagrid]'));
  60  |         const tabs = element.matches('[role="tablist"],fluent-tablist');
  61  |         if (!(label && (grid || tabs))) unlabelled.push(`${element.tagName}#${element.id}`);
  62  |       }
  63  |     };
  64  |     visit(document);
  65  |     return { width: root.clientWidth, scrollWidth: root.scrollWidth, unlabelled };
  66  |   });
  67  |   expect(geometry.scrollWidth, `Page overflow: ${JSON.stringify(geometry)}`).toBeLessThanOrEqual(geometry.width + 1);
> 68  |   expect(geometry.unlabelled, 'Horizontal scroll regions must be labelled grids or tablists').toEqual([]);
      |                                                                                               ^ Error: Horizontal scroll regions must be labelled grids or tablists
  69  | }
  70  | 
  71  | /** Inventory actual hit targets, collapsing a Fluent control and its shadow control to one target. */
  72  | export async function inventoryTargets(page: Page, exceptions: TargetException[] = []) {
  73  |   return page.evaluate((records) => {
  74  |     const selector = 'a[href],button,input:not([type="hidden"]),select,textarea,summary,[role="button"],[role="tab"],[role="option"],[role="menuitem"],[role="checkbox"],[role="radio"],[role="switch"],fluent-button,fluent-text-input,fluent-number-input,fluent-select,fluent-combobox,fluent-dropdown,fluent-radio,fluent-switch,[tabindex]:not([tabindex="-1"]),[onclick]';
  75  |     const all: Element[] = [];
  76  |     const visit = (root: Document | ShadowRoot) => {
  77  |       root.querySelectorAll('*').forEach(element => { all.push(element); if (element.shadowRoot) visit(element.shadowRoot); });
  78  |     };
  79  |     visit(document);
  80  |     const visible = (element: Element) => {
  81  |       const rect = element.getBoundingClientRect();
  82  |       const style = getComputedStyle(element);
  83  |       return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none'
  84  |         && !element.closest('[inert]') && !element.closest('[aria-hidden="true"]');
  85  |     };
  86  |     const modalDialog = all.find(element => element.matches('dialog[open]'));
  87  |     const modalRoot = modalDialog?.getRootNode();
  88  |     const modal = modalRoot instanceof ShadowRoot ? modalRoot.host : modalDialog;
  89  |     const candidates = all.filter(element => element.matches(selector) && visible(element)
  90  |       && (!modal || element === modal || modal.contains(element) || element.getRootNode() instanceof ShadowRoot && modal.contains((element.getRootNode() as ShadowRoot).host)));
  91  |     const targets = candidates.filter(element => {
  92  |       const root = element.getRootNode();
  93  |       return !(root instanceof ShadowRoot && candidates.includes(root.host))
  94  |         && !candidates.some(ancestor => ancestor !== element && ancestor.tagName.startsWith('FLUENT-') && ancestor.contains(element));
  95  |     });
  96  |     const boxes = targets.map(element => ({ element, rect: element.getBoundingClientRect() }));
  97  |     const intersects = (a: DOMRect, b: DOMRect) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
  98  |     const circleIntersectsRect = (x: number, y: number, rect: DOMRect) => Math.hypot(x - Math.max(rect.left, Math.min(x, rect.right)), y - Math.max(rect.top, Math.min(y, rect.bottom))) < 12 - .01;
  99  |     const used = new Set<string>();
  100 |     const inventory = boxes.map(({ element, rect }, index) => {
  101 |       const identifier = element.id ? `#${element.id}` : element.getAttribute('data-testid') ? `[data-testid="${element.getAttribute('data-testid')}"]` : `${element.tagName.toLowerCase()}[inventory-index="${index}"]`;
  102 |       const record = records.find(item => element.matches(item.selector));
  103 |       let failure: string | null = null;
  104 |       const conforming = rect.width >= 24 && rect.height >= 24;
  105 |       if (record) used.add(record.selector);
  106 |       if (record && conforming) failure = 'Exception is stale: target already meets 24px minimum';
  107 |       if (!conforming) {
  108 |         if (!record || !record.rationale.trim() || !record.keyboardPath.trim() || !record.evidence.trim()) failure = 'Undersized target lacks an evidenced exception';
  109 |         else if (record.kind === 'Spacing') {
  110 |           const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
  111 |           if (boxes.some(other => other.element !== element && (circleIntersectsRect(x, y, other.rect)
  112 |             || (other.rect.width < 24 || other.rect.height < 24) && Math.hypot(x - other.rect.left - other.rect.width / 2, y - other.rect.top - other.rect.height / 2) < 24 - .01))) failure = '24px spacing circle intersects a target or neighboring undersized circle';
  113 |         } else if (record.kind === 'Equivalent') {
  114 |           const equivalent = record.equivalentSelector ? document.querySelector(record.equivalentSelector) : null;
  115 |           const box = equivalent?.getBoundingClientRect();
  116 |           if (!equivalent || equivalent === element || !visible(equivalent) || !box || box.width < 24 || box.height < 24 || intersects(rect, box)) failure = 'Equivalent control is absent, identical, overlapping, or undersized';
  117 |         } else if (record.kind === 'Inline') {
  118 |           if (!element.closest('p,li,dd') || !['inline', 'inline-block'].includes(getComputedStyle(element).display) || element.matches('button,[role="button"],fluent-button')) failure = 'Inline exception does not apply to a control outside running text';
  119 |         } else if (record.kind === 'Essential' && (!record.essentialReason?.trim() || !element.matches('[data-ae-essential-target]'))) failure = 'Essential exception requires an identified essential presentation and specific justification';
  120 |         else if (record.kind === 'User Agent Control' && (!element.matches('input,select,textarea') || getComputedStyle(element).appearance === 'none' || element.hasAttribute('style'))) failure = 'User agent exception requires an unmodified native control';
  121 |       }
  122 |       const css = getComputedStyle(element);
  123 |       const equivalent = record?.kind === 'Equivalent' && record.equivalentSelector ? document.querySelector(record.equivalentSelector) : null;
  124 |       const equivalentBox = equivalent?.getBoundingClientRect();
  125 |       return { target: identifier, width: rect.width, height: rect.height,
  126 |         box: { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom },
  127 |         traits: { runningText: Boolean(element.closest('p,li,dd')) && ['inline','inline-block'].includes(css.display) && !element.matches('button,[role="button"],fluent-button'), nativeUnmodified: element.matches('input,select,textarea') && css.appearance !== 'none' && !element.hasAttribute('style'), essentialIdentified: element.hasAttribute('data-ae-essential-target') },
  128 |         equivalent: equivalent && equivalentBox ? { distinct: equivalent !== element, visible: visible(equivalent), width: equivalentBox.width, height: equivalentBox.height, box: { left: equivalentBox.left, top: equivalentBox.top, right: equivalentBox.right, bottom: equivalentBox.bottom } } : null,
  129 |         conforming, exception: record ?? null, failure };
  130 |     });
  131 |     return { inventory, unusedExceptions: records.filter(record => !used.has(record.selector)).map(record => record.selector) };
  132 |   }, exceptions);
  133 | }
  134 | 
  135 | export async function expectTargetSizes(page: Page, exceptions: TargetException[] = []) {
  136 |   const result = await inventoryTargets(page, exceptions);
  137 |   expect(result.inventory.length, 'Pointer-target inventory must be nonempty').toBeGreaterThan(0);
  138 |   expect(result.unusedExceptions, 'Stale or unmatched exception selectors').toEqual([]);
  139 |   expect(result.inventory.filter(target => target.failure), 'AE-04 target-size failures').toEqual([]);
  140 |   return result.inventory;
  141 | }
  142 | 
  143 | type PaintBox = { left: number; top: number; right: number; bottom: number };
  144 | type PaintClip = { kind: 'none' | 'rect' | 'hidden' | 'unsupported'; box?: PaintBox };
  145 | type RestingPaint = Map<Element, Record<string, Record<string, string>>>;
  146 | type PaintAudit = { clip: (css: CSSStyleDeclaration, box: PaintBox) => PaintClip; parse: (value: string) => number[]; resting: (scope: Element) => RestingPaint; changed: (element: Element, pseudo: string | null, style: CSSStyleDeclaration, resting: RestingPaint, properties: string[]) => boolean; shadows: (element: Element, pseudo: string | null, style: CSSStyleDeclaration, resting: RestingPaint) => string[] };
  147 | 
  148 | /** Observe resting pseudo-class paint synchronously, suppressing application focus callbacks. */
  149 | async function preparePaintAudit(root: Locator) {
  150 |   await root.evaluate(() => {
  151 |     const parse = (value: string): number[] => {
  152 |       if (!CSS.supports('color', value)) throw new Error(`Unsupported computed paint: ${value}`);
  153 |       const canvas = document.createElement('canvas'); canvas.width = canvas.height = 1;
  154 |       const context = canvas.getContext('2d')!; context.fillStyle = value; context.fillRect(0, 0, 1, 1);
  155 |       const pixel = context.getImageData(0, 0, 1, 1).data;
  156 |       return [pixel[0], pixel[1], pixel[2], pixel[3] / 255];
  157 |     };
  158 |     const clip = (css: CSSStyleDeclaration, box: PaintBox): PaintClip => {
  159 |       let result = { left: box.left, top: box.top, right: box.right, bottom: box.bottom }, clipped = false;
  160 |       const width = box.right - box.left, height = box.bottom - box.top;
  161 |       const length = (value: string, extent: number): number | null => {
  162 |         if (/^-?[\d.]+px$/u.test(value) || value === '0') return parseFloat(value);
  163 |         if (/^-?[\d.]+%$/u.test(value)) return parseFloat(value) * extent / 100;
  164 |         const calc = value.match(/^calc\(\s*(-?[\d.]+)%\s*([+-])\s*([\d.]+)px\s*\)$/u);
  165 |         return calc ? Number(calc[1]) * extent / 100 + (calc[2] === '+' ? 1 : -1) * Number(calc[3]) : null;
  166 |       };
  167 |       if (css.clip && css.clip !== 'auto' && ['absolute','fixed'].includes(css.position)) {
  168 |         const rect = css.clip.match(/^rect\((.*)\)$/u)?.[1].split(/[,\s]+/u).filter(Boolean);
```