# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> AE complete state matrix light >> generated zero-field policy: safe feedback, focus, owner, next attempt
- Location: specs/accessibility-state-matrix.spec.ts:112:7

# Error details

```
Error: page.evaluate: Test ended.
```

# Test source

```ts
  681 |       if (sampleKind === 'text') {
  682 |         if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
  683 |           const placeholder = getComputedStyle(element, '::placeholder');
  684 |           const glyph = glyphPaint;
  685 |           const paint = element.value.trim() ? glyph(css) : element.getAttribute('placeholder') ? glyph(placeholder) : null;
  686 |           if (paint) sample(element, paint, element.value.trim() ? 'input value' : 'input placeholder', 4.5, false, element.value.trim() ? 1 : Number(placeholder.opacity));
  687 |         }
  688 |         const textNodes = element instanceof HTMLSlotElement ? element.assignedNodes({ flatten: true }) : element.childNodes;
  689 |         for (const node of textNodes) if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim() && !sampledText.has(node)) {
  690 |           sampledText.add(node);
  691 |           const range = document.createRange(); range.selectNodeContents(node);
  692 |           if (![...range.getClientRects()].some(box => box.width > 0 && box.height > 0)) continue;
  693 |           const textOwner = (node as Text).assignedSlot ?? element;
  694 |           const textCss = getComputedStyle(textOwner);
  695 |           const large = parseFloat(textCss.fontSize) >= 24 || parseFloat(textCss.fontSize) >= 18.667 && parseInt(textCss.fontWeight) >= 700;
  696 |           sample(textOwner, glyphPaint(textCss), node.textContent.trim().slice(0, 80), large ? 3 : 4.5, false, 1, [...range.getClientRects()]);
  697 |         }
  698 |         for (const pseudo of ['::before', '::after']) {
  699 |           const generated = getComputedStyle(element, pseudo);
  700 |           if (!generated.content || ['none','normal','""',"''"].includes(generated.content) || generated.visibility === 'hidden' || generated.display === 'none' || Number(generated.opacity) === 0) continue;
  701 |           if (!/^("[^"]*"|'[^']*')$/u.test(generated.content)) throw new Error('Generated content needs pixel evidence');
  702 |           if (parse(generated.backgroundColor)[3] > 0 || generated.backgroundImage !== 'none') throw new Error('Generated text background needs pixel evidence');
  703 |           sample(element, glyphPaint(generated), `${pseudo} generated text`, 4.5, false, Number(generated.opacity));
  704 |         }
  705 |       } else if (sampleKind === 'icon' && element.matches('svg path,svg polygon,svg circle,svg rect,svg ellipse,svg line,svg polyline,svg use,svg text')) {
  706 |         if (element.matches('use')) throw new Error('SVG use instance needs pixel evidence');
  707 |         for (const property of ['fill', 'stroke']) {
  708 |           const paint = css.getPropertyValue(property);
  709 |           if (property === 'stroke' && parseFloat(css.strokeWidth) <= 0 || property === 'fill' && element.matches('line')) continue;
  710 |           if (paint !== 'none') { const opacity = css.getPropertyValue(`${property}-opacity`); sample(element, paint, `icon ${property}`, 3, false, parseFloat(opacity) / (opacity.endsWith('%') ? 100 : 1)); }
  711 |         }
  712 |       } else if (sampleKind === 'border') {
  713 |         for (const pseudo of [null, '::before', '::after']) {
  714 |           const edge = getComputedStyle(element, pseudo);
  715 |           if (pseudo && (edge.content === 'none' || edge.visibility === 'hidden' || Number(edge.opacity) === 0)) continue;
  716 |           if (edge.transform !== 'none') { const matrix = new DOMMatrixReadOnly(edge.transform); if (matrix.a === 0 || matrix.d === 0) continue; }
  717 |           for (const side of ['top', 'right', 'bottom', 'left']) if (parseFloat(edge.getPropertyValue(`border-${side}-width`)) > 0 && !['none', 'hidden'].includes(edge.getPropertyValue(`border-${side}-style`))) sample(element, edge.getPropertyValue(`border-${side}-color`), `${pseudo ?? 'element'} border-${side}`, 3, pseudo ? pseudoOutside(element, edge, side) : true, Number(edge.opacity));
  718 |         }
  719 |       } else if (sampleKind === 'focus' || sampleKind === 'cue') {
  720 |         for (const pseudo of [null, '::before', '::after']) {
  721 |           const paint = getComputedStyle(element, pseudo);
  722 |           if (paint.visibility === 'hidden' || paint.display === 'none' || Number(paint.opacity) === 0 || pseudo && paint.content === 'none') continue;
  723 |           if (paint.transform !== 'none') { const matrix = new DOMMatrixReadOnly(paint.transform); if (matrix.a === 0 || matrix.d === 0) continue; }
  724 |           const qualifies = (keys: string[]) => sampleKind === 'cue' || audit.changed(element, pseudo, paint, resting, keys);
  725 |           if (qualifies(['outline-width','outline-style','outline-color','outline-offset']) && parseFloat(paint.outlineWidth) > 0 && paint.outlineStyle !== 'none') {
  726 |             const offset = parseFloat(paint.outlineOffset);
  727 |             if (offset < 0 && offset + parseFloat(paint.outlineWidth) > 0) throw new Error('Straddling outline adjacency needs pixel evidence');
  728 |             sample(element, paint.outlineColor, `${pseudo ?? 'element'} outline`, 3, offset >= 0, Number(paint.opacity));
  729 |           }
  730 |           if (qualifies(['box-shadow'])) for (const shadow of audit.shadows(element, pseudo, paint, resting)) {
  731 |             if (/\binset\b/u.test(shadow)) continue;
  732 |             const lengths = shadow.replace(/[a-z][a-z0-9-]*\([^()]*\)/giu, '').match(/-?[\d.]+px/gu)?.map(Number.parseFloat) ?? [];
  733 |             const bounds = element.getBoundingClientRect(), spread = lengths[3] ?? 0;
  734 |             if (bounds.width + 2 * spread <= 0 || bounds.height + 2 * spread <= 0 || lengths.length < 2 || (lengths[2] ?? 0) > 0 || lengths[0] === 0 && lengths[1] === 0 && (lengths[3] ?? 0) <= 0) continue;
  735 |             for (const color of shadow.match(/[a-z][a-z0-9-]*\([^()]*\)/giu) ?? []) sample(element, color, `${pseudo ?? 'element'} box-shadow`, 3, true, Number(paint.opacity));
  736 |           }
  737 |           if (pseudo && qualifies(['border-top-width','border-right-width','border-bottom-width','border-left-width','border-top-color','border-right-color','border-bottom-color','border-left-color'])) for (const side of ['top', 'right', 'bottom', 'left']) if (parseFloat(paint.getPropertyValue(`border-${side}-width`)) > 0 && !['none', 'hidden'].includes(paint.getPropertyValue(`border-${side}-style`))) sample(element, paint.getPropertyValue(`border-${side}-color`), `${pseudo} border-${side}`, 3, pseudoOutside(element, paint, side), Number(paint.opacity));
  738 |         }
  739 |       }
  740 |       if (element instanceof HTMLSlotElement) for (const child of element.assignedElements({ flatten: true })) visit(child);
  741 |       if (element.shadowRoot) for (const child of element.shadowRoot.children) visit(child);
  742 |       for (const child of element.children) if (!child.matches('style,script,template')) visit(child);
  743 |     };
  744 |     visit(scope);
  745 |     return samples;
  746 |   }, kind);
  747 | }
  748 | 
  749 | export async function expectSurfaceContrast(root: Locator, kind: ContrastKind = 'text') {
  750 |   const samples = await measureSurfaceContrast(root, kind);
  751 |   expect(samples.length, `Nonempty ${kind} contrast inventory`).toBeGreaterThan(0);
  752 |   // A Fluent control may paint a contrasting edge plus a two-color separator.
  753 |   // Alternatives belong to that unique control; another control cannot mask a failure.
  754 |   const owners = new Set(samples.map(sample => sample.owner));
  755 |   const passingOwners = new Set([...owners].filter(owner => samples.some(sample => sample.owner === owner && sample.ratio >= sample.minimum)));
  756 |   const failures = samples.filter(sample => sample.ratio < sample.minimum && (!(kind === 'focus' || kind === 'cue' || kind === 'border') || !passingOwners.has(sample.owner)));
  757 |   expect(failures, `${kind} contrast failures`).toEqual([]);
  758 |   return samples;
  759 | }
  760 | 
  761 | /** Diagnostic element captures must leave the operator's scroll/focus geometry unchanged. */
  762 | export async function screenshotPreservingScroll(target: Locator, options?: Parameters<Locator['screenshot']>[0]) {
  763 |   const positions = await target.evaluateHandle(() => {
  764 |     const elements = new Set<Element>([document.scrollingElement ?? document.documentElement]);
  765 |     const visit = (root: Document | ShadowRoot) => { for (const element of root.querySelectorAll('*')) {
  766 |       if (element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth || element.scrollTop || element.scrollLeft) elements.add(element);
  767 |       if (element.shadowRoot) visit(element.shadowRoot);
  768 |     } };
  769 |     visit(document);
  770 |     return [...elements].map(element => ({ element, left: element.scrollLeft, top: element.scrollTop }));
  771 |   });
  772 |   try { return await target.screenshot(options); }
  773 |   finally {
  774 |     await positions.evaluate(records => { for (const { element, left, top } of records) if (element.isConnected) element.scrollTo({ left, top, behavior: 'instant' }); });
  775 |     await positions.dispose();
  776 |   }
  777 | }
  778 | 
  779 | /** Wait for finite theme/control paint transitions without changing the active styling. */
  780 | export async function settlePaint(page: Page): Promise<void> {
> 781 |   await page.evaluate(async () => {
      |              ^ Error: page.evaluate: Test ended.
  782 |     for (let pass = 0; pass < 5; pass++) {
  783 |       await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  784 |       const roots: (Document | ShadowRoot)[] = [document];
  785 |       const collect = (root: Document | ShadowRoot) => { for (const element of root.querySelectorAll('*')) if (element.shadowRoot) { roots.push(element.shadowRoot); collect(element.shadowRoot); } };
  786 |       collect(document);
  787 |       const animations = roots.flatMap(root => root.getAnimations()).filter(animation => animation.playState === 'running' && Number.isFinite(Number(animation.effect?.getComputedTiming().endTime)));
  788 |       if (!animations.length) return;
  789 |       await Promise.allSettled(animations.map(animation => animation.finished));
  790 |     }
  791 |   });
  792 | }
  793 | 
```