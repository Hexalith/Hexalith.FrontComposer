# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility-state-matrix.spec.ts >> AE complete state matrix light >> generated zero-field admission: safe feedback, focus, owner, next attempt
- Location: specs/accessibility-state-matrix.spec.ts:112:7

# Error details

```
Error: locator.evaluate: Test ended.
Call log:
  - waiting for getByTestId('fc-ae-scenarios').getByRole('button', { name: 'Run accessibility specimen', exact: true })

```

# Test source

```ts
  50  |     const unlabelled: string[] = [];
  51  |     const visit = (scope: Document | ShadowRoot) => {
  52  |       for (const element of scope.querySelectorAll('*')) {
  53  |         if (element.shadowRoot) visit(element.shadowRoot);
  54  |         const style = getComputedStyle(element), box = element.getBoundingClientRect();
  55  |         if (box.width === 0 || box.height === 0 || style.visibility === 'hidden' || element.closest('[hidden],[aria-hidden="true"]')) continue;
  56  |         if (!/(auto|scroll)/u.test(style.overflowX) || element.scrollWidth <= element.clientWidth + 1) continue;
  57  |         const labelOwner = element.matches('fluent-tablist') && element.parentElement?.matches('.fluent-tabs') ? element.parentElement : element;
  58  |         const label = labelOwner.getAttribute('aria-label')?.trim() || labelOwner.getAttribute('aria-labelledby')?.split(/\s+/u).map(id => element.ownerDocument.getElementById(id)?.textContent?.trim()).filter(Boolean).join(' ');
  59  |         const grid = element.matches('[role="region"]') && Boolean(element.querySelector('[role="grid"],table,[data-fc-datagrid]'));
  60  |         const tabs = element.matches('[role="tablist"],fluent-tablist');
  61  |         if (!(label && (grid || tabs))) unlabelled.push(`${element.tagName}#${element.id}`);
  62  |       }
  63  |     };
  64  |     visit(document);
  65  |     return { width: root.clientWidth, scrollWidth: root.scrollWidth, unlabelled };
  66  |   });
  67  |   expect(geometry.scrollWidth, `Page overflow: ${JSON.stringify(geometry)}`).toBeLessThanOrEqual(geometry.width + 1);
  68  |   expect(geometry.unlabelled, 'Horizontal scroll regions must be labelled grids or tablists').toEqual([]);
  69  | }
  70  | 
  71  | /** Inventory actual hit targets, collapsing a Fluent control and its shadow control to one target. */
  72  | export async function inventoryTargets(page: Page, exceptions: TargetException[] = []) {
  73  |   return page.evaluate((records) => {
  74  |     const selector = 'a[href],button,input:not([type="hidden"]),select,textarea,summary,[role="button"],[role="tab"],[role="option"],[role="menuitem"],[role="checkbox"],[role="radio"],[role="switch"],fluent-button,fluent-text-input,fluent-number-input,fluent-select,fluent-combobox,fluent-dropdown,fluent-radio,fluent-switch,[tabindex]:not([tabindex="-1"]),[onclick]';
  75  |     const all: Element[] = [];
  76  |     const visit = (root: Document | ShadowRoot) => {
  77  |       root.querySelectorAll('*').forEach(element => { all.push(element); if (element.shadowRoot) visit(element.shadowRoot); });
  78  |     };
  79  |     visit(document);
  80  |     const visible = (element: Element) => {
  81  |       const rect = element.getBoundingClientRect();
  82  |       const style = getComputedStyle(element);
  83  |       return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none'
  84  |         && !element.closest('[inert]') && !element.closest('[aria-hidden="true"]');
  85  |     };
  86  |     const modalDialog = all.find(element => element.matches('dialog[open]'));
  87  |     const modalRoot = modalDialog?.getRootNode();
  88  |     const modal = modalRoot instanceof ShadowRoot ? modalRoot.host : modalDialog;
  89  |     const candidates = all.filter(element => element.matches(selector) && visible(element)
  90  |       && (!modal || element === modal || modal.contains(element) || element.getRootNode() instanceof ShadowRoot && modal.contains((element.getRootNode() as ShadowRoot).host)));
  91  |     const targets = candidates.filter(element => {
  92  |       const root = element.getRootNode();
  93  |       return !(root instanceof ShadowRoot && candidates.includes(root.host))
  94  |         && !candidates.some(ancestor => ancestor !== element && ancestor.tagName.startsWith('FLUENT-') && ancestor.contains(element));
  95  |     });
  96  |     const boxes = targets.map(element => ({ element, rect: element.getBoundingClientRect() }));
  97  |     const intersects = (a: DOMRect, b: DOMRect) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
  98  |     const circleIntersectsRect = (x: number, y: number, rect: DOMRect) => Math.hypot(x - Math.max(rect.left, Math.min(x, rect.right)), y - Math.max(rect.top, Math.min(y, rect.bottom))) < 12 - .01;
  99  |     const used = new Set<string>();
  100 |     const inventory = boxes.map(({ element, rect }, index) => {
  101 |       const identifier = element.id ? `#${element.id}` : element.getAttribute('data-testid') ? `[data-testid="${element.getAttribute('data-testid')}"]` : `${element.tagName.toLowerCase()}[inventory-index="${index}"]`;
  102 |       const record = records.find(item => element.matches(item.selector));
  103 |       let failure: string | null = null;
  104 |       const conforming = rect.width >= 24 && rect.height >= 24;
  105 |       if (record) used.add(record.selector);
  106 |       if (record && conforming) failure = 'Exception is stale: target already meets 24px minimum';
  107 |       if (!conforming) {
  108 |         if (!record || !record.rationale.trim() || !record.keyboardPath.trim() || !record.evidence.trim()) failure = 'Undersized target lacks an evidenced exception';
  109 |         else if (record.kind === 'Spacing') {
  110 |           const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
  111 |           if (boxes.some(other => other.element !== element && (circleIntersectsRect(x, y, other.rect)
  112 |             || (other.rect.width < 24 || other.rect.height < 24) && Math.hypot(x - other.rect.left - other.rect.width / 2, y - other.rect.top - other.rect.height / 2) < 24 - .01))) failure = '24px spacing circle intersects a target or neighboring undersized circle';
  113 |         } else if (record.kind === 'Equivalent') {
  114 |           const equivalent = record.equivalentSelector ? document.querySelector(record.equivalentSelector) : null;
  115 |           const box = equivalent?.getBoundingClientRect();
  116 |           if (!equivalent || equivalent === element || !visible(equivalent) || !box || box.width < 24 || box.height < 24 || intersects(rect, box)) failure = 'Equivalent control is absent, identical, overlapping, or undersized';
  117 |         } else if (record.kind === 'Inline') {
  118 |           if (!element.closest('p,li,dd') || !['inline', 'inline-block'].includes(getComputedStyle(element).display) || element.matches('button,[role="button"],fluent-button')) failure = 'Inline exception does not apply to a control outside running text';
  119 |         } else if (record.kind === 'Essential' && (!record.essentialReason?.trim() || !element.matches('[data-ae-essential-target]'))) failure = 'Essential exception requires an identified essential presentation and specific justification';
  120 |         else if (record.kind === 'User Agent Control' && (!element.matches('input,select,textarea') || getComputedStyle(element).appearance === 'none' || element.hasAttribute('style'))) failure = 'User agent exception requires an unmodified native control';
  121 |       }
  122 |       const css = getComputedStyle(element);
  123 |       const equivalent = record?.kind === 'Equivalent' && record.equivalentSelector ? document.querySelector(record.equivalentSelector) : null;
  124 |       const equivalentBox = equivalent?.getBoundingClientRect();
  125 |       return { target: identifier, width: rect.width, height: rect.height,
  126 |         box: { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom },
  127 |         traits: { runningText: Boolean(element.closest('p,li,dd')) && ['inline','inline-block'].includes(css.display) && !element.matches('button,[role="button"],fluent-button'), nativeUnmodified: element.matches('input,select,textarea') && css.appearance !== 'none' && !element.hasAttribute('style'), essentialIdentified: element.hasAttribute('data-ae-essential-target') },
  128 |         equivalent: equivalent && equivalentBox ? { distinct: equivalent !== element, visible: visible(equivalent), width: equivalentBox.width, height: equivalentBox.height, box: { left: equivalentBox.left, top: equivalentBox.top, right: equivalentBox.right, bottom: equivalentBox.bottom } } : null,
  129 |         conforming, exception: record ?? null, failure };
  130 |     });
  131 |     return { inventory, unusedExceptions: records.filter(record => !used.has(record.selector)).map(record => record.selector) };
  132 |   }, exceptions);
  133 | }
  134 | 
  135 | export async function expectTargetSizes(page: Page, exceptions: TargetException[] = []) {
  136 |   const result = await inventoryTargets(page, exceptions);
  137 |   expect(result.inventory.length, 'Pointer-target inventory must be nonempty').toBeGreaterThan(0);
  138 |   expect(result.unusedExceptions, 'Stale or unmatched exception selectors').toEqual([]);
  139 |   expect(result.inventory.filter(target => target.failure), 'AE-04 target-size failures').toEqual([]);
  140 |   return result.inventory;
  141 | }
  142 | 
  143 | type PaintBox = { left: number; top: number; right: number; bottom: number };
  144 | type PaintClip = { kind: 'none' | 'rect' | 'hidden' | 'unsupported'; box?: PaintBox };
  145 | type RestingPaint = Map<Element, Record<string, Record<string, string>>>;
  146 | type PaintAudit = { clip: (css: CSSStyleDeclaration, box: PaintBox) => PaintClip; parse: (value: string) => number[]; resting: (scope: Element) => RestingPaint; changed: (element: Element, pseudo: string | null, style: CSSStyleDeclaration, resting: RestingPaint, properties: string[]) => boolean; shadows: (element: Element, pseudo: string | null, style: CSSStyleDeclaration, resting: RestingPaint) => string[] };
  147 | 
  148 | /** Observe resting pseudo-class paint synchronously, suppressing application focus callbacks. */
  149 | async function preparePaintAudit(root: Locator) {
> 150 |   await root.evaluate(() => {
      |              ^ Error: locator.evaluate: Test ended.
  151 |     const parse = (value: string): number[] => {
  152 |       if (!CSS.supports('color', value)) throw new Error(`Unsupported computed paint: ${value}`);
  153 |       const canvas = document.createElement('canvas'); canvas.width = canvas.height = 1;
  154 |       const context = canvas.getContext('2d')!; context.fillStyle = value; context.fillRect(0, 0, 1, 1);
  155 |       const pixel = context.getImageData(0, 0, 1, 1).data;
  156 |       return [pixel[0], pixel[1], pixel[2], pixel[3] / 255];
  157 |     };
  158 |     const clip = (css: CSSStyleDeclaration, box: PaintBox): PaintClip => {
  159 |       let result = { left: box.left, top: box.top, right: box.right, bottom: box.bottom }, clipped = false;
  160 |       const width = box.right - box.left, height = box.bottom - box.top;
  161 |       const length = (value: string, extent: number): number | null => {
  162 |         if (/^-?[\d.]+px$/u.test(value) || value === '0') return parseFloat(value);
  163 |         if (/^-?[\d.]+%$/u.test(value)) return parseFloat(value) * extent / 100;
  164 |         const calc = value.match(/^calc\(\s*(-?[\d.]+)%\s*([+-])\s*([\d.]+)px\s*\)$/u);
  165 |         return calc ? Number(calc[1]) * extent / 100 + (calc[2] === '+' ? 1 : -1) * Number(calc[3]) : null;
  166 |       };
  167 |       if (css.clip && css.clip !== 'auto' && ['absolute','fixed'].includes(css.position)) {
  168 |         const rect = css.clip.match(/^rect\((.*)\)$/u)?.[1].split(/[,\s]+/u).filter(Boolean);
  169 |         if (!rect || rect.length !== 4) return { kind: 'unsupported' };
  170 |         const values = rect.map((value, side) => value === 'auto' ? [0,width,height,0][side] : length(value, side % 2 ? width : height));
  171 |         if (values.some(value => value === null)) return { kind: 'unsupported' };
  172 |         result = { left: box.left + values[3]!, top: box.top + values[0]!, right: box.left + values[1]!, bottom: box.top + values[2]! }; clipped = true;
  173 |       }
  174 |       if (css.clipPath && css.clipPath !== 'none') {
  175 |         const tokens = css.clipPath.match(/^inset\((.*)\)$/u)?.[1].match(/calc\([^)]*\)|[^\s]+/gu);
  176 |         if (!tokens || tokens.length > 4) return { kind: 'unsupported' };
  177 |         const sides = [tokens[0], tokens[1] ?? tokens[0], tokens[2] ?? tokens[0], tokens[3] ?? tokens[1] ?? tokens[0]];
  178 |         const values = sides.map((value, side) => length(value, side % 2 ? width : height));
  179 |         if (values.some(value => value === null)) return { kind: 'unsupported' };
  180 |         result = { left: Math.max(result.left, box.left + values[3]!), top: Math.max(result.top, box.top + values[0]!), right: Math.min(result.right, box.right - values[1]!), bottom: Math.min(result.bottom, box.bottom - values[2]!) }; clipped = true;
  181 |       }
  182 |       if (clipped && (result.right <= result.left || result.bottom <= result.top)) return { kind: 'hidden' };
  183 |       if (['mask-image','-webkit-mask-image','mask-border-source','-webkit-mask-box-image-source'].some(property => { const value = css.getPropertyValue(property); return value && value !== 'none'; })) return { kind: 'unsupported' };
  184 |       return clipped ? { kind: 'rect', box: result } : { kind: 'none' };
  185 |     };
  186 |     const properties = ['outline-width','outline-style','outline-color','outline-offset','box-shadow','content','display','visibility','opacity','transform', ...['top','right','bottom','left'].flatMap(side => [`border-${side}-width`,`border-${side}-style`,`border-${side}-color`])];
  187 |     const resting = (scope: Element) => {
  188 |       const elements = new Set<Element>();
  189 |       const visit = (element: Element) => { elements.add(element); if (element.shadowRoot) for (const child of element.shadowRoot.children) visit(child); for (const child of element.children) visit(child); };
  190 |       visit(scope);
  191 |       for (let parent: Element | null = scope; parent; parent = parent.parentElement ?? (parent.getRootNode() instanceof ShadowRoot ? (parent.getRootNode() as ShadowRoot).host : null)) {
  192 |         elements.add(parent); if (parent.shadowRoot) for (const child of parent.shadowRoot.children) visit(child);
  193 |       }
  194 |       let active = document.activeElement as HTMLElement | null;
  195 |       while (active?.shadowRoot?.activeElement instanceof HTMLElement) active = active.shadowRoot.activeElement;
  196 |       const stop = (event: Event) => event.stopImmediatePropagation();
  197 |       const events = ['focus','blur','focusin','focusout'];
  198 |       for (const event of events) window.addEventListener(event, stop, true);
  199 |       const snapshots: RestingPaint = new Map();
  200 |       // Compare settled pseudo-class endpoints; a running blur transition retains the old
  201 |       // focused transform at time zero. Remove these synchronous probe rules after restoration.
  202 |       const probeStyles = [...new Set([...elements].map(element => element.getRootNode()))].flatMap(root => {
  203 |         if (!(root instanceof Document || root instanceof ShadowRoot)) return [];
  204 |         const style = document.createElement('style'); style.textContent = '*,*::before,*::after{transition:none!important}';
  205 |         (root instanceof Document ? root.head : root).append(style); return [style];
  206 |       });
  207 |       for (const element of elements) getComputedStyle(element).transform;
  208 |       try {
  209 |         active?.blur();
  210 |         for (const element of elements) {
  211 |           const paints: Record<string, Record<string, string>> = {};
  212 |           for (const pseudo of ['', '::before', '::after']) {
  213 |             const css = getComputedStyle(element, pseudo || null);
  214 |             paints[pseudo] = Object.fromEntries(properties.map(property => [property, css.getPropertyValue(property)]));
  215 |           }
  216 |           snapshots.set(element, paints);
  217 |         }
  218 |       } finally {
  219 |         active?.focus({ preventScroll: true });
  220 |         for (const element of elements) { getComputedStyle(element).transform; getComputedStyle(element, '::after').transform; }
  221 |         for (const style of probeStyles) style.remove();
  222 |         for (const event of events) window.removeEventListener(event, stop, true);
  223 |       }
  224 |       return snapshots;
  225 |     };
  226 |     const changed: PaintAudit['changed'] = (element, pseudo, css, snapshots, keys) => {
  227 |       const baseline = snapshots.get(element)?.[pseudo ?? ''];
  228 |       return Boolean(baseline && keys.concat(pseudo ? ['content','display','visibility','opacity','transform'] : []).some(key => baseline[key] !== css.getPropertyValue(key)));
  229 |     };
  230 |     const shadows: PaintAudit['shadows'] = (element, pseudo, css, snapshots) => {
  231 |       const split = (value: string) => value.split(/,(?![^()]*\))/u).map(layer => layer.trim()).filter(layer => layer !== 'none');
  232 |       const baseline = snapshots.get(element)?.[pseudo ?? ''];
  233 |       if (!baseline) return split(css.boxShadow);
  234 |       // A permanent layer cannot certify an invisible focus-only addition.
  235 |       const old = split(baseline['box-shadow']);
  236 |       const layers = split(css.boxShadow);
  237 |       const extent = (layer: string) => {
  238 |         if (/\binset\b/u.test(layer)) return null;
  239 |         const color = layer.match(/[a-z][a-z0-9-]*\([^()]*\)/iu)?.[0];
  240 |         const values = layer.replace(/[a-z][a-z0-9-]*\([^()]*\)/giu, '').match(/-?[\d.]+px/gu)?.map(Number.parseFloat) ?? [];
  241 |         return color && values.length >= 2 && (values[2] ?? 0) === 0 && parse(color)[3] === 1 ? { x: values[0], y: values[1], spread: values[3] ?? 0 } : null;
  242 |       };
  243 |       return layers.filter((layer, layerIndex) => {
  244 |         const index = old.indexOf(layer);
  245 |         if (index < 0) {
  246 |           const paint = extent(layer);
  247 |           return !paint || !layers.slice(0, layerIndex).some(previous => { const cover = extent(previous); return cover && cover.x === paint.x && cover.y === paint.y && cover.spread >= paint.spread; });
  248 |         }
  249 |         old.splice(index, 1); return false;
  250 |       });
```